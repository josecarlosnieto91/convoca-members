/**
 * Biodevas Members — Admin JS
 * Quick state change + CSV export using biodevasAdmin API.
 */
(function (bdvAdmin) {
    'use strict';

    if (!bdvAdmin) return;

    /* ── Quick state change ──────────────────────── */
    const stateForm = document.getElementById('bdv-state-form');
    if (stateForm) {
        stateForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const submitBtn = stateForm.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.textContent = 'Guardando...';
            }

            const fd = new FormData(stateForm);
            const nonce = window.bdvAdmin?.nonce || '';

            bdvAdmin.ajaxPost('bdv_change_state', fd, nonce,
                (res) => { location.reload(); },
                (res) => {
                    alert(res.data?.message || res.data || 'Error al cambiar el estado.');
                    if (submitBtn) {
                        submitBtn.disabled = false;
                        submitBtn.textContent = 'Cambiar estado';
                    }
                }
            );
        });
    }

    /* ── WhatsApp Click Tracking ─────────────────── */
    document.addEventListener('click', function(e) {
        const waLink = e.target.closest('a[href*="wa.me"]');
        if (waLink) {
            const row = waLink.closest('tr');
            if (row) {
                const cb = row.querySelector('input[name="miembros[]"]');
                const postId = cb ? cb.value : null;
                if (postId) {
                    // Silent ping to log the contact
                    const fd = new FormData();
                    fd.append('action', 'bdv_log_whatsapp');
                    fd.append('post_id', postId);
                    fd.append('nonce', bdvAdmin.nonce);
                    
                    fetch(ajaxurl, {
                        method: 'POST',
                        body: fd
                    });
                }
            }
        }
    });

})(window.biodevasAdmin);
