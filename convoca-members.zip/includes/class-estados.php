<?php
/**
 * State machine for member status with audit logging.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class Estados
{

    /** Valid states. */
    public const STATES = [
        'pendiente_documentacion',
        'pendiente_pago',
        'activo',
        'suspendido',
        'baja_solicitada',
        'baja',
    ];

    /** Allowed transitions: from => [ to, to, … ] */
    public const TRANSITIONS = [
        'pendiente_documentacion' => ['pendiente_pago', 'activo', 'baja'],
        'pendiente_pago' => ['activo', 'suspendido', 'baja'],
        'activo' => ['suspendido', 'baja_solicitada', 'baja'],
        'suspendido' => ['activo', 'baja_solicitada', 'baja'],
        'baja_solicitada' => ['baja', 'activo'],  // Admin can reactivate or confirm baja.
        'baja' => ['pendiente_documentacion'],  // Re-entry.
    ];

    /** Human-readable labels. */
    public const LABELS = [
        'pendiente_documentacion' => 'Pendiente documentación',
        'pendiente_pago' => 'Pendiente pago',
        'activo' => 'Activo',
        'suspendido' => 'Suspendido',
        'baja_solicitada' => 'Baja solicitada',
        'baja' => 'Baja',
    ];

    /** Badge CSS classes (matching theme). */
    public const BADGE_CLASSES = [
        'pendiente_documentacion' => 'biodevas-badge biodevas-badge--pending',
        'pendiente_pago' => 'biodevas-badge biodevas-badge--pending',
        'activo' => 'biodevas-badge biodevas-badge--confirmed',
        'suspendido' => 'biodevas-badge biodevas-badge--waitlist',
        'baja_solicitada' => 'biodevas-badge biodevas-badge--warning',
        'baja' => 'biodevas-badge biodevas-badge--pending',
    ];

    public function __construct()
    {
        // Listen for state changes to trigger emails.
        add_action('biodevas_members_estado_changed', [$this, 'on_state_change'], 10, 3);
    }

    /**
     * Change a member's state with validation.
     *
     * @param int    $post_id  Miembro post ID.
     * @param string $new      Target state.
     * @param string $note     Optional note for the audit log.
     * @return bool|\WP_Error
     */
    public static function change(int $post_id, string $new, string $note = ''): bool|\WP_Error
    {
        // Prevent concurrent state changes with transient lock
        $lock_key = "bdv_state_change_{$post_id}";
        if (get_transient($lock_key)) {
            \Biodevas\Common\Logger::warning(
                "Intento de cambio de estado concurrente bloqueado para miembro #$post_id",
                'Members/Estados',
                $post_id
            );
            return new \WP_Error('concurrent_change', 'Ya hay un cambio de estado en proceso para este miembro.');
        }
        
        // Set lock for 30 seconds
        set_transient($lock_key, 1, 30);

        if (!in_array($new, self::STATES, true)) {
            delete_transient($lock_key);
            return new \WP_Error('invalid_state', __('Estado no válido.', 'biodevas-members'));
        }

        $old = get_post_meta($post_id, '_bdv_estado_miembro', true);

        if ($old === $new && !empty($old)) {
            delete_transient($lock_key);
            return true; // No-op if already in that state and state was set.
        }

        // Validate transition if not first state.
        if (!empty($old)) {
            $allowed = self::TRANSITIONS[$old] ?? [];
            if (!in_array($new, $allowed, true)) {
                delete_transient($lock_key);
                return new \WP_Error(
                    'invalid_transition',
                    sprintf(
                        /* translators: %1$s: current state, %2$s: target state */
                        __('Transición no permitida: %1$s → %2$s', 'biodevas-members'),
                        self::LABELS[$old] ?? $old,
                        self::LABELS[$new] ?? $new
                    )
                );
            }
        }

        $old_log = !empty($old) ? $old : 'NUEVO';

        // Save new state.
        update_post_meta($post_id, '_bdv_estado_miembro', $new);

        // Audit log.
        self::log($post_id, $old, $new, $note);

        // Release lock
        delete_transient($lock_key);

        /**
         * Fires after a member's state has changed.
         *
         * @param int    $post_id  Post ID.
         * @param string $new      New state.
         * @param string $old      Previous state.
         */
        \Biodevas\Common\Utils::do_action('biodevas_members_estado_changed', 'biodevas_estado_changed', $post_id, $new, $old);

        return true;
    }

    private static function log(int $post_id, string $old, string $new, string $note): void
    {
        $history = get_post_meta($post_id, '_bdv_historial', true);
        $history = is_array($history) ? $history : [];
        $history[] = [
            'de' => $old,
            'a' => $new,
            'fecha' => current_time('mysql'),
            'usuario' => get_current_user_id(),
            'nota' => $note,
        ];
        update_post_meta($post_id, '_bdv_historial', $history);

        // Also write to the members audit log table.
        \Biodevas\Common\Logger::info(
            sprintf(
                'Estado: %s → %s. %s',
                self::LABELS[$old] ?? $old ?: 'NUEVO',
                self::LABELS[$new] ?? $new,
                $note ? "Nota: $note" : ''
            ),
            'Members/Estados',
            $post_id
        );
    }

    /**
     * Trigger emails on state change.
     */
    public function on_state_change(int $post_id, string $new, string $old): void
    {
        switch ($new) {
            case 'activo':
                \Biodevas\Common\Utils::do_action('biodevas_members_email_bienvenida', 'biodevas_email_bienvenida', $post_id);
                break;
            case 'pendiente_pago':
                \Biodevas\Common\Utils::do_action('biodevas_members_email_recordatorio_pago', 'biodevas_email_recordatorio_pago', $post_id);
                break;
        }
    }

    /**
     * Get the audit history for a member.
     *
     * @return array<array{de:string, a:string, fecha:string, usuario:int, nota:string}>
     */
    public static function get_history(int $post_id): array
    {
        $history = get_post_meta($post_id, '_bdv_historial', true);
        return is_array($history) ? $history : [];
    }

    /**
     * Get badge HTML for a state.
     */
    public static function badge_html(string $state): string
    {
        $class = self::BADGE_CLASSES[$state] ?? 'biodevas-badge';
        $label = self::LABELS[$state] ?? $state;
        return '<span class="' . esc_attr($class) . '">' . esc_html($label) . '</span>';
    }
}
