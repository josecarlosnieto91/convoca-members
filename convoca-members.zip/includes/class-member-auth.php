<?php
/**
 * Member authentication and session management.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

use Biodevas\Common\Logger;
use Biodevas\Common\Utils;

if (!defined('ABSPATH')) {
    exit;
}

class Member_Auth
{
    private const SESSION_COOKIE = 'bdv_member_session';
    private const TRANSIENT_PREFIX = 'bdv_member_session_';
    private const SESSION_EXPIRATION = 6 * HOUR_IN_SECONDS;
    private const MAX_LOGIN_ATTEMPTS = 5;
    private const LOGIN_LOCKOUT_SECONDS = 15 * MINUTE_IN_SECONDS;

    /**
     * Authenticate a member and start a session.
     *
     * @param string $email Member email.
     * @param string $code  Access code.
     * @return string|\WP_Error Token on success, WP_Error on failure.
     */
    public static function login(string $email, string $code): string|\WP_Error
    {
        $email = sanitize_email($email);
        $code = strtoupper(trim($code));

        if (!$email || !$code) {
            return new \WP_Error('missing_params', 'Email y código son obligatorios.');
        }

        // Rate limiting: prevent brute-force attacks.
        $ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '127.0.0.1');
        $rate_key = 'bdv_login_attempts_' . md5($ip);
        $attempts = (int) get_transient($rate_key);

        if ($attempts >= self::MAX_LOGIN_ATTEMPTS) {
            Logger::warning("Login bloqueado por exceso de intentos desde IP: {$ip}", 'Members/Auth');
            return new \WP_Error(
                'rate_limited',
                'Demasiados intentos de acceso. Por favor, espera 15 minutos e inténtalo de nuevo.'
            );
        }

        $member = self::get_member_by_email_and_code($email, $code);
        if (is_wp_error($member)) {
            // Increment failed attempts counter.
            set_transient($rate_key, $attempts + 1, self::LOGIN_LOCKOUT_SECONDS);
            return $member;
        }

        // Reset attempts on successful login.
        delete_transient($rate_key);

        // Generate token.
        $token = wp_generate_password(32, false);
        
        // Save session in transient.
        set_transient(self::TRANSIENT_PREFIX . $token, $member->ID, self::SESSION_EXPIRATION);
        
        // Set cookie.
        setcookie(self::SESSION_COOKIE, $token, [
            'expires' => time() + self::SESSION_EXPIRATION,
            'path' => COOKIEPATH,
            'domain' => COOKIE_DOMAIN,
            'secure' => is_ssl(),
            'httponly' => true,
            'samesite' => 'Strict',
        ]);

        \Biodevas\Common\Logger::info("Socio ha iniciado sesión: {$member->post_title} (ID: {$member->ID})", 'Members/Members', $member->ID);

        return $token;
    }

    /**
     * End member session.
     */
    public static function logout(): void
    {
        $token = self::get_current_token();
        if ($token) {
            delete_transient(self::TRANSIENT_PREFIX . $token);
        }
        
        setcookie(self::SESSION_COOKIE, '', [
            'expires' => time() - HOUR_IN_SECONDS,
            'path' => COOKIEPATH,
            'domain' => COOKIE_DOMAIN,
            'secure' => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    /**
     * Get the ID of the currently logged-in member.
     *
     * @return int Member ID or 0 if not logged in.
     */
    public static function get_current_member_id(): int
    {
        $token = self::get_current_token();
        if (!$token) {
            return 0;
        }

        $member_id = get_transient(self::TRANSIENT_PREFIX . $token);
        
        if ($member_id) {
            // Renew session.
            set_transient(self::TRANSIENT_PREFIX . $token, $member_id, self::SESSION_EXPIRATION);
            
            // Note: PHP setcookie only works if headers aren't sent.
            if (!headers_sent()) {
                setcookie(self::SESSION_COOKIE, $token, [
                    'expires' => time() + self::SESSION_EXPIRATION,
                    'path' => COOKIEPATH,
                    'domain' => COOKIE_DOMAIN,
                    'secure' => is_ssl(),
                    'httponly' => true,
                    'samesite' => 'Strict',
                ]);
            }
            
            return (int) $member_id;
        }
        
        return 0;
    }

    /**
     * Get the data of the currently logged-in member securely.
     * 
     * @return array|null Array with name, email, phone, dni, or null if not logged in.
     */
    public static function get_current_member_data(): ?array
    {
        $member_id = self::get_current_member_id();
        if (!$member_id) {
            return null;
        }

        $post = get_post($member_id);
        if (!$post) return null;

        return [
            'id' => $member_id,
            'name' => $post->post_title,
            'email' => get_post_meta($member_id, '_bdv_email', true),
            'phone' => get_post_meta($member_id, '_bdv_phone', true),
            'dni' => get_post_meta($member_id, '_bdv_dni', true),
            'member_status' => get_post_meta($member_id, '_bdv_status', true),
        ];
    }

    /**
     * Check if the current request is authenticated.
     *
     * @return bool
     */
    public static function is_authenticated(): bool
    {
        return self::get_current_member_id() > 0;
    }

    /**
     * Get the current session token from cookie or header.
     *
     * @return string
     */
    public static function get_current_token(): string
    {
        $token = sanitize_text_field($_COOKIE[self::SESSION_COOKIE] ?? '');
        
        if (!$token && isset($_SERVER['HTTP_X_BDV_AUTH'])) {
            $token = sanitize_text_field($_SERVER['HTTP_X_BDV_AUTH']);
        }

        return (string) $token;
    }

    /**
     * Find a member by email and access code.
     *
     * @param string $email
     * @param string $code
     * @return \WP_Post|\WP_Error
     */
    public static function get_member_by_email_and_code(string $email, string $code): \WP_Post|\WP_Error
    {
        $posts = get_posts([
            'post_type' => 'miembro',
            'posts_per_page' => 1,
            'post_status' => 'publish',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => '_bdv_email',
                    'value' => $email,
                    'compare' => '=',
                ],
                [
                    'key' => '_bdv_access_code',
                    'value' => $code,
                    'compare' => '=',
                ],
            ],
        ]);

        if (empty($posts)) {
            return new \WP_Error('not_found', 'No se ha encontrado ningún socio con esos datos.');
        }

        return $posts[0];
    }
}
