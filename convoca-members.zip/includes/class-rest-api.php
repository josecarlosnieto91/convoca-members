<?php
/**
 * REST API for Members.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class Rest_API
{
    /**
     * Namespace for the API.
     */
    public const NAMESPACE = 'biodevas/v1';

    /**
     * Rate limit: max attempts per IP in window.
     */
    private const RATE_LIMIT_MAX = 10;
    private const RATE_LIMIT_WINDOW = 300; // 5 minutes

    public function __construct()
    {
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    /**
     * Register routes.
     */
    public function register_routes(): void
    {
        // Login.
        register_rest_route(self::NAMESPACE, '/login', [
            'methods'             => 'POST',
            'callback'            => [$this, 'login'],
            'permission_callback' => '__return_true',
        ]);

        // Current member profile.
        register_rest_route(self::NAMESPACE, '/me', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_profile'],
            'permission_callback' => [$this, 'check_member_auth'],
        ]);

        // Inscriptions.
        register_rest_route(self::NAMESPACE, '/me/inscripciones', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_inscriptions'],
            'permission_callback' => [$this, 'check_member_auth'],
        ]);

        // Payments.
        register_rest_route(self::NAMESPACE, '/me/pagos', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_payments'],
            'permission_callback' => [$this, 'check_member_auth'],
        ]);

        // Volunteering hours.
        register_rest_route(self::NAMESPACE, '/me/horas', [
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'get_hours'],
                'permission_callback' => [$this, 'check_member_auth'],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [$this, 'submit_hours'],
                'permission_callback' => [$this, 'check_member_auth'],
            ]
        ]);

        // Card download/view.
        register_rest_route(self::NAMESPACE, '/me/card', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_card'],
            'permission_callback' => [$this, 'check_member_auth'],
        ]);

        // Active projects for dropdown.
        register_rest_route(self::NAMESPACE, '/proyectos', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_proyectos'],
            'permission_callback' => '__return_true',
        ]);

        // Download certificate.
        register_rest_route(self::NAMESPACE, '/me/certificate', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_certificate'],
            'permission_callback' => [$this, 'check_member_auth'],
        ]);

        // Download certificate as PDF.
        register_rest_route(self::NAMESPACE, '/me/certificate/download', [
            'methods'             => 'GET',
            'callback'            => [$this, 'download_certificate'],
            'permission_callback' => [$this, 'check_member_auth'],
        ]);

        // Unsubscribe request.
        register_rest_route(self::NAMESPACE, '/me/unsubscribe', [
            'methods'             => 'POST',
            'callback'            => [$this, 'unsubscribe_request'],
            'permission_callback' => [$this, 'check_member_auth'],
        ]);
    }

    /**
     * Check if a member is logged in via session cookie.
     */
    public function check_member_auth(): bool
    {
        return (bool) Member_Auth::get_current_member_id();
    }

    /**
     * Login handler.
     */
    public function login(\WP_REST_Request $request): \WP_REST_Response
    {
        // Check rate limit before processing
        if (!$this->check_rate_limit('login')) {
            return new \WP_REST_Response([
                'success' => false, 
                'message' => 'Demasiados intentos. Intenta de nuevo en 5 minutos.'
            ], 429);
        }

        $email = sanitize_email($request->get_param('email'));
        $code = sanitize_text_field($request->get_param('code'));

        if (empty($email) || empty($code)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Faltan credenciales.'], 400);
        }

        $token = Member_Auth::login($email, $code);

        if (is_wp_error($token)) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => $token->get_error_message()
            ], 401);
        }

        return new \WP_REST_Response([
            'success' => true,
            'token'   => $token
        ]);
    }

    /**
     * Check rate limit for an action.
     * Uses transients to track attempts per IP.
     */
    private function check_rate_limit(string $action): bool
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $key = 'bdv_ratelimit_' . $action . '_' . md5($ip);
        
        $attempts = (int) get_transient($key) ?: 0;
        
        if ($attempts >= self::RATE_LIMIT_MAX) {
            \Biodevas\Common\Logger::warning("Rate limit exceeded for $action from IP $ip", 'Members/API');
            return false;
        }
        
        set_transient($key, $attempts + 1, self::RATE_LIMIT_WINDOW);
        return true;
    }

    /**
     * Get profile data.
     */
    public function get_profile(\WP_REST_Request $request): \WP_REST_Response
    {
        $member_id = Member_Auth::get_current_member_id();
        $post = get_post($member_id);

        if (!$post || $post->post_type !== 'miembro') {
            return new \WP_REST_Response(['error' => 'Miembro no encontrado.'], 404);
        }

        return new \WP_REST_Response([
            'id'     => $member_id,
            'nombre' => $post->post_title,
            'email'  => get_post_meta($member_id, '_bdv_email', true),
            'codigo' => get_post_meta($member_id, '_bdv_access_code', true),
            'estado' => get_post_meta($member_id, '_bdv_estado_miembro', true),
            'tipo'   => (array) get_post_meta($member_id, '_bdv_modalidad', true) ?: ['Socio/a'],
        ]);
    }

    /**
     * Get inscriptions from biodevas-enroll.
     */
    public function get_inscriptions(\WP_REST_Request $request): \WP_REST_Response
    {
        $member_id = Member_Auth::get_current_member_id();
        $email = get_post_meta($member_id, '_bdv_email', true);
        $dni = get_post_meta($member_id, '_bdv_dni', true);

        // Query inscriptions by email or DNI.
        $args = [
            'post_type'      => 'inscripcion',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'meta_query'     => [
                'relation' => 'OR',
                ['key' => '_bde_email', 'value' => $email],
                ['key' => '_bde_dni', 'value' => $dni],
            ],
        ];

        $query = new \WP_Query($args);
        $items = [];

        if ($query->have_posts()) {
            foreach ($query->posts as $post) {
                $actividad_id = get_post_meta($post->ID, '_bde_actividad_id', true);
                $actividad = get_the_title($actividad_id);
                
                $items[] = [
                    'id'        => $post->ID,
                    'fecha'     => get_the_date('d/m/Y', $post->ID),
                    'actividad' => $actividad ?: __('Actividad desconocida', 'biodevas-members'),
                    'estado'    => get_post_meta($post->ID, '_bde_estado', true),
                    'token'     => get_post_meta($post->ID, '_bde_checkin_token', true),
                ];
            }
        }

        return new \WP_REST_Response(['items' => $items]);
    }

    /**
     * Get payments from biodevas-gateway.
     */
    public function get_payments(\WP_REST_Request $request): \WP_REST_Response
    {
        $member_id = Member_Auth::get_current_member_id();

        $args = [
            'post_type'      => 'pago',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_query'     => [
                ['key' => '_bdg_origin', 'value' => 'members'],
                ['key' => '_bdg_origin_id', 'value' => $member_id],
            ],
        ];

        $query = new \WP_Query($args);
        $items = [];

        if ($query->have_posts()) {
            foreach ($query->posts as $post) {
                $status = get_post_meta($post->ID, '_bdg_status', true);
                $amount = (int) get_post_meta($post->ID, '_bdg_amount_cents', true);
                
                $items[] = [
                    'id'       => $post->ID,
                    'fecha'    => get_the_date('d/m/Y', $post->ID),
                    'concepto' => get_post_meta($post->ID, '_bdg_product_desc', true),
                    'importe'  => number_format($amount / 100, 2, ',', '.'),
                    'estado'   => $status,
                ];
            }
        }

        return new \WP_REST_Response(['items' => $items]);
    }

    /**
     * Get volunteering hours.
     */
    public function get_hours(\WP_REST_Request $request): \WP_REST_Response
    {
        $member_id = Member_Auth::get_current_member_id();

        $args = [
            'post_type'      => 'registro_hora',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'meta_query'     => [
                ['key' => '_bdv_miembro_id', 'value' => $member_id],
            ],
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        $query = new \WP_Query($args);
        $items = [];
        $total_horas = 0;

        if ($query->have_posts()) {
            foreach ($query->posts as $post) {
                $horas = (float) get_post_meta($post->ID, '_bdv_horas', true);
                $estado = get_post_meta($post->ID, '_bdv_estado', true) ?: 'pendiente';
                $actividad_id = get_post_meta($post->ID, '_bdv_actividad_id', true);
                $proyecto_id = get_post_meta($post->ID, '_bdv_proyecto_id', true);
                $tareas = get_post_meta($post->ID, '_bdv_tareas', true);
                
                if ($estado === 'aprobada') {
                    $total_horas += $horas;
                }

                $items[] = [
                    'id'          => $post->ID,
                    'fecha'       => get_post_meta($post->ID, '_bdv_fecha', true) ?: get_the_date('d/m/Y', $post->ID),
                    'descripcion' => $post->post_content,
                    'horas'       => $horas,
                    'estado'      => $estado,
                    'actividad'   => $actividad_id ? get_the_title($actividad_id) : '',
                    'actividad_id'=> $actividad_id,
                    'proyecto'    => $proyecto_id ? get_the_title($proyecto_id) : '',
                    'proyecto_id' => $proyecto_id,
                    'tareas'      => $tareas,
                    'nota_admin'  => get_post_meta($post->ID, '_bdv_nota_admin', true) ?: '',
                ];
            }
        }

        return new \WP_REST_Response([
            'items'       => $items,
            'total_horas' => $total_horas
        ]);
    }

    /**
     * Submit new hours record.
     */
    public function submit_hours(\WP_REST_Request $request): \WP_REST_Response
    {
        $member_id = Member_Auth::get_current_member_id();
        $fecha = sanitize_text_field($request->get_param('fecha'));
        $descripcion = sanitize_textarea_field($request->get_param('descripcion'));
        $horas = (float) $request->get_param('horas');
        $actividad_id = (int) $request->get_param('actividad_id');
        $proyecto_id = (int) $request->get_param('proyecto_id');
        $tareas = sanitize_textarea_field($request->get_param('tareas'));

        if (empty($fecha) || empty($descripcion) || $horas <= 0) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Datos inválidos.'], 400);
        }

        $post_title = sprintf('Registro Socio %d — %s — %gh', $member_id, $fecha, $horas);
        
        $post_id = wp_insert_post([
            'post_type'    => 'registro_hora',
            'post_title'   => $post_title,
            'post_content' => $descripcion,
            'post_status'  => 'publish',
        ]);

        if (is_wp_error($post_id)) {
            return new \WP_REST_Response(['success' => false, 'message' => 'Error al guardar.'], 500);
        }

        update_post_meta($post_id, '_bdv_miembro_id', $member_id);
        update_post_meta($post_id, '_bdv_fecha', $fecha);
        update_post_meta($post_id, '_bdv_horas', $horas);
        update_post_meta($post_id, '_bdv_estado', 'pendiente');
        
        if ($actividad_id) {
            update_post_meta($post_id, '_bdv_actividad_id', $actividad_id);
        }

        if ($proyecto_id) {
            update_post_meta($post_id, '_bdv_proyecto_id', $proyecto_id);
        }

        if ($tareas) {
            update_post_meta($post_id, '_bdv_tareas', substr($tareas, 0, 500));
        }

        // Notification to admin.
        \Biodevas\Common\Logger::log("Nuevo registro de horas enviado por socio ID $member_id: $horas horas el $fecha", 'Members/Hours', $post_id);
        
        // Notify admin via action
        \Biodevas\Common\Utils::do_action('biodevas_members_hours_submitted', 'biodevas_hours_submitted', $post_id, $member_id);

        return new \WP_REST_Response(['success' => true, 'id' => $post_id]);
    }

    /**
     * Get active projects for dropdown.
     */
    public function get_proyectos(): \WP_REST_Response
    {
        $proyectos = CPT_Proyecto::get_active_proyectos();
        $items = [];
        
        foreach ($proyectos as $id => $title) {
            $items[] = ['id' => $id, 'title' => $title];
        }
        
        return new \WP_REST_Response($items);
    }

    /**
     * Get certificate download URL and info.
     */
    public function get_certificate(): \WP_REST_Response
    {
        $member_id = Member_Auth::get_current_member_id();
        
        $completado = Voluntariado_Manager::ha_completado_objetivo($member_id);
        
        if (!$completado) {
            return new \WP_REST_Response([
                'success' => false,
                'message' => 'Aún no has completado las horas mínimas requeridas para generar el certificado.',
                'progress' => Voluntariado_Manager::get_progreso($member_id),
            ], 400);
        }
        
        $cert_id = get_post_meta($member_id, '_bdv_certificado_id', true);
        $horas = Voluntariado_Manager::get_horas_aprobadas($member_id);
        $objetivo = Voluntariado_Manager::get_horas_objetivo($member_id);
        
        return new \WP_REST_Response([
            'success' => true,
            'certificado_id' => $cert_id,
            'horas' => $horas,
            'objetivo' => $objetivo,
            'download_url' => rest_url('biodevas/v1/me/certificate/download'),
        ]);
    }

    /**
     * Download certificate as PDF.
     */
    public function download_certificate(): void
    {
        $member_id = Member_Auth::get_current_member_id();
        
        if (!$member_id) {
            wp_send_json_error('No autorizado', 401);
        }
        
        Certificate_Generator::serve_pdf($member_id);
    }

    /**
     * Process unsubscribe request.
     */
    public function unsubscribe_request(\WP_REST_Request $request): \WP_REST_Response
    {
        $member_id = Member_Auth::get_current_member_id();
        
        // Log the request and notify admin.
        Estados::change($member_id, 'baja_solicitada', 'Solicitud de baja desde el panel de socio.');
        
        // Action for Email Manager to hook into.
        \Biodevas\Common\Utils::do_action('biodevas_members_unsubscribe_request', 'biodevas_member_unsubscribe_request', $member_id);

        return new \WP_REST_Response(['success' => true]);
    }

    /**
     * Get member card HTML.
     */
    public function get_card(\WP_REST_Request $request): \WP_REST_Response
    {
        $member_id = Member_Auth::get_current_member_id();
        $html = PDF_Card::get_html($member_id);
        return new \WP_REST_Response(['html' => $html]);
    }
}
