<?php
/**
 * Volunteer PDF Agreement Generator.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class PDF_Document
{
    public static function init(): void
    {
        add_action('bdv_voluntario_aprobado', [self::class, 'handle_approval']);
        add_filter('bdv_voluntario_aprobado_attachments', [self::class, 'add_pdf_to_email'], 10, 2);
    }

    public static function handle_approval(int $user_id): void
    {
        self::generate_volunteer_agreement($user_id);
    }

    public static function add_pdf_to_email(array $attachments, int $user_id): array
    {
        $existing = get_posts([
            'post_type' => 'bdv_documento',
            'meta_key' => '_bdv_usuario_id',
            'meta_value' => $user_id,
            'posts_per_page' => 1
        ]);
        
        if (!empty($existing)) {
            $filepath = get_post_meta($existing[0]->ID, '_bdv_documento_path', true);
            if ($filepath && file_exists($filepath)) {
                $attachments[] = $filepath;
            }
        }
        
        return $attachments;
    }

    public static function generate_volunteer_agreement(int $user_id): ?int
    {
        $user = get_userdata($user_id);
        if (!$user) {
            return null;
        }

        // Only generate if not exists
        $existing = get_posts([
            'post_type' => 'bdv_documento',
            'meta_key' => '_bdv_usuario_id',
            'meta_value' => $user_id,
            'posts_per_page' => 1
        ]);
        if (!empty($existing)) {
            return $existing[0]->ID;
        }

        if (!class_exists('\\Biodevas\\Common\\BDV_Signature')) {
            error_log('Biodevas: BDV_Signature class not found.');
            return null;
        }

        $signature = new \Biodevas\Common\BDV_Signature();

        // Collect user data
        $nombre = $user->first_name ?: $user->display_name;
        $dni = get_user_meta($user_id, '_cst_dni', true);
        $email = $user->user_email;
        $telefono = get_user_meta($user_id, '_cst_telefono', true);
        $direccion = get_user_meta($user_id, '_cst_direccion', true);
        $municipio = get_user_meta($user_id, '_cst_municipio', true);
        
        $legal_text = get_option('bdv_volunteer_legal_text', '');
        $date = wp_date('d/m/Y');
        
        $timestamp = time();
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'Desconocida';

        // Dynamic fields
        $dynamic_fields = get_option('bdv_volunteer_fields', []);
        $dynamic_html = '';
        if (!empty($dynamic_fields)) {
            $dynamic_html .= '<h3>Información Adicional</h3><table style="width:100%; border-collapse: collapse; margin-bottom: 20px;">';
            foreach ($dynamic_fields as $field) {
                $val = get_user_meta($user_id, '_cst_' . $field['name'], true);
                if ($val) {
                    $dynamic_html .= '<tr>';
                    $dynamic_html .= '<th style="text-align: left; padding: 8px; border-bottom: 1px solid #ddd; width: 40%;">' . esc_html($field['label']) . '</th>';
                    $dynamic_html .= '<td style="padding: 8px; border-bottom: 1px solid #ddd;">' . esc_html($val) . '</td>';
                    $dynamic_html .= '</tr>';
                }
            }
            $dynamic_html .= '</table>';
        }

        $templates = get_option('bdv_pdf_templates', []);
        $template_html = isset($templates['acuerdo_incorporacion']) ? $templates['acuerdo_incorporacion']['content'] : '<h1>Acuerdo de Incorporación</h1><p>Nombre: {{nombre}}</p><p>DNI: {{dni}}</p>{{dynamic_fields}}{{declaracion}}';
        
        // Append digital stamp
        $content_for_hash = $user_id . $dni . $email . $timestamp;
        $stamp_html = $signature->get_acceptance_stamp_html($nombre, $ip, $timestamp, $content_for_hash);
        
        if (strpos($template_html, '<!-- FIRMA DIGITAL SERÁ AÑADIDA POR LA CLASE BDV_Signature -->') !== false) {
            $template_html = str_replace('<!-- FIRMA DIGITAL SERÁ AÑADIDA POR LA CLASE BDV_Signature -->', $stamp_html, $template_html);
        } else {
            $template_html .= $stamp_html;
        }

        $data = [
            'nombre' => $nombre,
            'dni' => $dni,
            'email' => $email,
            'telefono' => $telefono,
            'direccion' => $direccion . ', ' . $municipio,
            'fecha_incorporacion' => $date,
            'declaracion' => wp_kses_post($legal_text),
            'dynamic_fields' => $dynamic_html
        ];

        // Create upload directory
        $upload_dir = wp_upload_dir();
        $target_dir = $upload_dir['basedir'] . '/biodevas-documentos';
        
        $hash = $signature->create_hash($content_for_hash, $ip, $timestamp);
        $filename = 'acuerdo-voluntariado-' . $user_id . '-' . substr($hash, 0, 8) . '.pdf';
        $filepath = $target_dir . '/' . $filename;
        $fileurl = $upload_dir['baseurl'] . '/biodevas-documentos/' . $filename;

        $generated_path = $signature->generate_pdf($template_html, $data, $filepath);

        if (!$generated_path) {
            return null;
        }

        // Create CPT
        $post_id = wp_insert_post([
            'post_type' => 'bdv_documento',
            'post_title' => 'Acuerdo Voluntariado - ' . $nombre,
            'post_status' => 'publish',
            'post_author' => 1 // System
        ]);

        if (!is_wp_error($post_id)) {
            update_post_meta($post_id, '_bdv_usuario_id', $user_id);
            update_post_meta($post_id, '_bdv_tipo_documento', 'acuerdo_voluntariado');
            update_post_meta($post_id, '_bdv_hash', $hash);
            update_post_meta($post_id, '_bdv_documento_url', $fileurl);
            update_post_meta($post_id, '_bdv_documento_path', $filepath);
            return $post_id;
        }

        return null;
    }
}
