<?php
/**
 * Member registration processing logic.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

use Biodevas\Common\Logger;
use Biodevas\Common\Utils;

if (!defined('ABSPATH')) {
    exit;
}

class Process_Member
{

    /**
     * Process a member registration request.
     *
     * @param array $data  Sanitized input data.
     * @param array $files Uploaded files ($_FILES).
     * @return array|\WP_Error Success data or WP_Error.
     */
    public static function register(array $data, array $files = []): array|\WP_Error
    {
        // 1. Validate
        $validation = self::validate($data, $files);
        if (is_wp_error($validation)) {
            return $validation;
        }

        // 2. Identify and sanitize key fields
        $nombre = sanitize_text_field($data['nombre'] ?? '');
        $dni = strtoupper(trim($data['dni'] ?? ''));
        $dni = str_replace([' ', '-'], '', $dni);
        $email = sanitize_email($data['email'] ?? '');
        $plan = sanitize_text_field($data['plan'] ?? '');
        $sub_plan = sanitize_text_field($data['sub_plan'] ?? '');
        $forma_pago = sanitize_text_field($data['forma_pago'] ?? '');
        
        // Mask DNI for logging (show only first 2 and last 2 chars)
        $dni_masked = strlen($dni) > 4 ? substr($dni, 0, 2) . '...' . substr($dni, -2) : 'XXXX';
        \Biodevas\Common\Logger::info("Iniciando registro de nuevo miembro: $nombre (DNI: $dni_masked, Email: $email)", 'Members');

        // 3. Check for duplicates ATOMICALLY to prevent race conditions
        global $wpdb;
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
             JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE p.post_type = 'miembro' 
               AND p.post_status = 'publish'
               AND pm.meta_key IN ('_bdv_dni', '_bdv_email')
               AND pm.meta_value = %s
             LIMIT 1",
            $dni
        ));
        
        if (!$exists) {
            // Also check email separately as OR logic
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
                 JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                 WHERE p.post_type = 'miembro' 
                   AND p.post_status = 'publish'
                   AND pm.meta_key = '_bdv_email'
                   AND pm.meta_value = %s
                 LIMIT 1",
                $email
            ));
        }

        if (!empty($exists)) {
            \Biodevas\Common\Logger::warning("Intento de registro duplicado (DNI o Email ya existen): $dni_masked / $email", 'Members');
            return new \WP_Error('duplicate', 'Ya existe un miembro registrado con este DNI o email.');
        }

        // 4. Resolve plan data
        $plan_key = (in_array($plan, ['familiar', 'juvenil'], true) && $sub_plan) ? $sub_plan : $plan;
        $plan_data = CPT_Miembro::get_plan($plan_key);
        if (!$plan_data) {
            return new \WP_Error('invalid_plan', 'El plan seleccionado no es válido.');
        }

        // 5. Calculate age/minor status
        $fecha_nac = sanitize_text_field($data['fecha_nacimiento'] ?? '');
        $menor = false;
        if ($fecha_nac) {
            $dob = new \DateTime($fecha_nac);
            $today = new \DateTime();
            $age = $today->diff($dob)->y;
            $menor = $age < 18;
        }

        // 6. Determine initial state
        // If they choose 'voluntariado' (hours instead of money), they are 'pendiente_documentacion' (proof of volunteering or similar)
        // If they choose 'cuota' (money), they are 'pendiente_pago'
        $estado = ($forma_pago === 'voluntariado') ? 'pendiente_documentacion' : 'pendiente_pago';

        // 7. Create Post with transaction
        $wpdb->query('START TRANSACTION');
        
        try {
            $post_id = wp_insert_post([
                'post_type' => 'miembro',
                'post_title' => $nombre,
                'post_status' => 'publish', // CPT is private, so 'publish' means internally available
            ]);

            if (is_wp_error($post_id)) {
                $wpdb->query('ROLLBACK');
                \Biodevas\Common\Logger::error("Error al insertar post de miembro: " . $post_id->get_error_message(), 'Members');
                return new \WP_Error('create_failed', 'Error al crear el registro en la base de datos.');
            }

            // 8. Save Meta
            $settings = get_option('bdv_members_settings', []);
            
            $meta = [
                'estado_miembro' => $estado,
                'plan' => $plan,
                'plan_label' => CPT_Miembro::get_plan($plan)['label'] ?? $plan,
                'sub_plan' => $sub_plan,
                'forma_pago' => $forma_pago,
                'cuota' => $plan_key, // legacy alias
                'modalidad' => $plan_data['modalidad'] ?? 'Numerario',
                'importe_cuota' => $plan_data['price'] ?? 0,
                'estado_cuota' => ($forma_pago === 'voluntariado') ? 'activa' : 'pendiente',
                'dni' => $dni,
                'fecha_nacimiento' => $fecha_nac,
                'email' => $email,
                'access_code' => Utils::generate_access_code(),
                'telefono' => sanitize_text_field($data['telefono'] ?? ''),
                'whatsapp' => sanitize_text_field($data['whatsapp'] ?? 'si'),
                'direccion' => sanitize_text_field($data['direccion'] ?? ''),
                'municipio' => sanitize_text_field($data['municipio'] ?? ''),
                'canal_contacto' => sanitize_text_field($data['canal_contacto'] ?? 'whatsapp'),
                'menor_edad' => $menor ? '1' : '0',
                'es_voluntario' => ($forma_pago === 'voluntariado') ? '1' : '0',
                'rgpd_version' => $settings['rgpd_version'] ?? '1.0',
                'rgpd_timestamp' => current_time('mysql'),
                'comunicaciones_ok' => !empty($data['comunicaciones']) ? '1' : '0',
                'pago_recurrente' => !empty($data['pago_recurrente']) ? '1' : '0',
                // Note: Renewal date is set on payment completion/approval, not here.
                // But for initial record, we might set a tentative one or leave empty.
            ];

            if ($menor) {
                $meta['tutor_nombre'] = sanitize_text_field($data['tutor_nombre'] ?? '');
                $meta['tutor_dni'] = sanitize_text_field($data['tutor_dni'] ?? '');
                $meta['tutor_autorizacion'] = '1';
            }

            foreach ($meta as $key => $value) {
                update_post_meta($post_id, '_bdv_' . $key, $value);
            }

            // Log GDPR consent.
            GDPR_Tools::log_consent(
                $post_id,
                'Aceptación de política de privacidad y condiciones de alta como socio.',
                $settings['rgpd_version'] ?? '1.0'
            );

            // Initial state log
            Estados::change($post_id, $estado, 'Registro inicial desde formulario');

            // Commit transaction
            $wpdb->query('COMMIT');
        } catch (\Throwable $e) {
            $wpdb->query('ROLLBACK');
            \Biodevas\Common\Logger::error("Excepción durante registro de miembro: " . $e->getMessage(), 'Members');
            return new \WP_Error('create_failed', 'Error inesperado al crear el registro.');
        }

        // 9. Handle File Uploads (outside transaction - can fail without rolling back member)
        if ($forma_pago === 'transferencia' && !empty($files['justificante'])) {
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');

            $file = $files['justificante'];
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
            $max_size = 5 * 1024 * 1024; // 5MB

            if (!in_array($file['type'], $allowed_types, true)) {
                \Biodevas\Common\Logger::error("Tipo de archivo no permitido: " . $file['type'], 'Members', $post_id);
            } elseif ($file['size'] > $max_size) {
                \Biodevas\Common\Logger::error("Archivo demasiado grande: " . $file['size'] . " bytes", 'Members', $post_id);
            } else {
                $attachment_id = media_handle_upload('justificante', $post_id);
                if (!is_wp_error($attachment_id)) {
                    update_post_meta($post_id, '_bdv_justificante_id', $attachment_id);
                    \Biodevas\Common\Logger::info("Justificante de transferencia subido: ID $attachment_id", 'Members', $post_id);
                } else {
                    \Biodevas\Common\Logger::error("Error al subir justificante: " . $attachment_id->get_error_message(), 'Members', $post_id);
                }
            }
        }

        // 10. Trigger Notifications
        \Biodevas\Common\Utils::do_action('biodevas_members_email_solicitud', 'biodevas_email_solicitud', $post_id);

        // 11. Handle Gateway Redirection
        $importe = (float) ($plan_data['price'] ?? 0);
        if (in_array($forma_pago, ['tarjeta', 'bizum'], true) && $importe > 0 && function_exists('Biodevas\\Gateway\\bdv_gateway_create_payment')) {
            $amount_cents = (int) round($importe * 100);

            $payment = \Biodevas\Gateway\bdv_gateway_create_payment([
                'amount_cents' => $amount_cents,
                'method' => $forma_pago,
                'origin' => 'members',
                'origin_id' => $post_id,
                'product_desc' => mb_substr('BIODEVAS CUOTA ' . ($plan_data['label'] ?? ''), 0, 125),
            ]);

            if (!is_wp_error($payment)) {
                update_post_meta($post_id, '_bdv_pago_id', $payment['pago_id']);
                return [
                    'id' => $post_id,
                    'nombre' => $nombre,
                    'redirect' => $payment['payment_url'],
                    'estado' => $estado,
                ];
            } else {
                \Biodevas\Common\Logger::error("Error al crear pago en pasarela: " . $payment->get_error_message(), 'Members', $post_id);
                return [
                    'id' => $post_id,
                    'nombre' => $nombre,
                    'gateway_error' => true,
                    'error_message' => 'No se ha podido contactar con la pasarela. Tu registro está guardado pero el pago está pendiente.',
                    'estado' => $estado,
                ];
            }
        }

        return [
            'id' => $post_id,
            'nombre' => $nombre,
            'estado' => $estado,
            'redirect' => add_query_arg('members_success', '1', home_url()),
        ];
    }

    /**
     * Validate registration data.
     */
    public static function validate(array $data, array $files = []): bool|\WP_Error
    {
        $errors = [];

        if (empty($data['nombre'])) $errors[] = 'El nombre es obligatorio.';
        if (empty($data['dni'])) $errors[] = 'El DNI/NIE es obligatorio.';
        if (empty($data['email'])) $errors[] = 'El email es obligatorio.';
        if (!is_email($data['email'] ?? '')) $errors[] = 'El email no es válido.';
        
        // Validate fecha_nacimiento: not empty, valid date, not in the future
        $fecha_nac = $data['fecha_nacimiento'] ?? '';
        if (empty($fecha_nac)) {
            $errors[] = 'La fecha de nacimiento es obligatoria.';
        } else {
            $dob = \DateTime::createFromFormat('Y-m-d', $fecha_nac);
            if (!$dob) {
                $errors[] = 'La fecha de nacimiento tiene un formato inválido.';
            } elseif ($dob > new \DateTime()) {
                $errors[] = 'La fecha de nacimiento no puede ser futura.';
            }
        }
        
        // Validate telefono: not empty and reasonable format
        $telefono = $data['telefono'] ?? '';
        if (empty($telefono)) {
            $errors[] = 'El teléfono es obligatorio.';
        } elseif (!preg_match('/^[6-9]\d{8}$/', preg_replace('/\s+/', '', $telefono))) {
            $errors[] = 'El teléfono debe ser un número español válido (9 dígitos, mulaiing con 6-9).';
        }
        
        if (empty($data['direccion'])) $errors[] = 'La dirección es obligatoria.';
        if (empty($data['municipio'])) $errors[] = 'El municipio es obligatorio.';
        if (empty($data['plan'])) $errors[] = 'Debes seleccionar un plan de membresía.';
        if (empty($data['forma_pago'])) $errors[] = 'Debes seleccionar una forma de pago.';
        if (empty($data['rgpd'])) $errors[] = 'Debes aceptar la política de privacidad.';

        // DNI Checksum
        $dni = strtoupper(trim($data['dni'] ?? ''));
        if ($dni && !Utils::validar_dni($dni)) {
            $errors[] = 'El formato del DNI/NIE no es correcto.';
        }

        // Juvenile check: age must be <= 30
        $plan = $data['plan'] ?? '';
        $sub_plan = $data['sub_plan'] ?? '';
        $plan_key = (in_array($plan, ['familiar', 'juvenil'], true) && $sub_plan) ? $sub_plan : $plan;
        $plan_data = CPT_Miembro::get_plan($plan_key);

        if ($plan_data && !empty($fecha_nac)) {
            // Check if it's a juvenile modality or the plan name implies it
            $is_juvenil = (isset($plan_data['modalidad']) && $plan_data['modalidad'] === 'Juvenil') || $plan === 'juvenil' || strpos($plan_key, 'juv-') === 0;
            
            if ($is_juvenil) {
                $dob = new \DateTime($fecha_nac);
                $today = new \DateTime();
                $age = $today->diff($dob)->y;
                
                if ($age > 30) {
                    $errors[] = sprintf(
                        'La modalidad Juvenil está reservada para menores de 30 años (tienes %d años). Por favor, selecciona una modalidad de socio ordinario u otra que se ajuste a tu perfil.',
                        $age
                    );
                }
            }
        }

        // File check for transfer
        if (($data['forma_pago'] ?? '') === 'transferencia' && (empty($files['justificante']['name']))) {
            $errors[] = 'Para pago por transferencia es necesario adjuntar el justificante.';
        }

        if (!empty($errors)) {
            return new \WP_Error('validation_error', implode(' ', $errors));
        }

        return true;
    }
}
