<?php
/**
 * Certificate Generator - Generates PDF certificates for volunteers.
 * 
 * Requires Dompdf library ( LGPL license ).
 * Download: https://github.com/dompdf/dompdf/releases
 * Place dompdf folder in: biodevas-members/vendor/dompdf/
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class Certificate_Generator
{
    private static function load_dompdf()
    {
        $dompdf_path = BDV_MEMBERS_DIR . 'vendor/dompdf/autoload.php';
        
        if (file_exists($dompdf_path)) {
            require_once $dompdf_path;
            return true;
        }
        
        return false;
    }

    public static function generate(int $miembro_id): array|\WP_Error
    {
        $miembro = get_post($miembro_id);
        if (!$miembro || $miembro->post_type !== 'miembro') {
            return new \WP_Error('invalid_member', 'Miembro no encontrado');
        }

        $nombre = $miembro->post_title;
        $email = get_post_meta($miembro_id, '_bdv_email', true);
        $plan = get_post_meta($miembro_id, '_bdv_plan', true);
        $plan_label = CPT_Miembro::get_plan($plan)['label'] ?? $plan;

        $total_horas = Voluntariado_Manager::get_horas_aprobadas($miembro_id);
        $objetivo = Voluntariado_Manager::get_horas_objetivo($miembro_id);
        
        $proyectos = self::get_proyectos_con_horas($miembro_id);

        $cert_id = 'VOL-' . wp_date('Y') . '-' . strtoupper(wp_generate_password(5, false, false));
        
        update_post_meta($miembro_id, '_bdv_certificado_id', $cert_id);
        update_post_meta($miembro_id, '_bdv_certificado_emitido', current_time('mysql'));

        $verify_url = home_url('/verificar-certificado/?id=' . $cert_id);
        $qr_data = self::generate_qr_data($verify_url);

        $html = self::build_html($nombre, $total_horas, $plan_label, $proyectos, $cert_id, $qr_data, $verify_url);
        
        $pdf_content = self::render_pdf($html);
        
        if (is_wp_error($pdf_content)) {
            return $pdf_content;
        }

        return [
            'id' => $cert_id,
            'pdf' => $pdf_content,
            'nombre' => $nombre,
            'horas' => $total_horas,
            'plan' => $plan_label,
            'fecha' => current_time('mysql'),
            'url' => $verify_url,
        ];
    }

    private static function get_proyectos_con_horas(int $miembro_id): array
    {
        global $wpdb;

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_content, 
                    SUM(CAST(hm.meta_value AS DECIMAL(10,2))) as horas
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} ph ON ph.post_id = p.ID AND ph.meta_key = '_bdv_proyecto_id'
             INNER JOIN {$wpdb->postmeta} hm ON hm.post_id = p.ID AND hm.meta_key = '_bdv_horas'
             INNER JOIN {$wpdb->postmeta} he ON he.post_id = p.ID AND he.meta_key = '_bdv_estado' AND he.meta_value = 'aprobada'
             INNER JOIN {$wpdb->postmeta} hm2 ON hm2.post_id = p.ID AND hm2.meta_key = '_bdv_miembro_id' AND hm2.meta_value = %d
             WHERE p.post_type = 'registro_hora'
             GROUP BY p.ID
             ORDER BY horas DESC",
            $miembro_id
        ), ARRAY_A);

        $proyectos = [];
        foreach ($results as $r) {
            $proyecto_id = get_post_meta($r['ID'], '_bdv_proyecto_id', true);
            $proyecto = $proyecto_id ? get_post($proyecto_id) : null;
            $tareas = get_post_meta($r['ID'], '_bdv_tareas', true);
            $fecha = get_post_meta($r['ID'], '_bdv_fecha', true);
            
            if ($proyecto) {
                if (!isset($proyectos[$proyecto->ID])) {
                    $proyectos[$proyecto->ID] = [
                        'titulo' => $proyecto->post_title,
                        'horas' => 0,
                        'tareas' => [],
                        'fechas' => [],
                    ];
                }
                $proyectos[$proyecto->ID]['horas'] += (float) $r['horas'];
                if ($tareas) {
                    $proyectos[$proyecto->ID]['tareas'][] = $tareas;
                }
                if ($fecha) {
                    $proyectos[$proyecto->ID]['fechas'][] = $fecha;
                }
            }
        }

        return array_values($proyectos);
    }

    private static function generate_qr_data(string $url): string
    {
        return $url;
    }

    private static function build_html(string $nombre, float $horas, string $plan, array $proyectos, string $cert_id, string $qr_data, string $verify_url): string
    {
        $proyectos_html = '';
        foreach ($proyectos as $p) {
            $tareas_resumen = !empty($p['tareas']) ? implode('. ', array_map('substr', $p['tareas'], array_fill(0, count($p['tareas']), 0), array_fill(0, count($p['tareas']), 60))) : 'Sin descripción';
            $proyectos_html .= '<div class="proyecto"><strong>' . esc_html($p['titulo']) . '</strong>: ' . number_format($p['horas'], 1) . 'h<br><small>' . esc_html(mb_substr($tareas_resumen, 0, 100)) . '</small></div>';
        }

        return '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; color: #333; }
        .certificado { border: 3px solid #2d5a27; padding: 40px; max-width: 800px; margin: 0 auto; background: #f9fff9; }
        .header { text-align: center; border-bottom: 2px solid #2d5a27; padding-bottom: 20px; margin-bottom: 30px; }
        .logo { font-size: 48px; }
        h1 { color: #2d5a27; margin: 10px 0; }
        .contenido { font-size: 18px; line-height: 1.8; }
        .nombre { font-size: 24px; font-weight: bold; color: #1a3a15; }
        .horas { font-size: 20px; color: #2d5a27; font-weight: bold; }
        .proyectos { margin: 20px 0; padding: 15px; background: #e8f5e9; border-radius: 8px; }
        .proyecto { margin: 10px 0; }
        .footer { margin-top: 40px; text-align: center; border-top: 1px solid #ccc; padding-top: 20px; }
        .qr { margin: 20px auto; width: 120px; height: 120px; background: #2d5a27; color: white; display: flex; align-items: center; justify-content: center; font-size: 10px; }
        .cert-id { font-size: 12px; color: #666; }
    </style>
</head>
<body>
    <div class="certificado">
        <div class="header">
            <div class="logo">🌿</div>
            <h1>Certificado de Voluntariado</h1>
            <p>Asociación Biodevas</p>
        </div>
        <div class="contenido">
            <p>Certificamos que <span class="nombre">' . esc_html($nombre) . '</span></p>
            <p>ha completado un total de <span class="horas">' . number_format($horas, 1) . ' horas</span> de voluntariado</p>
            <p>como parte del plan <strong>' . esc_html($plan) . '</strong></p>
            
            <h3>ProyectosParticipados</h3>
            <div class="proyectos">' . $proyectos_html . '</div>
        </div>
        <div class="footer">
            <p>Fecha de emisión: ' . wp_date('d/m/Y') . '</p>
            <p class="cert-id">ID: ' . esc_html($cert_id) . '</p>
            <div class="qr">QR</div>
            <p><small>Verificar en: ' . esc_html($verify_url) . '</small></p>
        </div>
    </div>
</body>
</html>';
    }

    private static function render_pdf(string $html): string|\WP_Error
    {
        if (!self::load_dompdf()) {
            return new \WP_Error('dompdf_missing', 'Librería Dompdf no encontrada. Por favor, descarga Dompdf y colócala en vendor/dompdf/');
        }

        try {
            $dompdf = new \Dompdf\Dompdf();
            $dompdf->loadHtml($html);
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();
            
            return $dompdf->output();
        } catch (\Exception $e) {
            return new \WP_Error('pdf_error', 'Error al generar PDF: ' . $e->getMessage());
        }
    }

    public static function serve_pdf(int $miembro_id): void
    {
        $cert_id = get_post_meta($miembro_id, '_bdv_certificado_id', true);
        
        if (!$cert_id) {
            $result = self::generate($miembro_id);
            if (is_wp_error($result)) {
                wp_die($result->get_error_message());
            }
            $cert_id = $result['id'];
        }

        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="certificado-' . $cert_id . '.pdf"');
        
        $result = self::generate($miembro_id);
        if (!is_wp_error($result)) {
            echo $result['pdf'];
        }
        exit;
    }

    public static function verify(string $cert_id): ?array
    {
        global $wpdb;
        
        $miembro_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_bdv_certificado_id' AND meta_value = %s LIMIT 1",
            $cert_id
        ));

        if (!$miembro_id) {
            return null;
        }

        $miembro = get_post($miembro_id);
        
        return [
            'nombre' => $miembro->post_title,
            'horas' => Voluntariado_Manager::get_horas_aprobadas($miembro_id),
            'certificado_id' => $cert_id,
            'emitido' => get_post_meta($miembro_id, '_bdv_certificado_emitido', true),
        ];
    }
}