<?php
/**
 * Email template system with dynamic variables.
 *
 * Templates stored in wp_options, editable via admin.
 * Uses wp_mail() — SMTP configured externally.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class Email_Manager
{

    /** Option key for templates. */
    private const OPTION = 'bdv_email_templates';

    /** Available template slugs. */
    public const TEMPLATES = [
        'solicitud_recibida',
        'bienvenida',
        'recordatorio_pago',
        'pago_pendiente_2',
        'pago_pendiente_ultimo',
        'renovacion', // 30d
        'renovacion_15d',
        'renovacion_7d',
        'renovacion_automatica',
        'renovacion_completada',
        'voluntariado_recordatorio',
        'objetivo_voluntariado_completado',
    ];

    /** Available variables for templates. */
    public const VARIABLES = [
        '{nombre}',
        '{email}',
        '{tipo_miembro}',
        '{plan}',
        '{cuota}',
        '{importe}',
        '{estado}',
        '{numero_socio}',
        '{fecha_alta}',
        '{fecha_renovacion}',
        '{fecha_baja}',
        '{link_pago}',
        '{horas_actuales}',
        '{horas_objetivo}',
        '{porcentaje_cumplimiento}',
        '{horas_totales}',
        '{plan_nombre}',
        '{proyectos_participados}',
        '{certificado_id}',
        '{certificado_url_verificacion}',
    ];

    public function __construct()
    {
        // New standard hooks
        add_action('biodevas_members_email_solicitud', [$this, 'send_solicitud']);
        add_action('biodevas_members_email_bienvenida', [$this, 'send_bienvenida']);
        add_action('biodevas_members_email_recordatorio_pago', [$this, 'send_recordatorio_pago'], 10, 2);
        add_action('biodevas_members_email_renovacion', [$this, 'send_renovacion']);
        add_action('biodevas_members_email_renovacion_automatica', [$this, 'send_renovacion_automatica'], 10, 2);
        add_action('biodevas_members_email_renovacion_completada', [$this, 'send_renovacion_completada']);
        add_action('biodevas_members_email_objetivo_voluntariado', [$this, 'send_objetivo_voluntariado']);

        // Legacy hooks (for compatibility)
        add_action('biodevas_email_solicitud', [$this, 'send_solicitud']);
        add_action('biodevas_email_bienvenida', [$this, 'send_bienvenida']);
        add_action('biodevas_email_recordatorio_pago', [$this, 'send_recordatorio_pago'], 10, 2);
        add_action('biodevas_email_renovacion', [$this, 'send_renovacion']);
        add_action('biodevas_email_renovacion_automatica', [$this, 'send_renovacion_automatica'], 10, 2);
        add_action('biodevas_email_renovacion_completada', [$this, 'send_renovacion_completada']);
        add_action('biodevas_email_objetivo_voluntariado', [$this, 'send_objetivo_voluntariado']);
    }

    /* ── Default templates (installed on activation) ───── */

    public static function install_defaults(): void
    {
        if (false !== get_option(self::OPTION)) {
            return;
        }

        $defaults = [
            'solicitud_recibida' => [
                'subject' => 'Hemos recibido tu solicitud — Biodevas',
                'body' => "Hola {nombre},\n\nHemos recibido correctamente tu solicitud como {tipo_miembro} en Biodevas.\n\nPlan seleccionado: {plan}\nCuota: {cuota}\n\nUn miembro del equipo revisará tu solicitud y te contactará pronto.\n\n¡Gracias por unirte a la familia Biodevas!\n\n— Equipo Biodevas",
            ],
            'bienvenida' => [
                'subject' => '¡Bienvenido/a a Biodevas, {nombre}!',
                'body' => "Hola {nombre},\n\nTu alta como {tipo_miembro} ha sido confirmada. 🎉\n\nNº Socio: {numero_socio}\nPlan: {plan}\nEstado: {estado}\n\nYa formas parte de la comunidad Biodevas. Puedes participar en todas nuestras actividades y proyectos.\n\nSi tienes cualquier duda, escríbenos a coordinacion@biodevas.org.\n\n¡Nos vemos en el campo!\n\n— Equipo Biodevas",
            ],
            'recordatorio_pago' => [
                'subject' => 'Recordatorio de pago (1/3) — Biodevas',
                'body' => "Hola {nombre},\n\nTu solicitud de alta/renovación como {tipo_miembro} está pendiente de pago.\n\nPlan: {plan}\nImporte: {importe}€\n\nPuedes realizar el pago de forma segura en el siguiente enlace:\n{link_pago}\n\nSi ya has realizado el pago, ignora este mensaje.\n\n— Equipo Biodevas",
            ],
            'pago_pendiente_2' => [
                'subject' => 'Segundo aviso: pago pendiente — Biodevas',
                'body' => "Hola {nombre},\n\nSeguimos sin constancia del pago de tu cuota de {tipo_miembro}.\n\nImporte: {importe}€\nEnlace de pago: {link_pago}\n\nEs importante completar el pago para mantener tu estado activo y acceder a las ventajas de socio.\n\n— Equipo Biodevas",
            ],
            'pago_pendiente_ultimo' => [
                'subject' => 'Último aviso: suspensión inminente — Biodevas',
                'body' => "Hola {nombre},\n\nEste es el último aviso respecto a tu cuota pendiente.\n\nSi no recibimos el pago en los próximos días, tu cuenta será suspendida automáticamente.\n\nEnlace de pago: {link_pago}\n\n— Equipo Biodevas",
            ],
            'renovacion' => [
                'subject' => 'Tu renovación en Biodevas (30 días) — Biodevas',
                'body' => "Hola {nombre},\n\nFaltan 30 días para tu fecha de renovación como {tipo_miembro}.\n\nPlan actual: {plan}\nCuota: {cuota}\nFecha renovación: {fecha_renovacion}\n\nPara renovar, puedes usar este enlace:\n{link_pago}\n\n¡Gracias por seguir con nosotros!\n\n— Equipo Biodevas",
            ],
            'renovacion_15d' => [
                'subject' => 'Tu renovación en Biodevas (15 días) — Biodevas',
                'body' => "Hola {nombre},\n\nFaltan solo 15 días para que venza tu membresía de {tipo_miembro}.\n\nRecuerda renovar para no perder tu antigüedad y beneficios.\n\nEnlace de renovación:\n{link_pago}\n\n— Equipo Biodevas",
            ],
            'renovacion_7d' => [
                'subject' => 'Última semana para tu renovación — Biodevas',
                'body' => "Hola {nombre},\n\nTu membresía de {tipo_miembro} vencerá en 7 días.\n\nEvita la suspensión automática realizando el pago aquí:\n{link_pago}\n\n— Equipo Biodevas",
            ],
            'renovacion_automatica' => [
                'subject' => 'Procesando tu renovación automática — Biodevas',
                'body' => "Hola {nombre},\n\nComo tienes activada la renovación automática, hemos generado el cargo correspondiente a tu cuota de {tipo_miembro}.\n\nPlan: {plan}\nImporte: {importe}€\nNueva fecha de renovación estimada: {fecha_renovacion} (tras el pago)\n\nNo tienes que hacer nada. Si hay algún problema con el cargo, te avisaremos.\n\n¡Gracias por seguir apoyando a Biodevas!\n\n— Equipo Biodevas",
            ],
            'renovacion_completada' => [
                'subject' => 'Renovación completada con éxito — Biodevas',
                'body' => "Hola {nombre},\n\n¡Buenas noticias! El pago de tu cuota anual como {tipo_miembro} se ha procesado correctamente.\n\nTu membresía ha sido renovada hasta el {fecha_renovacion}.\n\nAdjunto a este email encontrarás tu tarjeta de socio/a actualizada.\n\n¡Gracias por tu compromiso con la naturaleza!\n\n— Equipo Biodevas",
            ],
            'voluntariado_recordatorio' => [
                'subject' => 'Recuerda tus horas de voluntariado — Biodevas',
                'body' => "Hola {nombre},\n\nTe escribimos para recordarte tu compromiso de voluntariado con Biodevas.\n\nActualmente llevas registradas {horas_actuales}h de un objetivo anual de {horas_objetivo}h.\n\nProgreso: {porcentaje_cumplimiento}%\n\nSi tienes horas pendientes de registrar, puedes hacerlo desde tu panel de socio.\n\n¡Tus manos son fundamentales para la asociación!\n\n— Equipo Biodevas",
            ],
            'objetivo_voluntariado_completado' => [
                'subject' => '🎉 ¡Felicidades! Has completado tu voluntariado — Biodevas',
                'body' => "Hola {nombre},\n\n¡Enhorabuena! Has completado las {horas_totales} horas de voluntariado requeridas para el plan {plan_nombre}.\n\nTus horas de voluntariado han sido contabilizadas y ahora formas parte activa de la comunidad de Biodevas.\n\nDetalles:\n- Horas completadas: {horas_totales}h\n- Plan: {plan_nombre}\n- Proyectos en los que has participado: {proyectos_participados}\n\nYa puedes descargar tu certificado oficial de voluntariado:\n{certificado_url_verificacion}\n\nID del certificado: {certificado_id}\n\n¡Gracias por tu dedicación y apoyo a la naturaleza!\n\n— Equipo Biodevas",
            ],
        ];

        update_option(self::OPTION, $defaults);
    }

    /* ── Send methods ──────────────────────────────────── */

    public function send_solicitud(int $post_id): void
    {
        $this->send('solicitud_recibida', $post_id);
    }

    public function send_bienvenida(int $post_id): void
    {
        $this->send('bienvenida', $post_id);
    }

    /**
     * Send payment reminder.
     * @param int $post_id Member ID.
     * @param array $args Optional args (link_pago).
     */
    public function send_recordatorio_pago(int $post_id, array $args = []): void
    {
        $this->send('recordatorio_pago', $post_id, $args);
    }

    public function send_renovacion(int $post_id, array $args = []): void
    {
        $this->send('renovacion', $post_id, $args);
    }

    public function send_renovacion_automatica(int $post_id, array $args = []): void
    {
        $this->send('renovacion_automatica', $post_id, $args);
    }

    public function send_renovacion_completada(int $post_id): void
    {
        $this->send('renovacion_completada', $post_id);
    }

    public function send_objetivo_voluntariado(int $post_id): void
    {
        $this->send('objetivo_voluntariado_completado', $post_id);
    }

    /* ── Core send logic ───────────────────────────────── */

    private function send(string $template_slug, int $post_id, array $extra_vars = []): void
    {
        $templates = get_option(self::OPTION, []);
        $tpl = $templates[$template_slug] ?? null;

        if (!$tpl) {
            return;
        }

        $email = get_post_meta($post_id, '_bdv_email', true) ?: get_the_author_meta('user_email', get_post_field('post_author', $post_id));
        if (empty($email)) {
            return;
        }

        // The title stores: "Nombre Completo (email)"
        // But we also store email in meta, so let's gather vars.
        $vars = array_merge($this->build_variables($post_id), $extra_vars);

        $subject = $this->replace_vars($tpl['subject'], $vars);
        $body = $this->replace_vars($tpl['body'], $vars);

        $headers = ['Content-Type: text/plain; charset=UTF-8'];

        // Get Sender Name from settings
        $settings = get_option('bdv_members_settings', []);
        $sender_name = $settings['sender_name'] ?? get_bloginfo('name');
        $admin_email = $settings['admin_email'] ?? get_option('admin_email');

        $headers[] = 'From: ' . $sender_name . ' <' . $admin_email . '>';

        wp_mail($email, $subject, $body, $headers);

        // Update tracking and Audit Log
        $now = current_time('mysql');
        update_post_meta($post_id, '_bdv_ultimo_contacto_email', $now);
        update_post_meta($post_id, '_bdv_ultimo_contacto', $now);

        \Biodevas\Common\Logger::info(
            sprintf(__('Email enviado: %s', 'biodevas-members'), $subject),
            'Members/Emails',
            $post_id
        );

        // Also notify admin (only for specific types or always? User didn't specify, but existing code did).
        // Let's keep it for application/welcome/etc but maybe not general reminders to avoid spam?
        if ($template_slug === 'solicitud_recibida') {
            wp_mail(
                $admin_email,
                '[Biodevas] ' . $subject,
                "Notificación automática — Miembro: {$vars['{nombre}']}\n\n" . $body,
                $headers
            );
        }
    }

    /**
     * Build variable replacements from post meta.
     */
    private function build_variables(int $post_id): array
    {
        $meta = fn(string $key) => get_post_meta($post_id, '_bdv_' . $key, true);

        $plan_key = $meta('plan') ?: $meta('sub_plan');
        $plan_data = CPT_Miembro::get_plan($plan_key);

        $forma = $meta('forma_pago');
        $importe_custom = $meta('importe_cuota');

        if ($forma === 'voluntariado' && $plan_data) {
            $cuota = $plan_data['hours'] . 'h voluntariado';
            $importe = 0;
        } elseif ($plan_data) {
            $cuota = $plan_data['price'] . '€/año';
            $importe = $plan_data['price'];
        } else {
            $cuota = '—';
            $importe = 0;
        }

        // Override if custom amount is set and different (legacy)
        if ($importe_custom && $importe_custom != $importe) {
            $importe = $importe_custom;
            $cuota = $importe . '€/año';
        }

        $terms = wp_get_object_terms($post_id, 'tipo_miembro', ['fields' => 'names']);
        $tipo_label = is_array($terms) && !empty($terms) ? $terms[0] : '—';

        $estado = $meta('estado_miembro');
        $estado_label = Estados::LABELS[$estado] ?? $estado;

        // Voluntariado data (resolved here so all templates can use them).
        $horas_aprobadas = Voluntariado_Manager::get_horas_aprobadas($post_id);
        $horas_objetivo = Voluntariado_Manager::get_horas_objetivo($post_id);
        $porcentaje = $horas_objetivo > 0 ? min(100, round(($horas_aprobadas / $horas_objetivo) * 100)) : 0;

        // Projects participated (for certificate email).
        $proyectos = '';
        $proyecto_ids = get_posts([
            'post_type' => 'registro_hora',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => [
                ['key' => '_bdv_miembro_id', 'value' => $post_id],
                ['key' => '_bdv_estado', 'value' => 'aprobada'],
            ],
        ]);
        if (!empty($proyecto_ids)) {
            $nombres_proyecto = [];
            foreach ($proyecto_ids as $pid) {
                $proy_id = get_post_meta($pid, '_bdv_proyecto_id', true);
                if ($proy_id && ($titulo = get_the_title($proy_id))) {
                    $nombres_proyecto[$proy_id] = $titulo;
                }
            }
            $proyectos = implode(', ', array_unique($nombres_proyecto)) ?: '—';
        }

        $certificado_id = $meta('certificado_id') ?: '—';

        return [
            '{nombre}' => get_the_title($post_id),
            '{email}' => $meta('email') ?: '—',
            '{tipo_miembro}' => $tipo_label,
            '{plan}' => $plan_data['label'] ?? ucfirst($plan_key ?: '—'),
            '{cuota}' => $cuota,
            '{importe}' => $importe,
            '{estado}' => $estado_label,
            '{numero_socio}' => $meta('numero_socio') ?: '—',
            '{fecha_alta}' => get_the_date('d/m/Y', $post_id),
            '{fecha_renovacion}' => $meta('fecha_renovacion') ?: '—',
            '{fecha_baja}' => $meta('fecha_baja') ?: '—',
            '{link_pago}' => '', // Default empty, usually injected via extra_vars
            // Voluntariado variables
            '{horas_actuales}' => $horas_aprobadas,
            '{horas_objetivo}' => $horas_objetivo,
            '{porcentaje_cumplimiento}' => $porcentaje,
            '{horas_totales}' => $horas_aprobadas,
            '{plan_nombre}' => $plan_data['label'] ?? ucfirst($plan_key ?: '—'),
            '{proyectos_participados}' => $proyectos ?: '—',
            '{certificado_id}' => $certificado_id,
            '{certificado_url_verificacion}' => $certificado_id !== '—'
                ? rest_url('biodevas/v1/me/certificate')
                : '—',
        ];
    }

    /**
     * Replace template variables.
     */
    private function replace_vars(string $text, array $vars): string
    {
        return str_replace(array_keys($vars), array_values($vars), $text);
    }

    /* ── Getters / Setters for admin ───────────────────── */

    public static function get_templates(): array
    {
        return get_option(self::OPTION, []);
    }

    public static function save_templates(array $templates): void
    {
        update_option(self::OPTION, $templates);
    }
}
