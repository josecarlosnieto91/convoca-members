<?php
/**
 * Custom Post Type for Documents (Volunteers).
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class CPT_Documento
{
    public function __construct()
    {
        add_action('init', [$this, 'register_cpt']);
        add_filter('map_meta_cap', [$this, 'map_documento_caps'], 10, 4);
    }

    public function register_cpt(): void
    {
        $labels = [
            'name'                  => _x('Documentos', 'Post Type General Name', 'biodevas-members'),
            'singular_name'         => _x('Documento', 'Post Type Singular Name', 'biodevas-members'),
            'menu_name'             => __('Documentos', 'biodevas-members'),
            'name_admin_bar'        => __('Documento', 'biodevas-members'),
            'archives'              => __('Archivo de documentos', 'biodevas-members'),
            'attributes'            => __('Atributos del documento', 'biodevas-members'),
            'parent_item_colon'     => __('Documento superior:', 'biodevas-members'),
            'all_items'             => __('Todos los documentos', 'biodevas-members'),
            'add_new_item'          => __('Añadir nuevo documento', 'biodevas-members'),
            'add_new'               => __('Añadir nuevo', 'biodevas-members'),
            'new_item'              => __('Nuevo documento', 'biodevas-members'),
            'edit_item'             => __('Editar documento', 'biodevas-members'),
            'update_item'           => __('Actualizar documento', 'biodevas-members'),
            'view_item'             => __('Ver documento', 'biodevas-members'),
            'view_items'            => __('Ver documentos', 'biodevas-members'),
            'search_items'          => __('Buscar documento', 'biodevas-members'),
            'not_found'             => __('No encontrado', 'biodevas-members'),
            'not_found_in_trash'    => __('No encontrado en la papelera', 'biodevas-members'),
        ];
        
        $args = [
            'label'                 => __('Documento', 'biodevas-members'),
            'description'           => __('Documentos generados como el Acuerdo de Incorporación.', 'biodevas-members'),
            'labels'                => $labels,
            'supports'              => ['title', 'author', 'custom-fields'],
            'hierarchical'          => false,
            'public'                => false, // Only accessible via code/admin
            'show_ui'               => true,
            'show_in_menu'          => 'edit.php?post_type=miembro', // Under Members menu
            'show_in_admin_bar'     => false,
            'show_in_nav_menus'     => false,
            'can_export'            => true,
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => false,
            'capability_type'       => 'bdv_documento',
            'map_meta_cap'          => true,
        ];
        
        register_post_type('bdv_documento', $args);
    }

    /**
     * Map capabilities to 'gestionar_documentos_voluntariado'
     */
    public function map_documento_caps($caps, $cap, $user_id, $args)
    {
        $documento_caps = [
            'edit_bdv_documento',
            'read_bdv_documento',
            'delete_bdv_documento',
            'edit_bdv_documentos',
            'edit_others_bdv_documentos',
            'publish_bdv_documentos',
            'read_private_bdv_documentos',
        ];

        if (in_array($cap, $documento_caps)) {
            $caps = ['gestionar_documentos_voluntariado'];
        }

        return $caps;
    }
}
