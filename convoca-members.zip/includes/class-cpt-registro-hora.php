<?php
/**
 * Custom Post Type: registro_hora for volunteering hours tracking.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class CPT_Registro_Hora
{
    public const POST_TYPE = 'registro_hora';

    /** Meta keys for registro_hora records. */
    public const META_KEYS = [
        'miembro_id',
        'fecha',
        'horas',
        'actividad_id',
        'estado',
        'aprobada_por',
        'proyecto_id',
        'tareas',
    ];

    /**
     * Register the CPT.
     */
    public static function register(): void
    {
        $labels = [
            'name'                  => _x('Registros de Horas', 'Post Type General Name', 'biodevas-members'),
            'singular_name'         => _x('Registro de Hora', 'Post Type Singular Name', 'biodevas-members'),
            'menu_name'             => __('Horas Voluntariado', 'biodevas-members'),
            'name_admin_bar'        => __('Registro de Hora', 'biodevas-members'),
            'archives'              => __('Archivo de Registros', 'biodevas-members'),
            'attributes'            => __('Atributos de Registro', 'biodevas-members'),
            'parent_item_colon'     => __('Registro Padre:', 'biodevas-members'),
            'all_items'             => __('Todos los Registros', 'biodevas-members'),
            'add_new_item'          => __('Añadir Nuevo Registro', 'biodevas-members'),
            'add_new'               => __('Añadir Nuevo', 'biodevas-members'),
            'new_item'              => __('Nuevo Registro', 'biodevas-members'),
            'edit_item'             => __('Editar Registro', 'biodevas-members'),
            'update_item'           => __('Actualizar Registro', 'biodevas-members'),
            'view_item'             => __('Ver Registro', 'biodevas-members'),
            'view_items'            => __('Ver Registros', 'biodevas-members'),
            'search_items'          => __('Buscar Registro', 'biodevas-members'),
            'not_found'             => __('No encontrado', 'biodevas-members'),
            'not_found_in_trash'    => __('No encontrado en la papelera', 'biodevas-members'),
            'featured_image'        => __('Imagen Destacada', 'biodevas-members'),
            'set_featured_image'    => __('Establecer imagen destacada', 'biodevas-members'),
            'remove_featured_image' => __('Borrar imagen destacada', 'biodevas-members'),
            'use_featured_image'    => __('Usar como imagen destacada', 'biodevas-members'),
            'insert_into_item'      => __('Insertar en el registro', 'biodevas-members'),
            'uploaded_to_this_item' => __('Subido a este registro', 'biodevas-members'),
            'items_list'            => __('Lista de registros', 'biodevas-members'),
            'items_list_navigation' => __('Navegación de lista de registros', 'biodevas-members'),
            'filter_items_list'     => __('Filtrar lista de registros', 'biodevas-members'),
        ];

        $args = [
            'label'               => __('Registro de Hora', 'biodevas-members'),
            'description'         => __('Seguimiento de horas de voluntariado.', 'biodevas-members'),
            'labels'              => $labels,
            'supports'            => ['title', 'editor', 'author', 'revisions', 'custom-fields'],
            'hierarchical'        => false,
            'public'              => false,
            'show_ui'             => true,
            'show_in_menu'        => 'edit.php?post_type=miembro',
            'menu_position'       => 5,
            'show_in_admin_bar'   => true,
            'show_in_nav_menus'   => false,
            'can_export'          => true,
            'has_archive'         => false,
            'exclude_from_search' => true,
            'publicly_queryable'  => false,
            'capability_type'     => 'post',
            'show_in_rest'        => false,
        ];

        register_post_type(self::POST_TYPE, $args);
    }
}
