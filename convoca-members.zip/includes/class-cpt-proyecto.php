<?php
/**
 * Custom Post Type: proyecto for volunteer projects.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class CPT_Proyecto
{
    public const POST_TYPE = 'proyecto';

    /** Meta keys for proyecto records. */
    public const META_KEYS = [
        'fecha_inicio',
        'fecha_fin',
        'responsable',
        'activo',
    ];

    /**
     * Register the CPT.
     */
    public static function register(): void
    {
        $labels = [
            'name'                  => _x('Proyectos', 'Post Type General Name', 'biodevas-members'),
            'singular_name'         => _x('Proyecto', 'Post Type Singular Name', 'biodevas-members'),
            'menu_name'             => __('Proyectos', 'biodevas-members'),
            'name_admin_bar'        => __('Proyecto', 'biodevas-members'),
            'archives'              => __('Archivo de Proyectos', 'biodevas-members'),
            'attributes'            => __('Atributos de Proyecto', 'biodevas-members'),
            'parent_item_colon'     => __('Proyecto Padre:', 'biodevas-members'),
            'all_items'             => __('Todos los Proyectos', 'biodevas-members'),
            'add_new_item'          => __('Añadir Nuevo Proyecto', 'biodevas-members'),
            'add_new'               => __('Añadir Nuevo', 'biodevas-members'),
            'new_item'              => __('Nuevo Proyecto', 'biodevas-members'),
            'edit_item'             => __('Editar Proyecto', 'biodevas-members'),
            'update_item'           => __('Actualizar Proyecto', 'biodevas-members'),
            'view_item'             => __('Ver Proyecto', 'biodevas-members'),
            'view_items'            => __('Ver Proyectos', 'biodevas-members'),
            'search_items'          => __('Buscar Proyecto', 'biodevas-members'),
            'not_found'             => __('No encontrado', 'biodevas-members'),
            'not_found_in_trash'    => __('No encontrado en la papelera', 'biodevas-members'),
            'featured_image'        => __('Imagen Destacada', 'biodevas-members'),
            'set_featured_image'    => __('Establecer imagen destacada', 'biodevas-members'),
            'remove_featured_image' => __('Borrar imagen destacada', 'biodevas-members'),
            'use_featured_image'    => __('Usar como imagen destacada', 'biodevas-members'),
            'insert_into_item'      => __('Insertar en el proyecto', 'biodevas-members'),
            'uploaded_to_this_item' => __('Subido a este proyecto', 'biodevas-members'),
            'items_list'            => __('Lista de proyectos', 'biodevas-members'),
            'items_list_navigation' => __('Navegación de lista de proyectos', 'biodevas-members'),
            'filter_items_list'     => __('Filtrar lista de proyectos', 'biodevas-members'),
        ];

        $args = [
            'label'               => __('Proyecto', 'biodevas-members'),
            'description'         => __('Proyectos de voluntariado.', 'biodevas-members'),
            'labels'              => $labels,
            'supports'            => ['title', 'editor', 'author', 'revisions'],
            'hierarchical'        => false,
            'public'              => false,
            'show_ui'             => true,
            'show_in_menu'        => 'edit.php?post_type=miembro',
            'menu_position'       => 6,
            'show_in_admin_bar'   => true,
            'show_in_nav_menus'   => false,
            'can_export'          => true,
            'has_archive'         => false,
            'exclude_from_search' => true,
            'publicly_queryable'  => false,
            'capability_type'     => 'post',
            'show_in_rest'        => false,
        ];

        register_post_type(self::POST_TYPE, $args);
    }

    /**
     * Get meta data for a proyecto.
     */
    public static function get_meta(int $post_id): array
    {
        $data = [];
        foreach (self::META_KEYS as $key) {
            $data[$key] = get_post_meta($post_id, '_bdv_' . $key, true);
        }
        return $data;
    }

    /**
     * Get all active proyectos for dropdown select.
     */
    public static function get_active_proyectos(): array
    {
        $proyectos = get_posts([
            'post_type' => self::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);

        $result = [];
        $now = current_time('mysql');

        foreach ($proyectos as $p) {
            $meta = self::get_meta($p->ID);
            $fecha_fin = $meta['fecha_fin'] ?? '';

            if (!empty($fecha_fin) && $fecha_fin < $now) {
                continue;
            }

            $result[$p->ID] = $p->post_title;
        }

        return $result;
    }

    /**
     * Get proyectos where a member has participated.
     */
    public static function get_proyectos_by_member(int $miembro_id): array
    {
        global $wpdb;

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT DISTINCT pm.post_id as proyecto_id, p.post_title, p.post_content
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             INNER JOIN {$wpdb->postmeta} ph ON ph.post_id = pm.post_id AND ph.meta_key = '_bdv_miembro_id' AND ph.meta_value = %d
             WHERE pm.meta_key = '_bdv_proyecto_id'
             AND pm.meta_value = p.ID
             AND p.post_type = %s
             AND p.post_status = 'publish'
             ORDER BY p.post_title ASC",
            $miembro_id,
            self::POST_TYPE
        ), ARRAY_A);

        $proyectos = [];
        foreach ($results as $r) {
            $proyectos[] = [
                'id' => $r['proyecto_id'],
                'titulo' => $r['post_title'],
                'descripcion' => $r['post_content'],
                'meta' => self::get_meta((int) $r['proyecto_id']),
            ];
        }

        return $proyectos;
    }

    /**
     * Render metabox for proyecto details.
     */
    public static function render_metabox(int $post_id): void
    {
        $meta = self::get_meta($post_id);
        ?>
        <div class="bdv-proyecto-metabox">
            <?php wp_nonce_field('bdv_save_proyecto', 'bdv_proyecto_nonce'); ?>
            <p>
                <label for="bdv_fecha_inicio"><?php esc_html_e('Fecha de inicio:', 'biodevas-members'); ?></label>
                <input type="date" id="bdv_fecha_inicio" name="bdv_fecha_inicio" 
                       value="<?php echo esc_attr($meta['fecha_inicio'] ?? ''); ?>" class="widefat">
            </p>
            <p>
                <label for="bdv_fecha_fin"><?php esc_html_e('Fecha de fin:', 'biodevas-members'); ?></label>
                <input type="date" id="bdv_fecha_fin" name="bdv_fecha_fin" 
                       value="<?php echo esc_attr($meta['fecha_fin'] ?? ''); ?>" class="widefat">
            </p>
            <p>
                <label for="bdv_responsable"><?php esc_html_e('Responsable:', 'biodevas-members'); ?></label>
                <select id="bdv_responsable" name="bdv_responsable" class="widefat">
                    <option value=""><?php esc_html_e('— Seleccionar —', 'biodevas-members'); ?></option>
                    <?php
                    $users = get_users(['role__in' => ['administrator', 'editor']]);
                    foreach ($users as $user) {
                        echo '<option value="' . esc_attr($user->ID) . '"' . 
                             selected($meta['responsable'] ?? '', $user->ID, false) . '>' .
                             esc_html($user->display_name) . '</option>';
                    }
                    ?>
                </select>
            </p>
            <p>
                <label>
                    <input type="checkbox" name="bdv_activo" value="1" 
                           <?php checked($meta['activo'] ?? '', '1'); ?>>
                    <?php esc_html_e('Proyecto activo (visible para voluntarios)', 'biodevas-members'); ?>
                </label>
            </p>
        </div>
        <?php
    }

    /**
     * Save metabox data.
     */
    public static function save_metabox(int $post_id): void
    {
        if (get_post_type($post_id) !== self::POST_TYPE) {
            return;
        }

        if (!isset($_POST['bdv_proyecto_nonce']) || !wp_verify_nonce($_POST['bdv_proyecto_nonce'], 'bdv_save_proyecto')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        update_post_meta($post_id, '_bdv_fecha_inicio', sanitize_text_field($_POST['bdv_fecha_inicio'] ?? ''));
        update_post_meta($post_id, '_bdv_fecha_fin', sanitize_text_field($_POST['bdv_fecha_fin'] ?? ''));
        update_post_meta($post_id, '_bdv_responsable', sanitize_text_field($_POST['bdv_responsable'] ?? ''));
        update_post_meta($post_id, '_bdv_activo', !empty($_POST['bdv_activo']) ? '1' : '0');
    }
}