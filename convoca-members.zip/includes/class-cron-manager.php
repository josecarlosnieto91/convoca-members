<?php
/**
 * Cron jobs for notifications, reminders, and automated renewals.
 *
 * Handles:
 * - Escalated payment reminders (3d, 7d, 14d)
 * - Escalated renewal notices (30d, 15d, 7d)
 * - Volunteer hour reminders (quarterly)
 * - Automatic recurrent renewals
 * - Member expiration processing
 * - Admin weekly digest
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

use Biodevas\Gateway\CPT_Pago;
use Biodevas\Gateway\Payment_Handler;

if (!defined('ABSPATH')) {
    exit;
}

class Cron_Manager
{
    /** Meta key to track last reminder sent. */
    private const META_LAST_REMINDER = '_bdv_last_reminder';

    /** Meta key to track last renewal notice sent. */
    private const META_LAST_RENEWAL_NOTICE = '_bdv_last_renewal_notice';

    /** Meta key to track volunteer reminder quarter. */
    private const META_VOLUNTARIADO_REMINDER_Q = '_bdv_voluntariado_reminder_q';

    public function __construct()
    {
        // Daily cron
        add_action('bdv_daily_event', [$this, 'run_daily']);

        // Weekly cron (admin digest)
        add_action('bdv_weekly_event', [$this, 'run_weekly']);
    }

    /**
     * Daily check for payments pending, renewals, or expirations.
     */
    public function run_daily(): void
    {
        $this->process_pending_payments();
        $this->process_renewals();
        $this->process_automatic_renewals();
        $this->process_expirations();
        $this->process_volunteer_reminders();
    }

    /**
     * Weekly tasks: admin digest.
     */
    public function run_weekly(): void
    {
        $this->send_admin_digest();
    }

    /* ── Escalated Payment Reminders (3d, 7d, 14d) ─────────── */

    /**
     * Remind users with 'pendiente_pago' status at escalating intervals.
     * - Day 3: First reminder (recordatorio_pago)
     * - Day 7: Second reminder (pago_pendiente_2)
     * - Day 14: Final warning (pago_pendiente_ultimo)
     */
    private function process_pending_payments(): void
    {
        // Limit to 50 members per cron run to avoid timeout
        $args = [
            'post_type'      => 'miembro',
            'meta_query'     => [
                [
                    'key'   => '_bdv_estado_miembro',
                    'value' => 'pendiente_pago',
                ],
            ],
            'posts_per_page' => 50,
            'fields'         => 'ids',
            'orderby'        => 'date',
            'order'          => 'ASC',
        ];

        $ids = get_posts($args);
        
        if (empty($ids)) {
            return;
        }

        $email_manager = new Email_Manager();

        foreach ($ids as $post_id) {
            // Use wp_date for consistent timezone handling
            $created_at = get_post_time('Y-m-d', true, $post_id);
            $today = current_time('Y-m-d');
            $days_diff = (int) floor((strtotime($today) - strtotime($created_at)) / DAY_IN_SECONDS);
            $last_sent  = get_post_meta($post_id, self::META_LAST_REMINDER, true);

            // Determine which reminder to send
            $template = null;
            $reminder_key = null;

            if ($days_diff >= 14 && $last_sent !== 'ultimo') {
                $template     = 'pago_pendiente_ultimo';
                $reminder_key = 'ultimo';
            } elseif ($days_diff >= 7 && !in_array($last_sent, ['segundo', 'ultimo'], true)) {
                $template     = 'pago_pendiente_2';
                $reminder_key = 'segundo';
            } elseif ($days_diff >= 3 && empty($last_sent)) {
                $template     = 'recordatorio_pago';
                $reminder_key = 'primero';
            }

            if ($template && $reminder_key) {
                $pago_id = (int) get_post_meta($post_id, '_bdv_pago_id', true);
                $link    = '';
                if ($pago_id) {
                    $link = $this->get_payment_link($pago_id);
                }

                // Send the escalated email
                $method = 'send_' . ($template === 'recordatorio_pago' ? 'recordatorio_pago' : $template);
                if (method_exists($email_manager, $method)) {
                    $email_manager->$method($post_id, ['{link_pago}' => $link]);
                } else {
                    // Generic send via the internal send method
                    $this->send_template_email($email_manager, $template, $post_id, ['{link_pago}' => $link]);
                }

                update_post_meta($post_id, self::META_LAST_REMINDER, $reminder_key);

                \Biodevas\Common\Logger::info(
                    "Recordatorio de pago escalonado ($reminder_key) enviado al miembro #$post_id (día $days_diff).",
                    'Members/Cron',
                    $post_id
                );

                // Fire webhook
                do_action('biodevas_members_payment_reminder_sent', $post_id, $reminder_key, $days_diff);
            }
        }
    }

    /* ── Escalated Renewal Reminders (30d, 15d, 7d) ────────── */

    /**
     * Handle renewal reminders at 30, 15, and 7 days before expiration.
     */
    private function process_renewals(): void
    {
        $email_manager = new Email_Manager();

        // Check each interval
        $intervals = [
            30 => 'renovacion',
            15 => 'renovacion_15d',
            7  => 'renovacion_7d',
        ];

        foreach ($intervals as $days => $template) {
            $target_date = wp_date('Y-m-d', strtotime("+{$days} days"));

            $args = [
                'post_type'      => 'miembro',
                'meta_query'     => [
                    [
                        'key'   => '_bdv_fecha_renovacion',
                        'value' => $target_date,
                    ],
                    [
                        'key'   => '_bdv_estado_miembro',
                        'value' => 'activo',
                    ],
                ],
                'posts_per_page' => 50,
                'fields'         => 'ids',
                'orderby'        => 'date',
                'order'          => 'ASC',
            ];

            $ids = get_posts($args);
            
            if (empty($ids)) {
                continue;
            }

            foreach ($ids as $post_id) {
                // Check if this notice was already sent
                $last_notice = get_post_meta($post_id, self::META_LAST_RENEWAL_NOTICE, true);
                if ($last_notice === (string) $days) {
                    continue;
                }

                $link = $this->get_renewal_link($post_id);

                // Use the specific send method
                $method = 'send_' . $template;
                if (method_exists($email_manager, $method)) {
                    $email_manager->$method($post_id, ['{link_pago}' => $link]);
                } else {
                    $this->send_template_email($email_manager, $template, $post_id, ['{link_pago}' => $link]);
                }

                update_post_meta($post_id, self::META_LAST_RENEWAL_NOTICE, (string) $days);

                \Biodevas\Common\Logger::info(
                    "Aviso de renovación ({$days}d) enviado al miembro #$post_id.",
                    'Members/Cron',
                    $post_id
                );

                // Fire webhook
                do_action('biodevas_members_renewal_reminder_sent', $post_id, $days);
            }
        }
    }

    /* ── Volunteer Hour Reminders (quarterly) ──────────────── */

    /**
     * Quarterly reminder for volunteers to log their hours.
     * Runs daily but checks if we're in a new quarter.
     */
    private function process_volunteer_reminders(): void
    {
        $current_quarter = 'Q' . ceil(wp_date('n') / 3) . '-' . wp_date('Y');
        $today_md        = wp_date('m-d');

        // Only send on the 1st of quarter months: Jan, Apr, Jul, Oct
        $quarter_starts = ['01-01', '04-01', '07-01', '10-01'];
        if (!in_array($today_md, $quarter_starts, true)) {
            return;
        }

        $args = [
            'post_type'      => 'miembro',
            'meta_query'     => [
                [
                    'key'   => '_bdv_estado_miembro',
                    'value' => 'activo',
                ],
                [
                    'key'   => '_bdv_forma_pago',
                    'value' => 'voluntariado',
                ],
            ],
            'posts_per_page' => 50,
            'fields'         => 'ids',
            'orderby'        => 'date',
            'order'          => 'ASC',
        ];

        $ids = get_posts($args);
        
        if (empty($ids)) {
            return;
        }
        
        $email_manager = new Email_Manager();

        foreach ($ids as $post_id) {
            // Check if already sent this quarter
            $last_q = get_post_meta($post_id, self::META_VOLUNTARIADO_REMINDER_Q, true);
            if ($last_q === $current_quarter) {
                continue;
            }

            // Calculate volunteer hours progress
            $horas_data    = $this->get_volunteer_hours_summary($post_id);
            $extra_vars    = [
                '{horas_actuales}'          => $horas_data['total'],
                '{horas_objetivo}'          => $horas_data['objetivo'],
                '{porcentaje_cumplimiento}' => $horas_data['porcentaje'],
            ];

            $this->send_template_email($email_manager, 'voluntariado_recordatorio', $post_id, $extra_vars);

            update_post_meta($post_id, self::META_VOLUNTARIADO_REMINDER_Q, $current_quarter);

            \Biodevas\Common\Logger::info(
                "Recordatorio de voluntariado ($current_quarter) enviado al miembro #$post_id. Progreso: {$horas_data['porcentaje']}%",
                'Members/Cron',
                $post_id
            );
        }
    }

    /* ── Automatic Renewals ────────────────────────────────── */

    /**
     * Process automatic renewals for members with recurrent payment enabled.
     */
    private function process_automatic_renewals(): void
    {
        global $wpdb;

        $today = current_time('Y-m-d');

        $query = "
            SELECT p.ID 
            FROM {$wpdb->posts} p
            JOIN {$wpdb->postmeta} pm_rec ON p.ID = pm_rec.post_id AND pm_rec.meta_key = '_bdv_pago_recurrente' AND pm_rec.meta_value = '1'
            JOIN {$wpdb->postmeta} pm_est ON p.ID = pm_est.post_id AND pm_est.meta_key = '_bdv_estado_miembro' AND pm_est.meta_value = 'activo'
            JOIN {$wpdb->postmeta} pm_ren ON p.ID = pm_ren.post_id AND pm_ren.meta_key = '_bdv_fecha_renovacion'
            WHERE p.post_type = 'miembro' 
              AND p.post_status = 'publish'
              AND pm_ren.meta_value <= %s
        ";

        $member_ids = $wpdb->get_col($wpdb->prepare($query, $today));

        if (empty($member_ids)) {
            return;
        }

        $email_manager = new Email_Manager();

        foreach ($member_ids as $member_id) {
            $member_id = (int) $member_id;

            // Avoid double processing: use transient to prevent same-day reprocessing
            $transient_key = 'bdv_auto_renewal_processed_' . $member_id . '_' . $today;
            if (get_transient($transient_key)) {
                continue;
            }

            $plan_key  = get_post_meta($member_id, '_bdv_plan', true) ?: get_post_meta($member_id, '_bdv_sub_plan', true);
            $plan_data = CPT_Miembro::get_plan($plan_key);

            if (!$plan_data || (float) $plan_data['price'] <= 0) {
                \Biodevas\Common\Logger::warning(
                    "Intento de renovación automática fallido: Plan no encontrado o importe 0 para el miembro #$member_id.",
                    'Members/Cron',
                    $member_id
                );
                continue;
            }

            // Create payment via Gateway
            if (!class_exists('Biodevas\\Gateway\\Payment_Handler')) {
                \Biodevas\Common\Logger::error(
                    "Gateway no disponible para renovación automática del miembro #$member_id.",
                    'Members/Cron',
                    $member_id
                );
                continue;
            }

            $pago_id = Payment_Handler::create_payment([
                'origin'      => 'members',
                'origin_id'   => $member_id,
                'amount_cents' => (int) round($plan_data['price'] * 100),
                'product_desc' => mb_substr('RENOVACIÓN BIODEVAS - ' . strtoupper($plan_data['label']), 0, 125),
                'method'      => 'tarjeta',
            ]);

            if (is_wp_error($pago_id)) {
                \Biodevas\Common\Logger::error(
                    "Error al generar renovación automática para el miembro #$member_id: " . $pago_id->get_error_message(),
                    'Members/Cron',
                    $member_id
                );
                
                // Notificar al socio que la renovación falló
                if (method_exists($email_manager, 'send_renovacion_fallida')) {
                    $email_manager->send_renovacion_fallida($member_id);
                }
                
                // Cambiar estado a pendiente_pago via state machine (triggers audit log)
                Estados::change($member_id, 'pendiente_pago', 'Renovación automática fallida - requerido pago manual');
                
                continue;
            }

            // Mark as processed via transient to prevent same-day reprocessing
            set_transient($transient_key, $pago_id, DAY_IN_SECONDS * 2);
            update_post_meta($member_id, '_bdv_last_auto_renewal', $today);
            update_post_meta($member_id, '_bdv_pago_id', $pago_id);

            \Biodevas\Common\Logger::info(
                "Procesando renovación automática para el miembro #$member_id (Pago: #$pago_id).",
                'Members/Cron',
                $member_id
            );

            $email_manager->send_renovacion_automatica($member_id);

            // Fire webhook
            do_action('biodevas_members_auto_renewal_created', $member_id, $pago_id);
        }
    }

    /* ── Expirations ───────────────────────────────────────── */

    /**
     * Check for expired members daily and update their status.
     */
    private function process_expirations(): void
    {
        global $wpdb;
        $today = current_time('Y-m-d');

        $query = "
            SELECT p.ID 
            FROM {$wpdb->posts} p
            JOIN {$wpdb->postmeta} pm_est ON p.ID = pm_est.post_id AND pm_est.meta_key = '_bdv_estado_miembro' AND pm_est.meta_value = 'activo'
            JOIN {$wpdb->postmeta} pm_ren ON p.ID = pm_ren.post_id AND pm_ren.meta_key = '_bdv_fecha_renovacion'
            WHERE p.post_type = 'miembro' 
              AND p.post_status = 'publish'
              AND pm_ren.meta_value < %s
        ";

        $member_ids = $wpdb->get_col($wpdb->prepare($query, $today));

        foreach ($member_ids as $member_id) {
            $member_id = (int) $member_id;
            CPT_Miembro::check_member_status($member_id);

            \Biodevas\Common\Logger::info(
                "Expiración procesada para el miembro #$member_id.",
                'Members/Cron',
                $member_id
            );

            // Fire webhook
            do_action('biodevas_members_membership_expired', $member_id);
        }
    }

    /* ── Admin Weekly Digest ───────────────────────────────── */

    /**
     * Send a weekly summary email to administrators.
     */
    private function send_admin_digest(): void
    {
        $settings    = get_option('bdv_members_settings', []);
        $admin_email = $settings['admin_email'] ?? get_option('admin_email');
        $sender_name = $settings['sender_name'] ?? get_bloginfo('name');

        // Gather stats
        $stats = $this->gather_weekly_stats();

        // Build email body
        $body = $this->build_digest_body($stats);

        $subject = sprintf(
            '[Biodevas] Resumen semanal — %s',
            wp_date('d/m/Y')
        );

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $sender_name . ' <' . $admin_email . '>',
        ];

        // Also send to extra admin emails if configured
        $extra_emails = $settings['digest_extra_emails'] ?? '';
        $recipients   = [$admin_email];
        if (!empty($extra_emails)) {
            $extras = array_map('trim', explode(',', $extra_emails));
            $recipients = array_merge($recipients, array_filter($extras, 'is_email'));
        }

        foreach ($recipients as $recipient) {
            wp_mail($recipient, $subject, $body, $headers);
        }

        \Biodevas\Common\Logger::info(
            'Resumen semanal enviado a: ' . implode(', ', $recipients),
            'Members/Cron'
        );
    }

    /**
     * Gather weekly statistics for the digest.
     */
    private function gather_weekly_stats(): array
    {
        global $wpdb;

        $week_ago = wp_date('Y-m-d', strtotime('-7 days'));
        $today    = wp_date('Y-m-d');

        // New members this week
        $new_members = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} 
             WHERE post_type = 'miembro' 
             AND post_status = 'publish' 
             AND post_date >= %s",
            $week_ago . ' 00:00:00'
        ));

        // Status counts
        $status_counts = [];
        foreach (Estados::STATES as $state) {
            $status_counts[$state] = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->posts} p
                 JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                 WHERE p.post_type = 'miembro'
                 AND p.post_status = 'publish'
                 AND pm.meta_key = '_bdv_estado_miembro'
                 AND pm.meta_value = %s",
                $state
            ));
        }

        // Expiring in the next 7 days
        $expiring_soon = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} p
             JOIN {$wpdb->postmeta} pm_est ON p.ID = pm_est.post_id AND pm_est.meta_key = '_bdv_estado_miembro' AND pm_est.meta_value = 'activo'
             JOIN {$wpdb->postmeta} pm_ren ON p.ID = pm_ren.post_id AND pm_ren.meta_key = '_bdv_fecha_renovacion'
             WHERE p.post_type = 'miembro'
             AND p.post_status = 'publish'
             AND pm_ren.meta_value BETWEEN %s AND %s",
            $today,
            wp_date('Y-m-d', strtotime('+7 days'))
        ));

        // Pending payments
        $pending_payments = $status_counts['pendiente_pago'] ?? 0;

        // Volunteer hours logged this week
        $hours_logged = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(pm.meta_value), 0) FROM {$wpdb->posts} p
             JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_bdv_horas'
             WHERE p.post_type = 'registro_hora'
             AND p.post_status = 'publish'
             AND p.post_date >= %s",
            $week_ago . ' 00:00:00'
        ));

        // Recent errors from logs
        $recent_errors = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}biodevas_logs 
             WHERE level = 'error' 
             AND created_at >= %s",
            $week_ago . ' 00:00:00'
        ));

        return [
            'new_members'      => $new_members,
            'status_counts'    => $status_counts,
            'expiring_soon'    => $expiring_soon,
            'pending_payments' => $pending_payments,
            'hours_logged'     => $hours_logged,
            'recent_errors'    => $recent_errors,
            'total_active'     => $status_counts['activo'] ?? 0,
        ];
    }

    /**
     * Build the HTML body for the admin weekly digest.
     */
    private function build_digest_body(array $stats): string
    {
        $admin_url = admin_url('admin.php?page=bdv-members');
        $date_range = wp_date('d/m/Y', strtotime('-7 days')) . ' — ' . wp_date('d/m/Y');

        $html = '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;">';

        // Header
        $html .= '<div style="background:#2c5e3e;color:#fff;padding:20px;border-radius:8px 8px 0 0;text-align:center;">';
        $html .= '<h1 style="margin:0;font-size:22px;">📊 Resumen Semanal Biodevas</h1>';
        $html .= '<p style="margin:5px 0 0;opacity:0.8;font-size:14px;">' . esc_html($date_range) . '</p>';
        $html .= '</div>';

        // Body
        $html .= '<div style="background:#f8f9fa;padding:20px;border:1px solid #e9ecef;">';

        // Key metrics row
        $html .= '<table style="width:100%;border-collapse:collapse;margin-bottom:20px;">';
        $html .= '<tr>';
        $html .= $this->digest_metric_cell('Socios Activos', $stats['total_active'], '#2c5e3e');
        $html .= $this->digest_metric_cell('Nuevos esta semana', $stats['new_members'], '#0d6efd');
        $html .= $this->digest_metric_cell('Horas Registradas', $stats['hours_logged'] . 'h', '#6f42c1');
        $html .= '</tr>';
        $html .= '</table>';

        // Alerts
        if ($stats['expiring_soon'] > 0 || $stats['pending_payments'] > 0 || $stats['recent_errors'] > 0) {
            $html .= '<div style="background:#fff3cd;border:1px solid #ffc107;padding:12px;border-radius:6px;margin-bottom:15px;">';
            $html .= '<strong>⚠️ Requiere atención:</strong><ul style="margin:8px 0 0;padding-left:20px;">';

            if ($stats['expiring_soon'] > 0) {
                $html .= '<li>' . $stats['expiring_soon'] . ' membresía(s) vencen en los próximos 7 días</li>';
            }
            if ($stats['pending_payments'] > 0) {
                $html .= '<li>' . $stats['pending_payments'] . ' pago(s) pendiente(s)</li>';
            }
            if ($stats['recent_errors'] > 0) {
                $html .= '<li>' . $stats['recent_errors'] . ' error(es) en el sistema esta semana</li>';
            }

            $html .= '</ul></div>';
        }

        // Status breakdown
        $html .= '<div style="background:#fff;padding:15px;border-radius:6px;border:1px solid #dee2e6;">';
        $html .= '<h3 style="margin:0 0 10px;font-size:16px;">Desglose por estado</h3>';
        $html .= '<table style="width:100%;font-size:14px;">';

        foreach ($stats['status_counts'] as $state => $count) {
            $label = Estados::LABELS[$state] ?? $state;
            $html .= '<tr><td style="padding:4px 0;">' . esc_html($label) . '</td>';
            $html .= '<td style="padding:4px 0;text-align:right;font-weight:bold;">' . $count . '</td></tr>';
        }

        $html .= '</table></div>';

        $html .= '</div>';

        // Footer
        $html .= '<div style="background:#e9ecef;padding:15px;border-radius:0 0 8px 8px;text-align:center;font-size:13px;color:#6c757d;">';
        $html .= '<a href="' . esc_url($admin_url) . '" style="color:#2c5e3e;text-decoration:none;font-weight:bold;">Ver panel de administración →</a>';
        $html .= '<br><br>Este email se genera automáticamente cada lunes.';
        $html .= '</div>';

        $html .= '</div>';

        return $html;
    }

    /**
     * Build a single metric cell for the digest email.
     */
    private function digest_metric_cell(string $label, $value, string $color): string
    {
        return '<td style="text-align:center;padding:10px;background:#fff;border-radius:6px;border:1px solid #dee2e6;margin:5px;">'
            . '<div style="font-size:28px;font-weight:bold;color:' . $color . ';">' . esc_html($value) . '</div>'
            . '<div style="font-size:12px;color:#6c757d;margin-top:4px;">' . esc_html($label) . '</div>'
            . '</td>';
    }

    /* ── Helpers ────────────────────────────────────────────── */

    /**
     * Get signed payment link for a payment ID.
     */
    private function get_payment_link(int $pago_id): string
    {
        if (class_exists('Biodevas\\Gateway\\Payment_Handler')) {
            return Payment_Handler::get_payment_link($pago_id);
        }
        return home_url('/pagar/');
    }

    /**
     * Get renewal link for a member (try existing payment, fallback to renew page).
     */
    private function get_renewal_link(int $post_id): string
    {
        // If recurrent, create payment automatically
        $es_recurrente = get_post_meta($post_id, '_bdv_pago_recurrente', true);
        $forma_pago    = get_post_meta($post_id, '_bdv_forma_pago', true);

        if ($es_recurrente && in_array($forma_pago, ['tarjeta', 'bizum', 'cuota'], true)) {
            $plan_key  = get_post_meta($post_id, '_bdv_plan', true);
            $plan_data = CPT_Miembro::get_plan($plan_key);
            $importe   = (float) (get_post_meta($post_id, '_bdv_importe_cuota', true) ?: ($plan_data['price'] ?? 0));

            if ($importe > 0 && function_exists('Biodevas\\Gateway\\bdv_gateway_create_payment')) {
                $payment = \Biodevas\Gateway\bdv_gateway_create_payment([
                    'amount_cents'  => (int) round($importe * 100),
                    'method'        => ($forma_pago === 'cuota') ? 'tarjeta' : $forma_pago,
                    'origin'        => 'members',
                    'origin_id'     => $post_id,
                    'product_desc'  => mb_substr('RENOVACION BIODEVAS ' . ($plan_data['label'] ?? 'SOCIO'), 0, 125),
                ]);

                if (!is_wp_error($payment)) {
                    update_post_meta($post_id, '_bdv_pago_id', $payment['pago_id']);
                    \Biodevas\Common\Logger::info(
                        "Renovación automática generada (Pago #{$payment['pago_id']}) para el miembro #$post_id.",
                        'Members/Renewal',
                        $post_id
                    );
                    return $this->get_payment_link((int) $payment['pago_id']);
                }
            }
        }

        // Fallback: try existing payment link
        $pago_id = (int) get_post_meta($post_id, '_bdv_pago_id', true);
        if ($pago_id) {
            return $this->get_payment_link($pago_id);
        }

        return home_url('/renovar/');
    }

    /**
     * Get volunteer hours summary for a member.
     */
    private function get_volunteer_hours_summary(int $post_id): array
    {
        global $wpdb;

        $year = wp_date('Y');

        // Get total approved hours for current year
        $total = (float) $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(pm_h.meta_value), 0)
             FROM {$wpdb->posts} p
             JOIN {$wpdb->postmeta} pm_m ON p.ID = pm_m.post_id AND pm_m.meta_key = '_bdv_miembro_id' AND pm_m.meta_value = %d
             JOIN {$wpdb->postmeta} pm_h ON p.ID = pm_h.post_id AND pm_h.meta_key = '_bdv_horas'
             JOIN {$wpdb->postmeta} pm_e ON p.ID = pm_e.post_id AND pm_e.meta_key = '_bdv_estado' AND pm_e.meta_value = 'aprobada'
             WHERE p.post_type = 'registro_hora'
             AND p.post_status = 'publish'
             AND YEAR(p.post_date) = %d",
            $post_id,
            $year
        ));

        // Get the objective from plan
        $plan_key  = get_post_meta($post_id, '_bdv_plan', true);
        $plan_data = CPT_Miembro::get_plan($plan_key);
        $objetivo  = (float) ($plan_data['hours'] ?? 40);

        $porcentaje = $objetivo > 0 ? min(100, round(($total / $objetivo) * 100)) : 0;

        return [
            'total'      => $total,
            'objetivo'   => $objetivo,
            'porcentaje' => $porcentaje,
        ];
    }

    /**
     * Generic template email sender (uses reflection to access private send method).
     * This serves templates that don't have a dedicated public method.
     */
    private function send_template_email(Email_Manager $email_manager, string $template, int $post_id, array $extra_vars = []): void
    {
        // Try dedicated method first
        $method = 'send_' . $template;
        if (method_exists($email_manager, $method)) {
            $email_manager->$method($post_id, $extra_vars);
            return;
        }

        // For templates without a dedicated method, manually replicate the send logic
        $templates = Email_Manager::get_templates();
        $tpl       = $templates[$template] ?? null;

        if (!$tpl) {
            return;
        }

        $email = get_post_meta($post_id, '_bdv_email', true);
        if (empty($email)) {
            return;
        }

        // Build basic vars
        $nombre = get_the_title($post_id);
        $vars   = array_merge(['{nombre}' => $nombre, '{email}' => $email], $extra_vars);

        $subject = str_replace(array_keys($vars), array_values($vars), $tpl['subject']);
        $body    = str_replace(array_keys($vars), array_values($vars), $tpl['body']);

        $settings    = get_option('bdv_members_settings', []);
        $sender_name = $settings['sender_name'] ?? get_bloginfo('name');
        $admin_email = $settings['admin_email'] ?? get_option('admin_email');

        $headers = [
            'Content-Type: text/plain; charset=UTF-8',
            'From: ' . $sender_name . ' <' . $admin_email . '>',
        ];

        wp_mail($email, $subject, $body, $headers);
    }
}
