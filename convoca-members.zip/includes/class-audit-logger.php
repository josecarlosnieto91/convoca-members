<?php
namespace Biodevas\Members;

/**
 * Centralized Audit Logger for Members.
 * Tracks lifecycle events like deletions, email logs, etc.
 *
 * @package Biodevas\Members
 */

if (!defined('ABSPATH')) {
    exit;
}

class Audit_Logger
{
    public function __construct()
    {
        // Track logical deletions (trash)
        add_action('wp_trash_post', [$this, 'log_trash'], 10, 1);
        add_action('untrash_post', [$this, 'log_untrash'], 10, 1);
        add_action('before_delete_post', [$this, 'log_permanent_delete'], 10, 1);
        
        // Track metadata changes if needed
        add_action('updated_post_meta', [$this, 'log_meta_change'], 10, 4);
    }

    public function log_trash(int $post_id): void
    {
        if (get_post_type($post_id) !== 'miembro') return;
        
        \Biodevas\Common\Logger::warning(
            __('Miembro movido a la papelera (borrado lógico).', 'biodevas-members'),
            'Members/Audit',
            $post_id
        );
    }

    public function log_untrash(int $post_id): void
    {
        if (get_post_type($post_id) !== 'miembro') return;
        
        \Biodevas\Common\Logger::info(
            __('Miembro restaurado de la papelera.', 'biodevas-members'),
            'Members/Audit',
            $post_id
        );
    }

    public function log_permanent_delete(int $post_id): void
    {
        if (get_post_type($post_id) !== 'miembro') return;
        
        \Biodevas\Common\Logger::error(
            __('ELIMINACIÓN PERMANENTE del miembro.', 'biodevas-members'),
            'Members/Audit',
            $post_id
        );
    }

    /**
     * Log specific meta changes like WhatsApp usage.
     */
    public function log_meta_change(int $meta_id, int $post_id, string $meta_key, $meta_value): void
    {
        if (get_post_type($post_id) !== 'miembro') return;

        // Example: If we update 'ultimo_contacto_whatsapp' we log it
        if ($meta_key === '_bdv_ultimo_contacto_whatsapp') {
             \Biodevas\Common\Logger::info(
                __('Contacto por WhatsApp registrado.', 'biodevas-members'),
                'Members/Audit',
                $post_id
            );
        }
    }
}
