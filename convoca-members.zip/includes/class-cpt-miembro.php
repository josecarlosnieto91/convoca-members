<?php
/**
 * Custom Post Type: miembro + taxonomy tipo_miembro + meta fields.
 *
 * Aligned with libro de socios v2 (full field set).
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class CPT_Miembro
{

    /**
     * Meta keys used by the plugin.
     * Aligned with the libro de socios spreadsheet.
     */
    public const META_KEYS = [
        // ── Identity ──
        'email',
        'dni',
        'fecha_nacimiento',
        'menor_edad',           // boolean

        // ── Contact ──
        'telefono',
        'whatsapp',             // si / no
        'canal_contacto',       // whatsapp, email, telefono
        'direccion',
        'municipio',

        // ── Membership ──
        'plan',                 // busgosu, lugg, deva, etc.
        'sub_plan',             // fam-busgosu, juv-busgosu, etc.
        'modalidad',            // Numerario, Familiar, Juvenil
        'estado_miembro',       // activo, proximo_vencer, baja
        'forma_pago',           // cuota, voluntariado
        'importe_cuota',        // e.g. 100
        'estado_cuota',         // activa, pendiente, vencida
        'pago_id',              // Gateway pago post ID
        'metodo_pago',          // tarjeta | bizum
        'cuota',                // legacy alias
        'fecha_renovacion',
        'fecha_baja',

        // ── Volunteer ──
        'es_voluntario',        // boolean
        'tipo_voluntariado',    // string description
        'intereses',
        'disponibilidad',
        'experiencia',
        'motivacion',

        // ── Minor ──
        'tutor_nombre',
        'tutor_dni',
        'tutor_autorizacion',   // boolean

        // ── Legal ──
        'rgpd_version',
        'rgpd_timestamp',
        'comunicaciones_ok',    // boolean

        // ── Admin / Tracking ──
        'observaciones',        // admin notes (textarea)
        'incidencias',          // admin notes (textarea)
        'ultimo_contacto',      // date of last contact
        'responsable',          // responsible admin user
        'msg_bienvenida',       // boolean — sent?
        'msg_renovacion',       // boolean — sent?
        'avisos_generales',     // free text
        'access_code',          // member portal access code
    ];

    /** Status for payments (cuotas). */
    public const ESTADO_CUOTA = [
        'activa' => 'Activa',
        'pendiente' => 'Pendiente',
        'vencida' => 'Vencida',
    ];

    /** Plan definitions (price in €, hours in h). */
    public const PLANS = [
        'busgosu' => [
            'label' => '🍁 Busgosu',
            'price' => 30,
            'hours' => 15,
            'modalidad' => 'Numerario',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                'Participa en todas las actividades de naturaleza de forma gratuita.',
                'Prioridad en las inscripciones para actividades ambientales.'
            ]
        ],
        'lugg' => [
            'label' => '🌿 Lugg',
            'price' => 50,
            'hours' => 25,
            'modalidad' => 'Numerario',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                '20% de descuento en actividades de pago del Centro.',
                'Accede a los espacios sociales del local cuando quieras.',
                'Reserva el local 2 veces al año para eventos privados.'
            ]
        ],
        'deva' => [
            'label' => '🔥 Deva',
            'price' => 100,
            'hours' => 50,
            'modalidad' => 'Numerario',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                'Todas las ventajas de Busgosu y Lugg.',
                'Prioridad en ofertas de trabajo internas.',
                'Grupo de WhatsApp exclusivo con comunidad activa.',
                'Descuentos especiales con diferentes colaboradores.'
            ]
        ],
        'fam-busgosu' => [
            'label' => 'Familiar Busgosu',
            'price' => 45,
            'hours' => 22.5,
            'modalidad' => 'Familiar',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                'Participa en todas las actividades de naturaleza de forma gratuita.',
                'Prioridad en las inscripciones para actividades ambientales.',
                'Ventajas aplicables a toda la unidad familiar.'
            ]
        ],
        'fam-lugg' => [
            'label' => 'Familiar Lugg',
            'price' => 75,
            'hours' => 37.5,
            'modalidad' => 'Familiar',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                '20% de descuento en actividades de pago del Centro.',
                'Accede a los espacios sociales del local cuando quieras.',
                'Reserva el local 2 veces al año para eventos privados.',
                'Ventajas aplicables a toda la unidad familiar.'
            ]
        ],
        'fam-deva' => [
            'label' => 'Familiar Deva',
            'price' => 150,
            'hours' => 75,
            'modalidad' => 'Familiar',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                'Todas las ventajas de Busgosu y Lugg.',
                'Prioridad en ofertas de trabajo internas.',
                'Grupo de WhatsApp exclusivo con comunidad activa.',
                'Descuentos especiales con diferentes colaboradores.',
                'Ventajas aplicables a toda la unidad familiar.'
            ]
        ],
        'juv-busgosu' => [
            'label' => 'Juvenil Busgosu',
            'price' => 15,
            'hours' => 7.5,
            'modalidad' => 'Juvenil',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                'Participa en todas las actividades de naturaleza de forma gratuita.',
                'Prioridad en las inscripciones para actividades ambientales.',
                'Espacio independiente para actuar y tomar decisiones.'
            ]
        ],
        'juv-lugg' => [
            'label' => 'Juvenil Lugg',
            'price' => 25,
            'hours' => 12.5,
            'modalidad' => 'Juvenil',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                '20% de descuento en actividades de pago del Centro.',
                'Accede a los espacios sociales del local cuando quieras.',
                'Reserva el local 2 veces al año para eventos privados.',
                'Espacio independiente para actuar y tomar decisiones.'
            ]
        ],
        'juv-deva' => [
            'label' => 'Juvenil Deva',
            'price' => 50,
            'hours' => 25,
            'modalidad' => 'Juvenil',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                'Todas las ventajas de Busgosu y Lugg.',
                'Prioridad en ofertas de trabajo internas.',
                'Grupo de WhatsApp exclusivo con comunidad activa.',
                'Descuentos especiales con diferentes colaboradores.',
                'Espacio independiente para actuar y tomar decisiones.'
            ]
        ],
        'familiar' => [
            'label' => 'Modalidad Familiar',
            'price' => 0,
            'hours' => 0,
            'modalidad' => 'Virtual',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                'Descuentos en los diferentes formatos.',
                'Mismas ventajas que el plan correspondiente, adaptadas al grupo familiar.'
            ]
        ],
        'juvenil' => [
            'label' => 'Modalidad Juvenil',
            'price' => 0,
            'hours' => 0,
            'modalidad' => 'Virtual',
            'payment_methods' => ['bizum', 'tarjeta', 'transferencia'],
            'advantages' => [
                'Espacio independiente para actuar y tomar decisiones.',
                'Descuentos del 50% en todos los formatos.'
            ]
        ],
    ];

    public const SLUG = 'miembro';

    /**
     * Register Post Type and Taxonomy.
     */
    public static function register(): void
    {
        // Taxonomy: Tipo de miembro.
        register_taxonomy('tipo_miembro', [self::SLUG], [
            'labels' => [
                'name' => 'Tipos de miembro',
                'singular_name' => 'Tipo de miembro',
            ],
            'hierarchical' => true,
            'show_in_rest' => true,
            'public' => true,
        ]);

        // CPT: Miembro.
        register_post_type(self::SLUG, [
            'labels' => [
                'name' => 'Miembros',
                'singular_name' => 'Miembro',
                'add_new' => 'Añadir nuevo',
                'add_new_item' => 'Añadir nuevo miembro',
                'edit_item' => 'Editar miembro',
                'new_item' => 'Nuevo miembro',
                'view_item' => 'Ver miembro',
                'search_items' => 'Buscar miembros',
                'not_found' => 'No se han encontrado miembros',
                'not_found_in_trash' => 'No se han encontrado miembros en la papelera',
            ],
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => false,
            'supports' => ['title', 'custom-fields'],
            'rewrite' => false,
            'has_archive' => false,
            'show_in_rest' => true,
            'map_meta_cap' => true,
        ]);
    }

    /**
     * Get all membership plans (merged with DB settings).
     */
    public static function get_plans(): array
    {
        $db_plans = get_option('bdv_members_plans', []);

        // If DB is empty, use defaults (legacy mode).
        $plans = empty($db_plans) ? self::PLANS : $db_plans;

        // Normalize: Ensure all plans have critical keys
        foreach ($plans as $key => &$plan) {
            $default = isset(self::PLANS[$key]) ? self::PLANS[$key] : [];

            if (!isset($plan['payment_methods'])) {
                $plan['payment_methods'] = isset($default['payment_methods']) ? $default['payment_methods'] : ['bizum', 'tarjeta', 'transferencia'];
            }
            if (!isset($plan['price'])) {
                $plan['price'] = isset($default['price']) ? $default['price'] : 0;
            }
            if (!isset($plan['hours'])) {
                $plan['hours'] = isset($default['hours']) ? $default['hours'] : 0;
            }
        }

        return $plans;
    }

    /**
     * Get plan data by key.
     */
    public static function get_plan(string $key): ?array
    {
        $plans = self::get_plans();
        return $plans[$key] ?? null;
    }

    /**
     * Build a WhatsApp wa.me link for a member.
     *
     * @param int    $post_id  Member post ID.
     * @param string $message  Optional custom message (URL-encoded automatically).
     * @return string|null     Full wa.me URL or null if no phone.
     */
    public static function whatsapp_link(int $post_id, string $message = ''): ?string
    {
        $phone = get_post_meta($post_id, '_bdv_telefono', true);
        $has_wa = get_post_meta($post_id, '_bdv_whatsapp', true);

        if (!$phone || $has_wa === 'no') {
            return null;
        }

        // Normalize phone: remove spaces, dashes, parentheses; add 34 prefix if needed.
        $clean = preg_replace('/[\s\-\(\)]+/', '', $phone);
        if (!str_starts_with($clean, '+') && !str_starts_with($clean, '34')) {
            $clean = '34' . $clean;
        }
        $clean = ltrim($clean, '+');

        $url = 'https://wa.me/' . $clean;
        if ($message) {
            $nombre = get_post_meta($post_id, '_bdv_nombre', true) ?: get_the_title($post_id);
            $msg = str_replace('{nombre}', $nombre, $message);
            $url .= '?text=' . rawurlencode($msg);
        }

        return $url;
    }

    /**
     * Get next sequential member number.
     */
    public static function get_next_member_number(): int
    {
        global $wpdb;
        $max = $wpdb->get_var("
            SELECT MAX(CAST(meta_value AS UNSIGNED)) 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_bdv_numero_socio'
        ");
        return ((int) $max) + 1;
    }

    /**
     * Approve member: Assign number, set dates, activate.
     */
    public static function approve_member(int $post_id): bool
    {
        $status = get_post_meta($post_id, '_bdv_estado_miembro', true);
        $num = get_post_meta($post_id, '_bdv_numero_socio', true);

        // If already active AND already has a number, nothing to do.
        if ($status === 'activo' && !empty($num)) {
            return false;
        }

        // Assign number if missing.
        if (empty($num)) {
            $num = self::get_next_member_number();
            update_post_meta($post_id, '_bdv_numero_socio', $num);
        }
        update_post_meta($post_id, '_bdv_estado_cuota', 'activa');

        // Set dates.
        $now = current_time('Y-m-d');
        update_post_meta($post_id, '_bdv_fecha_alta', $now);
        update_post_meta($post_id, '_bdv_fecha_renovacion', wp_date('Y-m-d', strtotime('+1 year')));

        // Activate via state machine (triggers audit log + hooks).
        Estados::change($post_id, 'activo', "Aprobado manualmente. Socio #$num");

        // TODO: Generate PDF and Send Email (Phase 3.2).

        return true;
    }
    /**
     * Centralized member status validation logic.
     * Checks if a member should be suspended or marked as baja based on renewal date.
     *
     * @param int $post_id Member ID.
     */
    public static function check_member_status(int $post_id): void
    {
        $status = get_post_meta($post_id, '_bdv_estado_miembro', true);
        $renewal_date = get_post_meta($post_id, '_bdv_fecha_renovacion', true);
        $today = current_time('Y-m-d');

        if ($status === 'baja' || empty($renewal_date)) {
            return;
        }

        // Skip volunteers — their renewal is handled by Voluntariado_Manager, not by payment.
        $forma_pago = get_post_meta($post_id, '_bdv_forma_pago', true);
        if ($forma_pago === 'voluntariado') {
            return;
        }

        // 1. Final Baja logic (Renewal date + 30 days) — check FIRST (most severe).
        $baja_date = wp_date('Y-m-d', strtotime($renewal_date . ' +30 days'));
        if ($today > $baja_date) {
            Estados::change($post_id, 'baja', 'Baja automática por falta de pago (30 días tras vencimiento).');
            update_post_meta($post_id, '_bdv_estado_cuota', 'vencida');
            update_post_meta($post_id, '_bdv_fecha_baja', $today);
            return;
        }

        // 2. Suspension logic (Renewal date + 15 days).
        $suspension_date = wp_date('Y-m-d', strtotime($renewal_date . ' +15 days'));
        if ($today > $suspension_date && $status !== 'suspendido') {
            Estados::change($post_id, 'suspendido', 'Suspendido automáticamente por falta de pago (15 días tras vencimiento).');
            update_post_meta($post_id, '_bdv_estado_cuota', 'vencida');
            return;
        }
    }
}
