<?php
/**
 * Upgrade Manager for Biodevas Members.
 *
 * Handles database structure upgrades for the members plugin.
 *
 * To add a new upgrade:
 * 1. Increment BDV_MEMBERS_DB_VERSION in biodevas-members.php
 * 2. Add a callback: '1.0.1' => [$this, 'upgrade_to_1_0_1']
 * 3. Implement the private method with idempotent logic.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

use Biodevas\Common\Upgrade_Manager;

if (!defined('ABSPATH')) {
    exit;
}

class Members_Upgrade_Manager extends Upgrade_Manager
{
    public function __construct()
    {
        $this->init();
    }

    protected function get_db_version(): string
    {
        return defined('BDV_MEMBERS_DB_VERSION') ? BDV_MEMBERS_DB_VERSION : '0.0.0';
    }

    protected function get_option_name(): string
    {
        return 'bdv_members_db_version';
    }

    protected function get_transient_prefix(): string
    {
        return 'bdv_members';
    }

    protected function get_upgrade_callbacks(): array
    {
        return [
            // Add upgrade callbacks here as needed.
            // '1.0.1' => [$this, 'upgrade_to_1_0_1'],
        ];
    }
}
