<?php
/**
 * Generates Member Card (PDF/Printable).
 * Currently implements a high-fidelity HTML print view.
 * 
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class PDF_Card
{

    /**
     * Generate HTML for the member card.
     */
    public static function get_html(int $post_id): string
    {
        $nombre = get_the_title($post_id);
        $num_socio = get_post_meta($post_id, '_bdv_numero_socio', true);
        $num_socio_display = $num_socio ? str_pad($num_socio, 4, '0', STR_PAD_LEFT) : esc_html__('PENDIENTE', 'biodevas-members');
        
        $plan_key = get_post_meta($post_id, '_bdv_plan', true);
        $plan_data = CPT_Miembro::get_plan($plan_key ?: '');
        $plan = $plan_data['label'] ?? esc_html__('Socio/a', 'biodevas-members');
        
        $fecha = get_post_meta($post_id, '_bdv_fecha_alta', true);
        $fecha_fmt = $fecha ? wp_date('d/m/Y', strtotime($fecha)) : wp_date('d/m/Y', strtotime(get_the_date('Y-m-d', $post_id)));

        $logo_url = BDV_MEMBERS_URL . 'assets/img/logo.png';
        $qr_url = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . urlencode(site_url('/mi-cuenta/reservas/'));

        return '
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>' . esc_html__('Tarjeta Socio', 'biodevas-members') . ' #' . esc_html($num_socio_display) . '</title>
            <style>
                @media print {
                    body { margin: 0; padding: 0; }
                    .no-print { display: none; }
                }
                body { 
                    font-family: "Segoe UI", Roboto, Helvetica, Arial, sans-serif; 
                    background: #f4f7f6; 
                    display: flex; 
                    flex-direction: column; 
                    align-items: center; 
                    justify-content: center; 
                    min-height: 100vh;
                    margin: 0;
                }
                .card {
                    width: 450px; 
                    height: 280px;
                    border-radius: 16px;
                    background: linear-gradient(135deg, #2d5a27 0%, #1e3c1a 100%);
                    color: #fff;
                    position: relative;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                    padding: 30px;
                    display: flex;
                    flex-direction: column;
                    justify-content: space-between;
                    overflow: hidden;
                    box-sizing: border-box;
                }
                .card::before {
                    content: "";
                    position: absolute;
                    top: -50px;
                    right: -50px;
                    width: 150px;
                    height: 150px;
                    background: rgba(255,255,255,0.05);
                    border-radius: 50%;
                }
                .header { display: flex; justify-content: space-between; align-items: flex-start; }
                .logo-container { display: flex; align-items: center; gap: 10px; }
                .logo-text { font-size: 22px; font-weight: 800; letter-spacing: 1px; color: #fff; }
                .plan-badge { 
                    background: #ffc107; 
                    color: #000; 
                    padding: 4px 12px; 
                    border-radius: 20px; 
                    font-size: 10px; 
                    font-weight: bold; 
                    text-transform: uppercase; 
                }
                .body { margin-top: 20px; }
                .member-number { 
                    font-family: "Courier New", monospace; 
                    font-size: 24px; 
                    letter-spacing: 4px; 
                    margin-bottom: 5px; 
                    opacity: 0.9;
                }
                .member-name { font-size: 18px; font-weight: 600; text-transform: uppercase; }
                .footer { display: flex; justify-content: space-between; align-items: flex-end; }
                .info { font-size: 11px; opacity: 0.8; }
                .qr-code { 
                    width: 70px; 
                    height: 70px; 
                    background: #fff; 
                    padding: 5px; 
                    border-radius: 8px; 
                    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                }
                .qr-code img { width: 100%; height: 100%; }
                .btn-print {
                    margin-top: 30px;
                    background: #1e3c1a;
                    color: white;
                    border: none;
                    padding: 12px 24px;
                    border-radius: 8px;
                    cursor: pointer;
                    font-weight: 600;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                    transition: all 0.3s ease;
                }
                .btn-print:hover { background: #2d5a27; transform: translateY(-2px); }
            </style>
        </head>
        <body>
            <div class="card">
                <div class="header">
                    <div class="logo-container">
                        <span class="logo-text">BIODEVAS</span>
                    </div>
                    <div class="plan-badge">' . esc_html($plan) . '</div>
                </div>
                
                <div class="body">
                    <div class="member-number">' . esc_html__('NO.', 'biodevas-members') . ' ' . esc_html($num_socio_display) . '</div>
                    <div class="member-name">' . esc_html($nombre) . '</div>
                </div>
                
                <div class="footer">
                    <div class="info">
                        <div>' . esc_html__('FECHA DE ALTA:', 'biodevas-members') . ' ' . esc_html($fecha_fmt) . '</div>
                        <div style="margin-top:4px;">WWW.BIODEVAS.ORG</div>
                    </div>
                    <div class="qr-code">
                        <img src="' . esc_url($qr_url) . '" alt="' . esc_attr__('QR Verification', 'biodevas-members') . '">
                    </div>
                </div>
            </div>
            
            <button class="btn-print no-print" onclick="window.print()">
                📄 ' . esc_html__('Imprimir / Guardar como PDF', 'biodevas-members') . '
            </button>
            <p class="no-print" style="margin-top:15px; color:#666; font-size:13px;">
                ' . esc_html__('Se abrirá el diálogo de impresión. Elige "Guardar como PDF" como destino.', 'biodevas-members') . '
            </p>
        </body>
        </html>
        ';
    }
}

