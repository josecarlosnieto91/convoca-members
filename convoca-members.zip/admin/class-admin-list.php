<?php
/**
 * Admin list table using WP_List_Table.
 *
 * v2: added Teléfono, WhatsApp (wa.me) columns,
 *     row actions with WhatsApp link, sortable by plan/estado.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class Admin_List extends \WP_List_Table
{

    /** Default WhatsApp message template. */
    private const WA_MSG = 'Hola {nombre}, te escribimos desde Biodevas. ';

    public function __construct()
    {
        parent::__construct([
            'singular' => 'miembro',
            'plural' => 'miembros',
            'ajax' => false,
        ]);
    }

    public function get_columns(): array
    {
        return [
            'cb' => '<input type="checkbox">',
            'numero' => __('Nº', 'biodevas-members'),
            'nombre' => __('Nombre', 'biodevas-members'),
            'email' => __('Email', 'biodevas-members'),
            'telefono' => __('Teléfono', 'biodevas-members'),
            'whatsapp' => __('WhatsApp', 'biodevas-members'),
            'tipo' => __('Tipo', 'biodevas-members'),
            'estado' => __('Estado', 'biodevas-members'),
            'plan' => __('Plan', 'biodevas-members'),
            'cuota' => __('Cuota', 'biodevas-members'),
            'recurrente' => __('Renov. Pago', 'biodevas-members'),
            'fecha' => __('Fecha alta', 'biodevas-members'),
        ];
    }

    public function get_sortable_columns(): array
    {
        return [
            'nombre' => ['title', true],
            'fecha' => ['date', false],
        ];
    }

    public function get_bulk_actions(): array
    {
        return [
            'bulk-delete' => __('Mover a la papelera', 'biodevas-members'),
        ];
    }

    public function process_bulk_action(): void
    {
        if ('bulk-delete' === $this->current_action()) {
            $ids = isset($_REQUEST['miembros']) ? array_map('intval', $_REQUEST['miembros']) : [];
            if (empty($ids))
                return;

            $count = 0;
            foreach ($ids as $id) {
                if (wp_trash_post($id)) {
                    $count++;
                }
            }
            // Add a transient or hook to show admin notice if needed, 
            // but for now relying on WP's default handling or redirect.
        }
    }

    public function prepare_items(): void
    {
        $this->process_bulk_action();

        $per_page = 20;
        $page = $this->get_pagenum();
        $search = isset($_REQUEST['s']) ? sanitize_text_field($_REQUEST['s']) : '';

        $args = [
            'post_type' => 'miembro',
            'posts_per_page' => $per_page,
            'paged' => $page,
            'post_status' => 'publish',
            'orderby' => sanitize_text_field($_REQUEST['orderby'] ?? 'date'),
            'order' => strtoupper(sanitize_text_field($_REQUEST['order'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC',
        ];

        // Search by name, email, DNI, or phone.
        if ($search) {
            $cleaned_search = strtoupper(str_replace([' ', '-'], '', $search));
            $args['meta_query'] = [
                'relation' => 'OR',
                ['key' => '_bdv_email', 'value' => $search, 'compare' => 'LIKE'],
                ['key' => '_bdv_dni', 'value' => $search, 'compare' => 'LIKE'],
                ['key' => '_bdv_dni', 'value' => $cleaned_search, 'compare' => 'LIKE'],
                ['key' => '_bdv_telefono', 'value' => $search, 'compare' => 'LIKE'],
            ];
            $args['s'] = $search; // Also search post title (nombre).
        }

        // Filter by estado.
        $estado_filter = sanitize_text_field($_GET['estado_filter'] ?? '');
        if ($estado_filter) {
            $args['meta_query'] = array_merge(
                $args['meta_query'] ?? [],
                [['key' => '_bdv_estado_miembro', 'value' => $estado_filter]]
            );
        }

        // Filter by tipo.
        $tipo_filter = sanitize_text_field($_GET['tipo_filter'] ?? '');
        if ($tipo_filter) {
            $args['tax_query'] = [
                ['taxonomy' => 'tipo_miembro', 'field' => 'slug', 'terms' => $tipo_filter],
            ];
        }

        // Filter by plan.
        $plan_filter = sanitize_text_field($_GET['plan_filter'] ?? '');
        if ($plan_filter) {
            $args['meta_query'] = array_merge(
                $args['meta_query'] ?? [],
                [['key' => '_bdv_plan', 'value' => $plan_filter]]
            );
        }

        // Filter by estado_cuota.
        $cuota_filter = sanitize_text_field($_GET['cuota_filter'] ?? '');
        if ($cuota_filter) {
            $args['meta_query'] = array_merge(
                $args['meta_query'] ?? [],
                [['key' => '_bdv_estado_cuota', 'value' => $cuota_filter]]
            );
        }

        $query = new \WP_Query($args);

        $this->items = $query->posts;

        $this->set_pagination_args([
            'total_items' => $query->found_posts,
            'per_page' => $per_page,
            'total_pages' => $query->max_num_pages,
        ]);

        $this->_column_headers = [
            $this->get_columns(),
            [],
            $this->get_sortable_columns(),
        ];
    }

    /* ── Extra filters above the table ─────────── */

    protected function extra_tablenav($which): void
    {
        if ($which !== 'top')
            return;
        ?>
        <div class="alignleft actions">
            <select name="estado_filter">
                <option value="">
                    <?php esc_html_e('Todos los estados', 'biodevas-members'); ?>
                </option>
                <?php foreach (Estados::LABELS as $slug => $label): ?>
                    <option value="<?php echo esc_attr($slug); ?>" <?php selected($_GET['estado_filter'] ?? '', $slug); ?>>
                        <?php echo esc_html($label); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <select name="tipo_filter">
                <option value="">
                    <?php esc_html_e('Todos los tipos', 'biodevas-members'); ?>
                </option>
                <option value="socio" <?php selected($_GET['tipo_filter'] ?? '', 'socio'); ?>>Socio/a</option>
                <option value="voluntario" <?php selected($_GET['tipo_filter'] ?? '', 'voluntario'); ?>>Voluntario/a</option>
                <option value="socio_voluntario" <?php selected($_GET['tipo_filter'] ?? '', 'socio_voluntario'); ?>>Socio +
                    Vol.</option>
            </select>
            <select name="plan_filter">
                <option value="">
                    <?php esc_html_e('Todos los planes', 'biodevas-members'); ?>
                </option>
                <?php foreach (CPT_Miembro::PLANS as $slug => $plan): ?>
                    <option value="<?php echo esc_attr($slug); ?>" <?php selected($_GET['plan_filter'] ?? '', $slug); ?>>
                        <?php echo esc_html($plan['label']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <select name="cuota_filter">
                <option value="">
                    <?php esc_html_e('Estado cuota', 'biodevas-members'); ?>
                </option>
                <?php foreach (CPT_Miembro::ESTADO_CUOTA as $slug => $label): ?>
                    <option value="<?php echo esc_attr($slug); ?>" <?php selected($_GET['cuota_filter'] ?? '', $slug); ?>>
                        <?php echo esc_html($label); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?php submit_button(__('Filtrar', 'biodevas-members'), '', 'filter_action', false); ?>
        </div>
        <?php
    }

    /* ── Column renderers ──────────────────────── */

    public function column_cb($item): string
    {
        return '<input type="checkbox" name="miembros[]" value="' . esc_attr($item->ID) . '">';
    }

    public function column_numero($item): string
    {
        $num = get_post_meta($item->ID, '_bdv_numero_socio', true);
        if ($num) {
            return '<strong>' . str_pad($num, 4, '0', STR_PAD_LEFT) . '</strong>';
        }

        $status = get_post_meta($item->ID, '_bdv_estado_miembro', true);
        $html = '<span style="color:#999">pending</span>';

        if ($status === 'activo' && current_user_can('manage_options')) {
            $repair_url = wp_nonce_url(
                admin_url('admin-post.php?action=bdv_approve_member&member_id=' . $item->ID),
                'bdv_approve_member_' . $item->ID
            );
            $html .= ' <a href="' . esc_url($repair_url) . '" style="font-size:10px;text-decoration:none" title="Asignar número ahora">🔧</a>';
        }

        return $html;
    }

    public function column_nombre($item): string
    {
        $url = admin_url('admin.php?page=bdv-members&member_id=' . $item->ID);
        $name_link = '<a href="' . esc_url($url) . '"><strong>' . esc_html($item->post_title) . '</strong></a>';

        // Row actions.
        $actions = [
            'edit' => '<a href="' . esc_url($url) . '">' . __('Ver ficha', 'biodevas-members') . '</a>',
        ];

        // Approval action.
        $status = get_post_meta($item->ID, '_bdv_estado_miembro', true);
        if ($status !== 'activo') {
            $approve_url = wp_nonce_url(
                admin_url('admin-post.php?action=bdv_approve_member&member_id=' . $item->ID),
                'bdv_approve_member_' . $item->ID
            );
            $actions['approve'] = '<a href="' . esc_url($approve_url) . '" style="color:#00a32a">' . __('Aprobar alta', 'biodevas-members') . '</a>';
        }

        // PDF Card action.
        $actions['card'] = '<a href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=bdv_pdf_card&member_id=' . $item->ID), 'bdv_pdf_card_' . $item->ID)) . '" target="_blank">🪪 ' . __('Tarjeta', 'biodevas-members') . '</a>';

        // Delete action.
        $delete_url = wp_nonce_url(
            admin_url('admin-post.php?action=bdv_delete_member&member_id=' . $item->ID),
            'bdv_delete_member_' . $item->ID
        );
        $actions['delete'] = '<a href="' . esc_url($delete_url) . '" style="color:#a00" onclick="return confirm(\'¿Estás seguro de que quieres enviar este miembro a la papelera?\')">' . __('Eliminar', 'biodevas-members') . '</a>';

        return $name_link . $this->row_actions($actions);
    }

    public function column_email($item): string
    {
        $email = get_post_meta($item->ID, '_bdv_email', true);
        if (!$email)
            return '—';
        return '<a href="mailto:' . esc_attr($email) . '">' . esc_html($email) . '</a>';
    }

    public function column_telefono($item): string
    {
        $tel = get_post_meta($item->ID, '_bdv_telefono', true);
        if (!$tel)
            return '—';
        return '<a href="tel:' . esc_attr($tel) . '">' . esc_html($tel) . '</a>';
    }

    public function column_whatsapp($item): string
    {
        $has_wa = get_post_meta($item->ID, '_bdv_whatsapp', true);
        if ($has_wa === 'no') {
            return '<span style="color:#999">No</span>';
        }

        $wa_url = CPT_Miembro::whatsapp_link($item->ID, self::WA_MSG);
        if ($wa_url) {
            return '<a href="' . esc_url($wa_url) . '" target="_blank" rel="noopener" '
                . 'style="color:#25D366;font-weight:600" title="Abrir chat en WhatsApp">📱 Enviar</a>';
        }

        return $has_wa === 'si' ? '✅' : '—';
    }

    public function column_tipo($item): string
    {
        $terms = wp_get_object_terms($item->ID, 'tipo_miembro', ['fields' => 'names']);
        return esc_html(implode(', ', $terms));
    }

    public function column_estado($item): string
    {
        $estado = get_post_meta($item->ID, '_bdv_estado_miembro', true) ?: 'pendiente_documentacion';
        return Estados::badge_html($estado);
    }

    public function column_plan($item): string
    {
        $plan = get_post_meta($item->ID, '_bdv_plan', true);
        $sub = get_post_meta($item->ID, '_bdv_sub_plan', true);
        $key = $sub ?: $plan;
        $data = CPT_Miembro::get_plan($key);
        return esc_html($data['label'] ?? ucfirst($key ?: '—'));
    }

    public function column_cuota($item): string
    {
        $importe = get_post_meta($item->ID, '_bdv_importe_cuota', true);
        $estado = get_post_meta($item->ID, '_bdv_estado_cuota', true);
        $label = CPT_Miembro::ESTADO_CUOTA[$estado] ?? '—';
        $amount = $importe ? number_format((float) $importe, 0) . '€' : '—';

        if ($estado === 'activa') {
            $badge = '<span class="biodevas-badge biodevas-badge--confirmed">' . esc_html($label) . '</span>';
        } elseif ($estado === 'pendiente') {
            $badge = '<span class="biodevas-badge biodevas-badge--pending">' . esc_html($label) . '</span>';
        } elseif ($estado === 'vencida') {
            $badge = '<span class="biodevas-badge biodevas-badge--cancelled">' . esc_html($label) . '</span>';
        } else {
            $badge = '—';
        }

        return $amount . ' ' . $badge;
    }

    public function column_recurrente($item): string
    {
        $recurrente = get_post_meta($item->ID, '_bdv_pago_recurrente', true);
        if ($recurrente === '1') {
            return '<span class="dashicons dashicons-yes" style="color:#2271b1"></span> ' . __('Sí', 'biodevas-members');
        }
        return '<span class="dashicons dashicons-no-alt" style="color:#666"></span> ' . __('No', 'biodevas-members');
    }

    public function column_fecha($item): string
    {
        return get_the_date('d/m/Y', $item);
    }

    public function column_default($item, $column_name): string
    {
        return '—';
    }
}
