<?php
/**
 * Admin page: menu registration, dashboard widget, and member detail view.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class Admin_Page
{

    public function __construct()
    {
        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_dashboard_setup', [$this, 'dashboard_widget']);

        // Quick state-change AJAX.
        add_action('wp_ajax_bdv_change_state', [$this, 'ajax_change_state']);
        add_action('wp_ajax_bdv_log_whatsapp', [$this, 'ajax_log_whatsapp']);
    }

    /* ── Menu ──────────────────────────────────── */

    public function register_menu(): void
    {
        add_menu_page(
            __('Miembros Biodevas', 'biodevas-members'),
            __('Miembros', 'biodevas-members'),
            'gestionar_miembros',
            'bdv-members',
            [$this, 'render_list_page'],
            'dashicons-groups',
            26
        );

        add_submenu_page(
            'bdv-members',
            __('Listado', 'biodevas-members'),
            __('Listado', 'biodevas-members'),
            'gestionar_miembros',
            'bdv-members',
            [$this, 'render_list_page']
        );

        add_submenu_page(
            'bdv-members',
            __('Ajustes', 'biodevas-members'),
            __('Ajustes', 'biodevas-members'),
            'manage_options',
            'bdv-members-settings',
            [$this, 'render_settings_page']
        );

        add_submenu_page(
            'bdv-members',
            __('Registros', 'biodevas-members'),
            __('Registros', 'biodevas-members'),
            'manage_options',
            'bdv-members-logs',
            [$this, 'render_logs_page']
        );
    }

    /* ── Assets ────────────────────────────────── */

    public function enqueue_assets(string $hook): void
    {
        if (strpos($hook, 'bdv-members') === false) {
            return;
        }
        wp_enqueue_style(
            'bdv-members-admin',
            BDV_MEMBERS_URL . 'assets/css/biodevas-members-admin.css',
            [],
            BDV_MEMBERS_VERSION
        );
        wp_enqueue_script(
            'bdv-members-admin',
            BDV_MEMBERS_URL . 'assets/js/biodevas-members-admin.js',
            ['biodevas-common-admin-js'],
            BDV_MEMBERS_VERSION,
            true
        );
        wp_localize_script('bdv-members-admin', 'bdvAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bdv_admin_nonce'),
        ]);
    }

    /* ── List page ─────────────────────────────── */

    public function render_list_page(): void
    {

        // Detail view.
        if (isset($_GET['member_id'])) {
            $this->render_detail((int) $_GET['member_id']);
            return;
        }

        $list = new Admin_List();
        $list->prepare_items();
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">
                <?php esc_html_e('Miembros Biodevas', 'biodevas-members'); ?>
            </h1>
            <a href="<?php echo esc_url(admin_url('post-new.php?post_type=miembro')); ?>" class="page-title-action">
                <?php esc_html_e('Añadir nuevo', 'biodevas-members'); ?>
            </a>
            <hr class="wp-header-end">

            <!-- Stats bar -->
            <?php $this->render_stats_bar(); ?>

            <!-- Filters -->
            <form method="get">
                <input type="hidden" name="page" value="bdv-members">
                <?php $list->search_box(__('Buscar', 'biodevas-members'), 'bdv-search'); ?>
                <?php $list->display(); ?>
            </form>

            <!-- CSV export -->
            <p style="margin-top:1rem">
                <a href="<?php echo esc_url(admin_url('admin-ajax.php?action=bdv_export_csv&nonce=' . wp_create_nonce('bdv_export_csv'))); ?>"
                    class="button">📥
                    <?php esc_html_e('Exportar CSV', 'biodevas-members'); ?>
                </a>
            </p>
        </div>
        <?php
    }

    /* ── Stats bar ─────────────────────────────── */

    private function render_stats_bar(): void
    {
        global $wpdb;

        $counts = [];
        foreach (Estados::STATES as $state) {
            $counts[$state] = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
				 JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = '_bdv_estado_miembro' AND pm.meta_value = %s
				   AND p.post_type = 'miembro' AND p.post_status = 'publish'",
                $state
            ));
        }
        ?>
        <div class="bdv-stats-bar">
            <div class="bdv-stat"><span class="bdv-stat-num">
                    <?php echo $counts['activo']; ?>
                </span> <?php esc_html_e('Activos', 'biodevas-members'); ?></div>
            <div class="bdv-stat"><span class="bdv-stat-num">
                    <?php echo $counts['pendiente_pago'] + $counts['pendiente_documentacion']; ?>
                </span> <?php esc_html_e('Pendientes', 'biodevas-members'); ?></div>
            <div class="bdv-stat"><span class="bdv-stat-num">
                    <?php echo $counts['baja']; ?>
                </span> <?php esc_html_e('Bajas', 'biodevas-members'); ?></div>
            <div class="bdv-stat"><span class="bdv-stat-num">
                    <?php echo array_sum($counts); ?>
                </span> <?php esc_html_e('Total', 'biodevas-members'); ?></div>
        </div>
        <?php
    }

    /* ── Detail view ───────────────────────────── */

    private function render_detail(int $post_id): void
    {
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'miembro') {
            echo '<div class="wrap"><p>Miembro no encontrado.</p></div>';
            return;
        }

        $meta = fn(string $key) => get_post_meta($post_id, '_bdv_' . $key, true);
        $estado = $meta('estado_miembro') ?: 'pendiente_documentacion';
        $history = Estados::get_history($post_id);
        $terms = wp_get_object_terms($post_id, 'tipo_miembro', ['fields' => 'names']);
        ?>
        <div class="wrap">
            <h1>
                <a href="<?php echo esc_url(admin_url('admin.php?page=bdv-members')); ?>">← <?php esc_html_e('Listado', 'biodevas-members'); ?></a>
                &nbsp;
                <?php echo esc_html($post->post_title); ?>
                <?php echo Estados::badge_html($estado); ?>
                &nbsp;
                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=bdv_pdf_card&member_id=' . $post_id), 'bdv_pdf_card_' . $post_id)); ?>" 
                   class="button" target="_blank">🪪 <?php esc_html_e('Ver Tarjeta', 'biodevas-members'); ?></a>
            </h1>
            <hr class="wp-header-end">

            <div class="bdv-detail-grid">
                <div class="bdv-detail-card">
                    <h3><?php esc_html_e('Datos personales', 'biodevas-members'); ?></h3>
                    <table class="widefat striped">
                        <tr>
                            <th><?php esc_html_e('Email', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html($meta('email')); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('DNI', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html($meta('dni')); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Teléfono', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html($meta('telefono')); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('WhatsApp', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html($meta('whatsapp')); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Dirección', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html($meta('direccion') . ', ' . $meta('municipio')); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('F. Nacimiento', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html($meta('fecha_nacimiento')); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Tipo', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html(implode(', ', $terms)); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Plan', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html($meta('plan') . ($meta('sub_plan') ? ' / ' . $meta('sub_plan') : '')); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Forma de pago', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html($meta('forma_pago')); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Alta', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo get_the_date('d/m/Y', $post); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('Renovación', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html($meta('fecha_renovacion')); ?>
                            </td>
                        </tr>
                        <tr>
                            <th><?php esc_html_e('RGPD', 'biodevas-members'); ?></th>
                            <td>
                                <?php echo esc_html($meta('rgpd_version')); ?> —
                                <?php echo esc_html($meta('rgpd_timestamp')); ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="bdv-detail-card">
                    <h3><?php esc_html_e('Cambiar estado', 'biodevas-members'); ?></h3>
                    <form id="bdv-state-form">
                        <input type="hidden" name="post_id" value="<?php echo (int) $post_id; ?>">
                        <select name="nuevo_estado">
                            <?php foreach (Estados::TRANSITIONS[$estado] ?? [] as $target): ?>
                                <option value="<?php echo esc_attr($target); ?>">
                                    <?php echo esc_html(Estados::LABELS[$target]); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" name="nota" placeholder="<?php esc_attr_e('Nota (opcional)', 'biodevas-members'); ?>" style="margin-top:.5rem;width:100%">
                        <button type="submit" class="button button-primary" style="margin-top:.5rem"><?php esc_html_e('Cambiar estado', 'biodevas-members'); ?></button>
                    </form>

                    <h3 style="margin-top:1.5rem"><?php esc_html_e('Historial', 'biodevas-members'); ?></h3>
                    <?php if (empty($history)): ?>
                        <p><?php esc_html_e('Sin historial todavía.', 'biodevas-members'); ?></p>
                    <?php else: ?>
                        <table class="widefat striped">
                            <thead>
                                <tr>
                                    <th><?php esc_html_e('De', 'biodevas-members'); ?></th>
                                    <th><?php esc_html_e('A', 'biodevas-members'); ?></th>
                                    <th><?php esc_html_e('Fecha', 'biodevas-members'); ?></th>
                                    <th><?php esc_html_e('Nota', 'biodevas-members'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_reverse($history) as $entry): ?>
                                    <tr>
                                        <td>
                                            <?php echo esc_html(Estados::LABELS[$entry['de']] ?? $entry['de']); ?>
                                        </td>
                                        <td>
                                            <?php echo esc_html(Estados::LABELS[$entry['a']] ?? $entry['a']); ?>
                                        </td>
                                        <td>
                                            <?php echo esc_html($entry['fecha']); ?>
                                        </td>
                                        <td>
                                            <?php echo esc_html($entry['nota']); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Logs Section -->
            <div class="bdv-detail-card" style="margin-top: 2rem;">
                <h3><?php esc_html_e('Registros de actividad', 'biodevas-members'); ?></h3>
                <?php
                global $wpdb;
                $table_logs = $wpdb->prefix . 'biodevas_logs';
                $logs = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM $table_logs WHERE object_id = %d ORDER BY created_at DESC LIMIT 20",
                    $post_id
                ));

                if ($logs): ?>
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th style="width: 170px;"><?php esc_html_e('Fecha', 'biodevas-members'); ?></th>
                                <th style="width: 100px;"><?php esc_html_e('Nivel', 'biodevas-members'); ?></th>
                                <th><?php esc_html_e('Mensaje', 'biodevas-members'); ?></th>
                                <th><?php esc_html_e('Contexto', 'biodevas-members'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?php echo esc_html($log->created_at); ?></td>
                                    <td>
                                        <span style="padding: 2px 6px; border-radius: 3px; font-weight: bold; background: <?php 
                                            echo $log->level === 'error' ? '#d63638' : ($log->level === 'warning' ? '#eba313' : '#72aee6'); 
                                        ?>; color: #fff; font-size: 10px;">
                                            <?php echo esc_html(strtoupper($log->level)); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html($log->message); ?></td>
                                    <td><code><?php echo esc_html($log->context); ?></code></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No hay registros de actividad para este miembro.</p>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /* ── Settings page (delegates) ─────────────── */

    public function render_settings_page(): void
    {
        $settings = new Admin_Settings();
        $settings->render();
    }

    public function render_logs_page(): void
    {
        Admin_Logs::render();
    }

    /* ── Dashboard widget ──────────────────────── */

    public function dashboard_widget(): void
    {
        wp_add_dashboard_widget(
            'bdv_members_widget',
            __('🍁 Miembros Biodevas', 'biodevas-members'),
            function () {
                global $wpdb;
                $total = (int) $wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'miembro' AND post_status = 'publish'"
                );
                $activos = (int) $wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id
					 WHERE pm.meta_key = '_bdv_estado_miembro' AND pm.meta_value = 'activo'
					   AND p.post_type = 'miembro' AND p.post_status = 'publish'"
                );
                echo '<p>' . sprintf(
                    esc_html__('<strong>%d</strong> activos de <strong>%d</strong> registrados.', 'biodevas-members'),
                    $activos,
                    $total
                ) . '</p>';
                echo '<a href="' . esc_url(admin_url('admin.php?page=bdv-members')) . '" class="button">' . esc_html__('Ver listado completo', 'biodevas-members') . '</a>';
            }
        );
    }

    /* ── AJAX: Quick state change ──────────────── */

    public function ajax_change_state(): void
    {
        check_ajax_referer('bdv_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Sin permisos.', 'biodevas-members'));
        }

        $post_id = (int) ($_POST['post_id'] ?? 0);
        $state = sanitize_text_field($_POST['nuevo_estado'] ?? '');
        $note = sanitize_text_field($_POST['nota'] ?? '');

        $result = Estados::change($post_id, $state, $note);
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        wp_send_json_success([
            'estado' => $state,
            'badge' => Estados::badge_html($state),
        ]);
    }

    public function ajax_log_whatsapp(): void
    {
        check_ajax_referer('bdv_admin_nonce', 'nonce');
        $post_id = (int) ($_POST['post_id'] ?? 0);
        if (!$post_id) wp_die();

        $now = current_time('mysql');
        update_post_meta($post_id, '_bdv_ultimo_contacto_whatsapp', $now);
        update_post_meta($post_id, '_bdv_ultimo_contacto', $now);

        \Biodevas\Common\Logger::info(
            __('Se ha iniciado contacto por WhatsApp desde el panel de administración.', 'biodevas-members'),
            'Members/Audit',
            $post_id
        );
        wp_send_json_success();
    }
}
