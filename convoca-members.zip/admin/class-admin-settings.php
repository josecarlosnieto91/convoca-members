<?php
/**
 * Settings page: general settings + plans + email template editor.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class Admin_Settings
{

    public function __construct()
    {
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function register_settings(): void
    {
        register_setting('bdv_members_settings_group', 'bdv_members_settings', [
            'sanitize_callback' => [$this, 'sanitize_settings'],
        ]);
        register_setting('bdv_members_plans_group', 'bdv_members_plans', [
            'sanitize_callback' => [$this, 'sanitize_plans'],
        ]);
        register_setting('bdv_members_volunteers_group', 'bdv_volunteer_fields', [
            'sanitize_callback' => [$this, 'sanitize_volunteer_fields'],
        ]);
        register_setting('bdv_members_volunteers_group', 'bdv_volunteer_legal_text', [
            'sanitize_callback' => 'wp_kses_post',
        ]);
    }

    public function sanitize_settings($input): array
    {
        if (!is_array($input)) {
            return [];
        }
        return [
            'admin_email' => sanitize_email($input['admin_email'] ?? ''),
            'iban' => sanitize_text_field($input['iban'] ?? ''),
            'rgpd_version' => sanitize_text_field($input['rgpd_version'] ?? '1.0'),
            'sender_name' => sanitize_text_field($input['sender_name'] ?? get_bloginfo('name')),
        ];
    }

    public function sanitize_plans($input): array
    {
        if (!is_array($input)) {
            return [];
        }
        $sanitized = [];

        foreach ($input as $key => $plan) {
            // If checking for removal/inactive, logic goes here.
            // We use the key provided in the input, ensuring it's safe.
            $key = sanitize_key($key);
            if (empty($key)) {
                continue;
            }

            $sanitized[$key] = [
                'label' => sanitize_text_field($plan['label'] ?? ''),
                'price' => (float) ($plan['price'] ?? 0),
                'hours' => (float) ($plan['hours'] ?? 0),
                'modalidad' => sanitize_text_field($plan['modalidad'] ?? 'Numerario'),
                'payment_methods' => array_map('sanitize_text_field', $plan['payment_methods'] ?? []),
                'url_bizum' => sanitize_url($plan['url_bizum'] ?? ''),
                'url_tarjeta' => sanitize_url($plan['url_tarjeta'] ?? ''),
                'advantages' => array_filter(array_map('trim', explode("\n", $plan['advantages_raw'] ?? ''))),
                'active' => isset($plan['active']) ? (bool) $plan['active'] : false,
                'order' => (int) ($plan['order'] ?? 0),
                'emoji' => sanitize_text_field($plan['emoji'] ?? ''),
                'description' => sanitize_textarea_field($plan['description'] ?? ''),
            ];
        }

        // Sort by order.
        uasort($sanitized, function ($a, $b) {
            return ($a['order'] ?? 0) <=> ($b['order'] ?? 0);
        });

        return $sanitized;
    }

    public function sanitize_volunteer_fields($input): array
    {
        if (!is_array($input)) {
            return [];
        }
        $sanitized = [];
        foreach ($input as $field) {
            $name = sanitize_key($field['name'] ?? '');
            if (empty($name)) {
                continue;
            }
            $sanitized[] = [
                'name' => $name,
                'label' => sanitize_text_field($field['label'] ?? ''),
                'type' => sanitize_key($field['type'] ?? 'text'),
                'options' => sanitize_textarea_field($field['options'] ?? ''),
                'required' => !empty($field['required']),
            ];
        }
        return $sanitized;
    }

    private function get_active_tab(): string
    {
        return isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'general';
    }

    public function render(): void
    {
        $active_tab = $this->get_active_tab();
        ?>
        <div class="wrap bdv-members-settings-wrap">
            <div class="bdv-admin-header" style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px;">
                <img src="<?php echo esc_url(BDV_MEMBERS_URL . 'assets/images/logo.png'); ?>" alt="Biodevas Members" style="width: 80px; height: 80px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                <div>
                    <h1 style="margin: 0; padding: 0;"><?php esc_html_e('Ajustes — Miembros Biodevas', 'biodevas-members'); ?></h1>
                    <p style="margin: 5px 0 0; color: #666; font-size: 1.1em;"><?php _e('Gestión de socios, planes y comunicaciones', 'biodevas-members'); ?></p>
                </div>
            </div>

            <nav class="nav-tab-wrapper">
                <a href="?page=bdv-members-settings&tab=general"
                    class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('General', 'biodevas-members'); ?>
                </a>
                <a href="?page=bdv-members-settings&tab=plans"
                    class="nav-tab <?php echo $active_tab === 'plans' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Planes de Socio', 'biodevas-members'); ?>
                </a>
                <a href="?page=bdv-members-settings&tab=emails"
                    class="nav-tab <?php echo $active_tab === 'emails' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Plantillas de Email', 'biodevas-members'); ?>
                </a>
                <a href="?page=bdv-members-settings&tab=volunteers"
                    class="nav-tab <?php echo $active_tab === 'volunteers' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Campos Voluntariado', 'biodevas-members'); ?>
                </a>
            </nav>

            <div class="bdv-settings-content">
                <?php
                switch ($active_tab) {
                    case 'plans':
                        $this->render_plans_tab();
                        break;
                    case 'emails':
                        $this->render_emails_tab();
                        break;
                    case 'volunteers':
                        $this->render_volunteers_tab();
                        break;
                    case 'general':
                    default:
                        $this->render_general_tab();
                        break;
                }
                ?>
            </div>
        </div>
        <?php
    }

    private function render_general_tab(): void
    {
        $settings = get_option('bdv_members_settings', []);
        ?>
        <form method="post" action="options.php">
            <?php settings_fields('bdv_members_settings_group'); ?>

            <table class="form-table">
                <tr>
                    <th><label for="admin_email"><?php esc_html_e('Email administrador', 'biodevas-members'); ?></label></th>
                    <td>
                        <input type="email" id="admin_email" name="bdv_members_settings[admin_email]"
                            value="<?php echo esc_attr($settings['admin_email'] ?? ''); ?>" class="regular-text">
                        <p class="description"><?php esc_html_e('Recibe notificaciones de nuevas altas.', 'biodevas-members'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="sender_name"><?php esc_html_e('Nombre remitente emails', 'biodevas-members'); ?></label>
                    </th>
                    <td>
                        <input type="text" id="sender_name" name="bdv_members_settings[sender_name]"
                            value="<?php echo esc_attr($settings['sender_name'] ?? get_bloginfo('name')); ?>"
                            class="regular-text">
                    </td>
                </tr>
                <tr>
                    <th><label for="iban"><?php esc_html_e('IBAN para transferencias', 'biodevas-members'); ?></label></th>
                    <td>
                        <input type="text" id="iban" name="bdv_members_settings[iban]"
                            value="<?php echo esc_attr($settings['iban'] ?? ''); ?>" class="regular-text"
                            placeholder="ES00 0000 0000 0000 0000 0000">
                    </td>
                </tr>
                <tr>
                    <th><label for="rgpd_version"><?php esc_html_e('Versión texto legal RGPD', 'biodevas-members'); ?></label>
                    </th>
                    <td>
                        <input type="text" id="rgpd_version" name="bdv_members_settings[rgpd_version]"
                            value="<?php echo esc_attr($settings['rgpd_version'] ?? '1.0'); ?>" class="small-text">
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
        <?php
    }

    private function render_plans_tab(): void
    {
        $plans = CPT_Miembro::get_plans();

        // Ensure at least one empty plan slot for adding new ones is hard to handle in simple options.php form.
        // We will use JS to clone a template or just save what we have. 
        // For simplicity in this first iteration: we iterate existing + provide a "Add New" block at the bottom 
        // that serves to create a new key.
        ?>
        <form method="post" action="options.php">
            <?php settings_fields('bdv_members_plans_group'); ?>

            <div id="bdv-plans-container">
                <?php foreach ($plans as $key => $plan): ?>
                    <?php $this->render_single_plan_card($key, $plan); ?>
                <?php endforeach; ?>
            </div>

            <!-- "Add New" Logic: We can generate a random unique ID for new plans in JS or PHP. -->
            <!-- For now, we will add a hidden template or rely on the user to manually add via code? 
                 No, request says "Add from settings". 
                 Strategy: A simple "Add Plan" button that reveals a new empty card with a key input. -->

            <div class="bdv-add-plan-wrapper"
                style="margin-top: 20px; padding: 20px; border: 2px dashed #ccc; text-align: center;">
                <h3><?php esc_html_e('Añadir Nuevo Plan', 'biodevas-members'); ?></h3>
                <p><?php esc_html_e('Para añadir un plan, guarda primero los cambios actuales.', 'biodevas-members'); ?></p>
                <div style="text-align: left; max_width: 600px; margin: 0 auto; display: inline-block;">
                    <label><?php esc_html_e('ID del Plan (ej: <code>socio-colaborador</code>):', 'biodevas-members'); ?> </label>
                    <input type="text" id="new_plan_key" placeholder="slug-unico">
                    <button type="button" class="button" onclick="bdvAddNewPlan()"><?php esc_html_e('Añadir', 'biodevas-members'); ?></button>
                </div>
            </div>

            <script>
                function bdvAddNewPlan() {
                    var key = document.getElementById('new_plan_key').value.trim();
                    if (!key) { alert('<?php echo esc_js(__('Escribe un ID único para el plan', 'biodevas-members')); ?>'); return; }
                    // Simple regex for slug
                    key = key.toLowerCase().replace(/[^a-z0-9-]/g, '-');

                    var container = document.getElementById('bdv-plans-container');
                    // Check if exists
                    if (document.querySelector('input[name="bdv_members_plans[' + key + '][label]"]')) {
                        alert('<?php echo esc_js(__('Este ID ya existe.', 'biodevas-members')); ?>');
                        return;
                    }

                    var html = `<?php
                    // Render a clean template string
                    $clean_plan = [
                        'label' => __('Nuevo Plan', 'biodevas-members'),
                        'price' => 0,
                        'hours' => 0,
                        'modalidad' => 'Numerario',
                        'active' => 1,
                        'order' => 0,
                        'emoji' => '⭐',
                        'description' => '',
                        'payment_methods' => [],
                        'url_bizum' => '',
                        'url_tarjeta' => '',
                        'advantages' => []
                    ];
                    // We need to escape newlines for JS string
                    ob_start();
                    $this->render_single_plan_card('__KEY__', $clean_plan);
                    $output = ob_get_clean();
                    echo str_replace(["\r", "\n"], '', addslashes($output));
                    ?>`;

                    var newCard = html.replace(/__KEY__/g, key);
                    var div = document.createElement('div');
                    div.innerHTML = newCard;
                    container.appendChild(div.firstElementChild);
                    document.getElementById('new_plan_key').value = '';
                }
            </script>

            <?php submit_button(__('Guardar Planes', 'biodevas-members')); ?>
        </form>
        <?php
    }

    private function render_single_plan_card($key, $plan): void
    {
        $active = isset($plan['active']) ? (bool) $plan['active'] : true; // Default active if not set
        ?>
        <div class="bdv-plan-card postbox" style="margin-bottom: 20px;">
            <div class="postbox-header"
                style="padding: 10px; display: flex; justify-content: space-between; align-items: center;">
                <h2 style="margin:0; font-size: 1.2em;">
                    <span class="bad-emoji"><?php echo esc_html($plan['emoji'] ?? '📄'); ?></span>
                    <?php echo esc_html($plan['label']); ?>
                    <code style="opacity: 0.5;">(<?php echo esc_html($key); ?>)</code>
                </h2>
                <div>
                    <label>
                        <input type="checkbox" name="bdv_members_plans[<?php echo esc_attr($key); ?>][active]" value="1" <?php checked($active); ?>>
                        <?php esc_html_e('Activo', 'biodevas-members'); ?>
                    </label>
                    <button type="button" class="button-link-delete" style="color: #b32d2e; margin-left: 15px;"
                        onclick="if(confirm('<?php echo esc_js(__('¿Eliminar este plan al guardar? (Desmarca activo para ocultarlo)', 'biodevas-members')); ?>')) { this.closest('.bdv-plan-card').remove(); }">
                        <?php esc_html_e('Eliminar', 'biodevas-members'); ?>
                    </button>
                </div>
            </div>
            <div class="inside" style="padding: 10px;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div>
                        <p>
                            <label><strong><?php esc_html_e('Nombre visible:', 'biodevas-members'); ?></strong></label>
                            <input type="text" name="bdv_members_plans[<?php echo esc_attr($key); ?>][label]"
                                value="<?php echo esc_attr($plan['label']); ?>" class="large-text">
                        </p>
                        <div style="display: flex; gap: 10px;">
                            <p style="flex:1;">
                                <label><strong><?php esc_html_e('Emoji:', 'biodevas-members'); ?></strong></label>
                                <input type="text" name="bdv_members_plans[<?php echo esc_attr($key); ?>][emoji]"
                                    value="<?php echo esc_attr($plan['emoji'] ?? ''); ?>" class="small-text">
                            </p>
                            <p style="flex:1;">
                                <label><strong><?php esc_html_e('Orden:', 'biodevas-members'); ?></strong></label>
                                <input type="number" name="bdv_members_plans[<?php echo esc_attr($key); ?>][order]"
                                    value="<?php echo esc_attr($plan['order'] ?? 0); ?>" class="small-text">
                            </p>
                        </div>
                        <p>
                            <label><strong><?php esc_html_e('Descripción:', 'biodevas-members'); ?></strong></label>
                            <textarea name="bdv_members_plans[<?php echo esc_attr($key); ?>][description]" rows="2"
                                class="large-text"><?php echo esc_textarea($plan['description'] ?? ''); ?></textarea>
                        </p>
                    </div>
                    <div>
                        <div style="display: flex; gap: 10px;">
                            <p style="flex:1;">
                                <label><strong><?php esc_html_e('Precio (€):', 'biodevas-members'); ?></strong></label>
                                <input type="number" step="0.01" name="bdv_members_plans[<?php echo esc_attr($key); ?>][price]"
                                    value="<?php echo esc_attr($plan['price']); ?>" class="small-text">
                            </p>
                            <p style="flex:1;">
                                <label><strong><?php esc_html_e('Horas Voluntariado:', 'biodevas-members'); ?></strong></label>
                                <input type="number" step="0.5" name="bdv_members_plans[<?php echo esc_attr($key); ?>][hours]"
                                    value="<?php echo esc_attr($plan['hours']); ?>" class="small-text">
                            </p>
                            <p style="flex:1;">
                                <label><strong><?php esc_html_e('Modalidad:', 'biodevas-members'); ?></strong></label><br>
                                <select name="bdv_members_plans[<?php echo esc_attr($key); ?>][modalidad]">
                                    <?php foreach (['Numerario', 'Familiar', 'Juvenil'] as $m): ?>
                                        <option value="<?php echo esc_attr($m); ?>" <?php selected($plan['modalidad'], $m); ?>>
                                            <?php echo esc_html($m); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </p>
                        </div>

                        <div style="background: #f0f0f1; padding: 10px; border-radius: 4px;">
                            <p style="margin-top:0;"><strong><?php esc_html_e('Pagos:', 'biodevas-members'); ?></strong></p>
                            <?php $methods = $plan['payment_methods'] ?? []; ?>
                            <label><input type="checkbox"
                                    name="bdv_members_plans[<?php echo esc_attr($key); ?>][payment_methods][]" value="bizum"
                                    <?php checked(in_array('bizum', $methods)); ?>> Bizum</label>
                            <label><input type="checkbox"
                                    name="bdv_members_plans[<?php echo esc_attr($key); ?>][payment_methods][]" value="tarjeta"
                                    <?php checked(in_array('tarjeta', $methods)); ?>> Tarjeta</label>
                            <label><input type="checkbox"
                                    name="bdv_members_plans[<?php echo esc_attr($key); ?>][payment_methods][]"
                                    value="transferencia" <?php checked(in_array('transferencia', $methods)); ?>>
                                <?php esc_html_e('Transferencia', 'biodevas-members'); ?></label>
                        </div>
                    </div>
                </div>

                <p>
                    <label><strong><?php esc_html_e('Ventajas (una por línea):', 'biodevas-members'); ?></strong></label>
                    <textarea name="bdv_members_plans[<?php echo esc_attr($key); ?>][advantages_raw]" rows="4"
                        class="large-text"><?php
                        $adv = $plan['advantages'] ?? [];
                        if (is_array($adv))
                            echo esc_textarea(implode("\n", $adv));
                        ?></textarea>
                </p>
            </div>
        </div>
        <?php
    }

    private function render_emails_tab(): void
    {
        // Save email templates logic specifically for this tab if needed differently, 
        // but since we want to leverage options.php, we might need to register a setting for templates too?
        // THE PREVIOUS CODE handled this manually via POST check.
        // We will keep that manual saving logic but integrate it into the flow.

        if (isset($_POST['bdv_save_templates']) && check_admin_referer('bdv_templates_nonce')) {
            $templates = [];
            foreach (Email_Manager::TEMPLATES as $slug) {
                $templates[$slug] = [
                    'subject' => sanitize_text_field($_POST['tpl_' . $slug . '_subject'] ?? ''),
                    'body' => wp_kses_post($_POST['tpl_' . $slug . '_body'] ?? ''), // Allow HTML
                ];
            }
            Email_Manager::save_templates($templates);
            echo '<div class="updated"><p>' . esc_html__('Plantillas guardadas.', 'biodevas-members') . '</p></div>';
        }

        $templates = Email_Manager::get_templates();
        $tpl_labels = [
            'solicitud_recibida'    => __('Solicitud recibida', 'biodevas-members'),
            'bienvenida'            => __('Bienvenida (activación)', 'biodevas-members'),
            'recordatorio_pago'     => __('Recordatorio de pago', 'biodevas-members'),
            'renovacion'            => __('Renovación anual (30 días)', 'biodevas-members'),
            'renovacion_automatica' => __('Aviso renovación automática', 'biodevas-members'),
            'renovacion_completada' => __('Renovación completada 🎉', 'biodevas-members'),
        ];

        ?>
        <form method="post">
            <?php wp_nonce_field('bdv_templates_nonce'); ?>
            <p class="description">
                <?php esc_html_e('Variables disponibles:', 'biodevas-members'); ?>
                <code>{nombre}</code>, <code>{plan}</code>, <code>{importe}</code>, <code>{link_pago}</code>,
                <code>{fecha_baja}</code>, <code>{numero_socio}</code>
            </p>

            <?php foreach (Email_Manager::TEMPLATES as $slug):
                $tpl = $templates[$slug] ?? ['subject' => '', 'body' => ''];
                ?>
                <div class="bdv-template-card postbox">
                    <div class="postbox-header" style="padding:10px;">
                        <h2 style="margin:0;"><?php echo esc_html($tpl_labels[$slug] ?? $slug); ?></h2>
                    </div>
                    <div class="inside">
                        <p>
                            <label><strong><?php esc_html_e('Asunto:', 'biodevas-members'); ?></strong></label>
                            <input type="text" name="tpl_<?php echo esc_attr($slug); ?>_subject"
                                value="<?php echo esc_attr($tpl['subject']); ?>" class="large-text">
                        </p>
                        <p>
                            <label><strong><?php esc_html_e('Cuerpo (HTML permitido):', 'biodevas-members'); ?></strong></label>
                            <?php
                            wp_editor($tpl['body'], 'tpl_' . $slug . '_body', [
                                'textarea_name' => 'tpl_' . $slug . '_body',
                                'textarea_rows' => 10,
                                'media_buttons' => false,
                                'teeny' => true
                            ]);
                            ?>
                        </p>
                    </div>
                </div>
            <?php endforeach; ?>

            <input type="hidden" name="bdv_save_templates" value="1">
            <?php submit_button(__('Guardar Plantillas', 'biodevas-members')); ?>
        </form>
        <?php
    }
    private function render_volunteers_tab(): void
    {
        $fields = get_option('bdv_volunteer_fields', []);
        $legal_text = get_option('bdv_volunteer_legal_text', '');
        ?>
        <form method="post" action="options.php">
            <?php settings_fields('bdv_members_volunteers_group'); ?>

            <h2><?php esc_html_e('Texto Legal (Declaración Responsable)', 'biodevas-members'); ?></h2>
            <p class="description"><?php esc_html_e('Este texto se mostrará junto a un checkbox obligatorio al final del formulario de voluntariado.', 'biodevas-members'); ?></p>
            <?php
            wp_editor($legal_text, 'bdv_volunteer_legal_text', [
                'textarea_name' => 'bdv_volunteer_legal_text',
                'textarea_rows' => 10,
                'media_buttons' => false,
                'teeny' => true
            ]);
            ?>

            <h2 style="margin-top: 40px;"><?php esc_html_e('Campos Personalizados', 'biodevas-members'); ?></h2>
            <p class="description"><?php esc_html_e('Estos campos se solicitarán en el formulario de registro de voluntarios. Los campos base (Nombre, DNI, Email, Teléfono) ya están incluidos y no necesitan añadirse aquí.', 'biodevas-members'); ?></p>

            <div id="bdv-fields-container">
                <?php foreach ($fields as $index => $field): ?>
                    <?php $this->render_single_field_card($index, $field); ?>
                <?php endforeach; ?>
            </div>

            <div class="bdv-add-field-wrapper" style="margin-top: 20px; padding: 20px; border: 2px dashed #ccc; text-align: center;">
                <h3><?php esc_html_e('Añadir Nuevo Campo', 'biodevas-members'); ?></h3>
                <p><?php esc_html_e('Para añadir un campo, guarda primero los cambios actuales.', 'biodevas-members'); ?></p>
                <div style="text-align: left; max_width: 600px; margin: 0 auto; display: inline-block;">
                    <label><?php esc_html_e('ID del Campo (solo minúsculas y guiones, ej: alergias):', 'biodevas-members'); ?> </label>
                    <input type="text" id="new_field_name" placeholder="id-del-campo">
                    <button type="button" class="button" onclick="bdvAddNewField()"><?php esc_html_e('Añadir', 'biodevas-members'); ?></button>
                </div>
            </div>

            <script>
                function bdvAddNewField() {
                    var name = document.getElementById('new_field_name').value.trim();
                    if (!name) { alert('Escribe un ID único para el campo'); return; }
                    name = name.toLowerCase().replace(/[^a-z0-9-]/g, '-');

                    var container = document.getElementById('bdv-fields-container');
                    if (document.querySelector('input[name="bdv_volunteer_fields[' + name + '][label]"]')) {
                        alert('Este ID ya existe.');
                        return;
                    }

                    var html = `<?php
                    $clean_field = [
                        'label' => 'Nuevo Campo',
                        'type' => 'text',
                        'options' => '',
                        'required' => false
                    ];
                    ob_start();
                    $this->render_single_field_card('__INDEX__', $clean_field);
                    $output = ob_get_clean();
                    echo str_replace(["\r", "\n"], '', addslashes($output));
                    ?>`;

                    var newCard = html.replace(/__INDEX__/g, name);
                    var div = document.createElement('div');
                    div.innerHTML = newCard;
                    
                    // Update input names to use the real name
                    var inputs = div.querySelectorAll('[name*="__INDEX__"]');
                    inputs.forEach(input => {
                        input.name = input.name.replace('__INDEX__', name);
                    });
                    
                    // Set the hidden name field
                    div.querySelector('input.field-name-input').value = name;

                    container.appendChild(div.firstElementChild);
                    document.getElementById('new_field_name').value = '';
                }
            </script>

            <p class="submit">
                <?php submit_button(__('Guardar Campos y Textos', 'biodevas-members'), 'primary', 'submit', false); ?>
            </p>
        </form>
        <?php
    }

    private function render_single_field_card($index, $field): void
    {
        $name = esc_attr($field['name'] ?? $index);
        ?>
        <div class="bdv-field-card postbox" style="margin-bottom: 15px;">
            <div class="postbox-header" style="padding: 10px; display: flex; justify-content: space-between; align-items: center;">
                <h3 style="margin:0;">
                    <?php echo esc_html($field['label'] ?? 'Nuevo Campo'); ?>
                    <code style="opacity: 0.5;">(<?php echo $name; ?>)</code>
                </h3>
                <button type="button" class="button-link-delete" style="color: #b32d2e;"
                    onclick="if(confirm('¿Eliminar este campo al guardar?')) { this.closest('.bdv-field-card').remove(); }">
                    <?php esc_html_e('Eliminar', 'biodevas-members'); ?>
                </button>
            </div>
            <div class="inside" style="padding: 10px;">
                <input type="hidden" class="field-name-input" name="bdv_volunteer_fields[<?php echo $index; ?>][name]" value="<?php echo $name; ?>">
                
                <div style="display: flex; gap: 20px; align-items: flex-start;">
                    <div style="flex: 1;">
                        <p>
                            <label><strong><?php esc_html_e('Etiqueta (Label):', 'biodevas-members'); ?></strong></label><br>
                            <input type="text" name="bdv_volunteer_fields[<?php echo $index; ?>][label]" value="<?php echo esc_attr($field['label'] ?? ''); ?>" class="large-text">
                        </p>
                        <p>
                            <label><strong><?php esc_html_e('Tipo de campo:', 'biodevas-members'); ?></strong></label><br>
                            <select name="bdv_volunteer_fields[<?php echo $index; ?>][type]">
                                <?php
                                $types = [
                                    'text' => 'Texto corto',
                                    'textarea' => 'Texto largo (párrafo)',
                                    'email' => 'Email',
                                    'tel' => 'Teléfono',
                                    'number' => 'Número',
                                    'date' => 'Fecha',
                                    'select' => 'Desplegable (Select)',
                                    'checkbox' => 'Casilla de verificación (Checkbox)'
                                ];
                                foreach ($types as $val => $label) {
                                    echo '<option value="' . esc_attr($val) . '" ' . selected($field['type'] ?? 'text', $val, false) . '>' . esc_html($label) . '</option>';
                                }
                                ?>
                            </select>
                        </p>
                        <p>
                            <label>
                                <input type="checkbox" name="bdv_volunteer_fields[<?php echo $index; ?>][required]" value="1" <?php checked(!empty($field['required'])); ?>>
                                <strong><?php esc_html_e('Campo obligatorio', 'biodevas-members'); ?></strong>
                            </label>
                        </p>
                    </div>
                    <div style="flex: 1;">
                        <p>
                            <label><strong><?php esc_html_e('Opciones (solo para Select):', 'biodevas-members'); ?></strong></label><br>
                            <span class="description">Una opción por línea. Ej: Sí \n No \n Tal vez</span><br>
                            <textarea name="bdv_volunteer_fields[<?php echo $index; ?>][options]" rows="4" class="large-text"><?php echo esc_textarea($field['options'] ?? ''); ?></textarea>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}
