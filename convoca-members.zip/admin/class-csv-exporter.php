<?php
/**
 * CSV exporter for member data.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class CSV_Exporter
{

    public function __construct()
    {
        add_action('wp_ajax_bdv_export_csv', [$this, 'export']);
    }

    public function export(): void
    {
        check_ajax_referer('bdv_export_csv', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_die('Sin permisos.');
        }

        $args = [
            'post_type' => 'miembro',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        // Optional estado filter.
        $estado = sanitize_text_field($_GET['estado'] ?? '');
        if ($estado) {
            $args['meta_query'] = [
                ['key' => '_bdv_estado_miembro', 'value' => $estado],
            ];
        }

        $query = new \WP_Query($args);

        \Biodevas\Common\Utils::csv_headers('biodevas-miembros-' . gmdate('Y-m-d') . '.csv');
        $out = fopen('php://output', 'w');

        // Column headers.
        fputcsv($out, [
            'ID',
            'Nombre',
            'Email',
            'DNI',
            'Teléfono',
            'WhatsApp',
            'Dirección',
            'Municipio',
            'Tipo',
            'Estado',
            'Plan',
            'Forma pago',
            'Menor',
            'RGPD versión',
            'RGPD fecha',
            'Comunicaciones',
            'Fecha alta',
            'Fecha renovación',
            'Recurrente',
        ], ';');

        foreach ($query->posts as $post) {
            $meta = fn (string $key) => get_post_meta($post->ID, '_bdv_' . $key, true);
            $terms = wp_get_object_terms($post->ID, 'tipo_miembro', ['fields' => 'names']);

            fputcsv($out, [
                $post->ID,
                \Biodevas\Common\Utils::escape_csv_field($post->post_title),
                \Biodevas\Common\Utils::escape_csv_field($meta('email')),
                \Biodevas\Common\Utils::escape_csv_field($meta('dni')),
                \Biodevas\Common\Utils::escape_csv_field($meta('telefono')),
                \Biodevas\Common\Utils::escape_csv_field($meta('whatsapp')),
                \Biodevas\Common\Utils::escape_csv_field($meta('direccion')),
                \Biodevas\Common\Utils::escape_csv_field($meta('municipio')),
                implode(', ', $terms),
                Estados::LABELS[$meta('estado_miembro')] ?? $meta('estado_miembro'),
                $meta('plan') . ($meta('sub_plan') ? '/' . $meta('sub_plan') : ''),
                $meta('forma_pago'),
                $meta('menor_edad') === '1' ? 'Sí' : 'No',
                $meta('rgpd_version'),
                $meta('rgpd_timestamp'),
                $meta('comunicaciones_ok') === '1' ? 'Sí' : 'No',
                get_the_date('d/m/Y', $post),
                $meta('fecha_renovacion'),
                $meta('pago_recurrente') === '1' ? 'Sí' : 'No',
            ], ';');
        }

        fclose($out);
        exit;
    }
}
