<?php
/**
 * Admin view for volunteer projects.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class Admin_Proyectos extends \WP_List_Table
{
    public function __construct()
    {
        add_action('admin_menu', [$this, 'add_menu']);
    }

    /**
     * Initialize WP_List_Table (must be called after admin screen is available).
     */
    private function init_table(): void
    {
        parent::__construct([
            'singular' => 'proyecto',
            'plural'   => 'proyectos',
            'ajax'     => false,
        ]);
    }

    public function add_menu()
    {
        add_submenu_page(
            'bdv-members',
            __('Proyectos de Voluntariado', 'biodevas-members'),
            __('Proyectos', 'biodevas-members'),
            'gestionar_miembros',
            'bdv-proyectos',
            [$this, 'render_page']
        );
    }

    public function render_page()
    {
        $this->init_table();
        $this->prepare_items();
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline"><?php _e('Proyectos de Voluntariado', 'biodevas-members'); ?></h1>
            <a href="<?php echo admin_url('post-new.php?post_type=proyecto'); ?>" class="page-title-action">
                <?php _e('Añadir nuevo', 'biodevas-members'); ?>
            </a>
            <hr class="wp-header-end">

            <form method="get">
                <input type="hidden" name="post_type" value="miembro">
                <input type="hidden" name="page" value="bdv-proyectos">
                <?php
                $this->search_box(__('Buscar proyectos', 'biodevas-members'), 'proyecto');
                $this->display();
                ?>
            </form>
        </div>
        <style>
            .column-fecha_inicio, .column-fecha_fin { width: 120px; }
            .column-responsable { width: 150px; }
            .column-activo { width: 80px; }
        </style>
        <?php
    }

    public function get_columns()
    {
        return [
            'cb'           => '<input type="checkbox" />',
            'title'        => __('Título', 'biodevas-members'),
            'fecha_inicio' => __('Inicio', 'biodevas-members'),
            'fecha_fin'    => __('Fin', 'biodevas-members'),
            'responsable'  => __('Responsable', 'biodevas-members'),
            'activo'       => __('Activo', 'biodevas-members'),
        ];
    }

    protected function get_sortable_columns()
    {
        return [
            'title'        => ['title', false],
            'fecha_inicio' => ['fecha_inicio', false],
            'fecha_fin'    => ['fecha_fin', false],
        ];
    }

    public function prepare_items()
    {
        $per_page = 20;
        $current_page = $this->get_pagenum();
        $search = isset($_REQUEST['s']) ? sanitize_text_field($_REQUEST['s']) : '';

        $args = [
            'post_type'      => CPT_Proyecto::POST_TYPE,
            'post_status'    => ['publish', 'draft'],
            'posts_per_page' => $per_page,
            'offset'         => ($current_page - 1) * $per_page,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ];

        if ($search) {
            $args['s'] = $search;
        }

        $query = new \WP_Query($args);
        $this->items = $query->posts;

        $this->set_pagination_args([
            'total_items' => $query->found_posts,
            'per_page'    => $per_page,
            'total_pages' => ceil($query->found_posts / $per_page),
        ]);
    }

    public function column_cb($item)
    {
        return sprintf('<input type="checkbox" name="bulk-delete[]" value="%s" />', $item->ID);
    }

    public function column_default($item, $column_name)
    {
        $meta = CPT_Proyecto::get_meta($item->ID);

        switch ($column_name) {
            case 'title':
                $edit_link = get_edit_post_link($item->ID);
                return sprintf(
                    '<strong><a href="%s">%s</a></strong>',
                    $edit_link,
                    esc_html($item->post_title)
                );

            case 'fecha_inicio':
                return $meta['fecha_inicio'] ?? '—';

            case 'fecha_fin':
                $fin = $meta['fecha_fin'] ?? '';
                if ($fin && $fin < current_time('mysql')) {
                    return '<span style="color:#d63638;">' . esc_html($fin) . '</span>';
                }
                return $fin ?: '—';

            case 'responsable':
                $resp_id = $meta['responsable'] ?? '';
                if ($resp_id) {
                    $user = get_userdata($resp_id);
                    return $user ? esc_html($user->display_name) : '—';
                }
                return '—';

            case 'activo':
                $activo = $meta['activo'] ?? '0';
                return $activo === '1' 
                    ? '<span style="color:#00a32a;">✓ ' . __('Sí', 'biodevas-members') . '</span>'
                    : '<span style="color:#646970;">—</span>';

            default:
                return '';
        }
    }

    public function no_items()
    {
        _e('No se encontraron proyectos.', 'biodevas-members');
    }
}