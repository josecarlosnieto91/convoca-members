<?php
/**
 * Admin view for volunteering hours.
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class Admin_Horas extends \WP_List_Table
{
    public function __construct()
    {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_post_bdv_process_horas', [$this, 'process_action']);
    }

    /**
     * Initialize WP_List_Table (must be called after admin screen is available).
     */
    private function init_table(): void
    {
        parent::__construct([
            'singular' => 'hora',
            'plural'   => 'horas',
            'ajax'     => false,
        ]);
    }

    public function add_menu()
    {
        add_submenu_page(
            'bdv-members',
            __('Horas de Voluntariado', 'biodevas-members'),
            __('Horas Voluntariado', 'biodevas-members'),
            'gestionar_miembros',
            'bdv-volunteer-hours',
            [$this, 'render_page']
        );
    }

    public function render_page()
    {
        $this->init_table();
        $this->prepare_items();
        
        $proyectos = CPT_Proyecto::get_active_proyectos();
        $filter_proyecto = isset($_GET['filter_proyecto']) ? (int) $_GET['filter_proyecto'] : 0;
        
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline"><?php _e('Horas de Voluntariado', 'biodevas-members'); ?></h1>
            <hr class="wp-header-end">

            <form method="get">
                <input type="hidden" name="post_type" value="miembro">
                <input type="hidden" name="page" value="bdv-volunteer-hours">
                
                <div class="tablenav top">
                    <div class="alignleft actions">
                        <select name="filter_proyecto">
                            <option value="0"><?php _e('Todos los proyectos', 'biodevas-members'); ?></option>
                            <?php foreach ($proyectos as $id => $title): ?>
                                <option value="<?php echo esc_attr($id); ?>" <?php selected($filter_proyecto, $id); ?>>
                                    <?php echo esc_html($title); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="submit" class="button" value="<?php _e('Filtrar', 'biodevas-members'); ?>">
                    </div>
                    <?php $this->search_box(__('Buscar registros', 'biodevas-members'), 'horas'); ?>
                </div>
                
                <?php $this->display(); ?>
            </form>
        </div>
        <style>
            .column-horas { width: 80px; }
            .column-estado { width: 120px; }
            .column-proyecto { width: 150px; }
            .column-tareas { width: 200px; }
            .status-pendiente { color: #d63638; font-weight: bold; }
            .status-aprobada { color: #00a32a; font-weight: bold; }
            .status-rechazada { color: #646970; }
        </style>
        <?php
    }

    public function get_columns()
    {
        return [
            'cb'          => '<input type="checkbox" />',
            'fecha'       => __('Fecha', 'biodevas-members'),
            'socio'       => __('Socio', 'biodevas-members'),
            'proyecto'    => __('Proyecto', 'biodevas-members'),
            'tareas'      => __('Tareas', 'biodevas-members'),
            'actividad'   => __('Actividad', 'biodevas-members'),
            'horas'       => __('Horas', 'biodevas-members'),
            'descripcion' => __('Descripción', 'biodevas-members'),
            'estado'      => __('Estado', 'biodevas-members'),
            'acciones'    => __('Acciones', 'biodevas-members'),
        ];
    }

    protected function get_sortable_columns()
    {
        return [
            'fecha' => ['fecha', true],
            'socio' => ['socio', false],
            'horas' => ['horas', false],
        ];
    }

    public function prepare_items()
    {
        $per_page = 20;
        $current_page = $this->get_pagenum();
        $search = isset($_REQUEST['s']) ? sanitize_text_field($_REQUEST['s']) : '';
        $filter_proyecto = isset($_REQUEST['filter_proyecto']) ? (int) $_REQUEST['filter_proyecto'] : 0;

        $args = [
            'post_type'      => 'registro_hora',
            'post_status'    => 'any',
            'posts_per_page' => $per_page,
            'offset'         => ($current_page - 1) * $per_page,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        if ($search) {
            $args['s'] = $search;
        }

        if ($filter_proyecto > 0) {
            $args['meta_query'] = [
                ['key' => '_bdv_proyecto_id', 'value' => $filter_proyecto],
            ];
        }

        $query = new \WP_Query($args);
        $this->items = $query->posts;

        $this->set_pagination_args([
            'total_items' => $query->found_posts,
            'per_page'    => $per_page,
            'total_pages' => ceil($query->found_posts / $per_page),
        ]);
    }

    public function column_cb($item)
    {
        return sprintf('<input type="checkbox" name="bulk-delete[]" value="%s" />', $item->ID);
    }

    public function column_fecha($item)
    {
        $fecha = get_post_meta($item->ID, '_bdv_fecha', true);
        return $fecha ?: get_the_date('', $item->ID);
    }

    public function column_socio($item)
    {
        $socio_id = get_post_meta($item->ID, '_bdv_miembro_id', true);
        if (!$socio_id) return '—';
        $socio = get_post($socio_id);
        if (!$socio) return 'Socio eliminado';
        
        return sprintf(
            '<a href="%s"><strong>%s</strong></a>',
            get_edit_post_link($socio_id),
            esc_html($socio->post_title)
        );
    }

    public function column_actividad($item)
    {
        $act_id = get_post_meta($item->ID, '_bdv_actividad_id', true);
        if (!$act_id) return 'General/Otros';
        $act = get_post($act_id);
        if (!$act) return 'Actividad eliminada';
        
        return sprintf(
            '<a href="%s">%s</a>',
            get_edit_post_link($act_id),
            esc_html($act->post_title)
        );
    }

    public function column_proyecto($item)
    {
        $proyecto_id = get_post_meta($item->ID, '_bdv_proyecto_id', true);
        if (!$proyecto_id) return '—';
        $proyecto = get_post($proyecto_id);
        if (!$proyecto) return 'Proyecto eliminado';
        
        return esc_html($proyecto->post_title);
    }

    public function column_tareas($item)
    {
        $tareas = get_post_meta($item->ID, '_bdv_tareas', true);
        if (!$tareas) return '—';
        return esc_html(mb_substr($tareas, 0, 60)) . (mb_strlen($tareas) > 60 ? '...' : '');
    }

    public function column_horas($item)
    {
        return get_post_meta($item->ID, '_bdv_horas', true) . 'h';
    }

    public function column_descripcion($item)
    {
        return esc_html($item->post_content);
    }

    public function column_estado($item)
    {
        $estado = get_post_meta($item->ID, '_bdv_estado', true) ?: 'pendiente';
        $class = 'status-' . $estado;
        $label = ucfirst($estado);
        
        return sprintf('<span class="%s">%s</span>', $class, $label);
    }

    public function column_acciones($item)
    {
        $estado = get_post_meta($item->ID, '_bdv_estado', true) ?: 'pendiente';
        $actions = [];

        if ($estado !== 'aprobada') {
            $url = admin_url('admin-post.php?action=bdv_process_horas&record_id=' . $item->ID . '&new_status=aprobada');
            $url = wp_nonce_url($url, 'process_horas_' . $item->ID);
            $actions[] = sprintf('<a href="%s" style="color: green;">Aprobar</a>', $url);
        }

        if ($estado !== 'rechazada') {
            $url = admin_url('admin-post.php?action=bdv_process_horas&record_id=' . $item->ID . '&new_status=rechazada');
            $url = wp_nonce_url($url, 'process_horas_' . $item->ID);
            $actions[] = sprintf('<a href="%s" style="color: red;">Rechazar</a>', $url);
        }

        return implode(' | ', $actions);
    }

    public function process_action()
    {
        if (!current_user_can('manage_options')) {
            wp_die('No tienes permisos.');
        }

        $record_id = (int) $_GET['record_id'];
        $new_status = sanitize_text_field($_GET['new_status']);

        check_admin_referer('process_horas_' . $record_id);

        if ($record_id && in_array($new_status, ['aprobada', 'rechazada'])) {
            $miembro_id = (int) get_post_meta($record_id, '_bdv_miembro_id', true);
            $member_post = get_post($miembro_id);
            
            if ($member_post && $member_post->post_author) {
                $member_author_id = (int) $member_post->post_author;
                $current_user_id = get_current_user_id();
                
                if ($member_author_id === $current_user_id) {
                    \Biodevas\Common\Logger::warning(
                        "Intento de auto-aprobación de horas bloqueado. Usuario: $current_user_id, Miembro: $miembro_id",
                        'Members/Hours',
                        $miembro_id
                    );
                    wp_die('No puedes aprobar tus propias horas de voluntariado.');
                }
            }

            update_post_meta($record_id, '_bdv_estado', $new_status);
            update_post_meta($record_id, '_bdv_aprobada_por', get_current_user_id());
            
            if ($new_status === 'aprobada') {
                do_action('biodevas_members_hora_aprobada', $record_id, $miembro_id);
            } elseif ($new_status === 'rechazada') {
                do_action('biodevas_members_hora_rechazada', $record_id, $miembro_id);
            }
            
            // Log activity
            $socio_id = get_post_meta($record_id, '_bdv_miembro_id', true);
            \Biodevas\Common\Logger::log("Registro de horas $record_id marcado como $new_status por admin " . get_current_user_id(), 'Members/Hours', $socio_id);
        }

        wp_redirect(admin_url('edit.php?post_type=miembro&page=bdv-volunteer-hours'));
        exit;
    }
}
