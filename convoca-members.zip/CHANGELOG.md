# Changelog - Biodevas Members

All notable changes to this project will be documented in this file.

## [2.3.0] - 2026-04-30
### Fixed
- Corregidos los estilos de los bloques "Mi Área", "Alta" y "Voluntariado" (ahora se cargan correctamente en el editor).
- Rediseño completo del bloque de "Verificar Certificado" para ajustarse a la guía de estilos de Biodevas.
- Asegurada la accesibilidad administrativa a todos los tipos de contenido de socios.
- Eliminación de estilos inline en favor de clases del sistema de diseño del tema.

## [2.0.0] - 2026-04-30
### Added
- **Categoría "Biodevas: Socios"**: Los bloques relacionados con la gestión de socios y voluntarios ahora están agrupados en su propia sección.
### Changed
- **Estabilidad de Bloques**: Actualización de los editores de bloques para asegurar que no interfieran con otros componentes del editor.
### Fixed
- **Inconsistencia de Versión**: Unificadas las versiones declaradas en cabecera y constantes internas.

## [1.5.0] - 2026-04-22
### Added
- Nuevo sistema de auditoría de logs para cambios en el estado de socios.
- Soporte para certificados de voluntariado generados dinámicamente.
- Integración de Webhooks para sincronización con CRM externo.
