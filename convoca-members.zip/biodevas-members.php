<?php
/**
 * Plugin Name:       Biodevas Members
 * Plugin URI:        https://biodevas.org
 * Description:       Gestión de socios, voluntarios y comunicaciones para la Asociación Biodevas.
 * Version:           2.3.0
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            Jose Carlos Nieto Ramos
 * Author URI:        https://josecarlosnietoramos.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       biodevas-members
 * Domain Path:       /languages
 * Requires Plugins:  biodevas-common
 * Network:           true
 */

if (!defined('ABSPATH')) {
    exit;
}

// ─────────────────────────────────────────────────────────────────────────────
// Compatibility Check: Ensure Biodevas Common is active.
// ─────────────────────────────────────────────────────────────────────────────
if (!function_exists('is_plugin_active')) {
    include_once ABSPATH . 'wp-admin/includes/plugin.php';
}

if (!is_plugin_active('biodevas-common/biodevas-common.php')) {
    add_action('admin_notices', function () {
        printf(
            '<div class="notice notice-error"><p>%s</p></div>',
            esc_html__('Biodevas Members requiere el plugin Biodevas Common Utilities activo para funcionar.', 'biodevas-members')
        );
    });
    return;
}

/* ── Constants ────────────────────────────────────────────── */
define('BDV_MEMBERS_VERSION', '2.0.0');
define('BDV_MEMBERS_DB_VERSION', '1.0.1');
define('BDV_MEMBERS_FILE', __FILE__);
define('BDV_MEMBERS_DIR', plugin_dir_path(__FILE__));
define('BDV_MEMBERS_URL', plugin_dir_url(__FILE__));

/* ── Autoloader ───────────────────────────────────────────── */
spl_autoload_register(function (string $class): void {
    $prefix = 'Biodevas\\Members\\';
    if (0 !== strpos($class, $prefix)) {
        return;
    }
    $relative = str_replace($prefix, '', $class);
    $relative = strtolower(str_replace('_', '-', $relative));

    $maps = [
        'includes/',
        'admin/',
        'public/',
    ];

    foreach ($maps as $dir) {
        $file = BDV_MEMBERS_DIR . $dir . 'class-' . $relative . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

/* ── Activation / Deactivation ────────────────────────────── */
/* ── Activation / Deactivation ────────────────────────────── */
register_activation_hook(__FILE__, function (): void {
    require_once BDV_MEMBERS_DIR . 'includes/class-utils.php';
    require_once BDV_MEMBERS_DIR . 'includes/class-cpt-miembro.php';
    require_once BDV_MEMBERS_DIR . 'includes/class-cpt-documento.php';
    require_once BDV_MEMBERS_DIR . 'includes/class-pdf-document.php';
    require_once BDV_MEMBERS_DIR . 'includes/class-estados.php';
    Biodevas\Members\CPT_Miembro::register();
    \Biodevas\Common\Installer::db_init();

    // Schedule Daily Cron
    if (!wp_next_scheduled('bdv_daily_event')) {
        wp_schedule_event(time(), 'daily', 'bdv_daily_event');
    }

    // Schedule Weekly Cron (admin digest)
    if (!wp_next_scheduled('bdv_weekly_event')) {
        // Next Monday at 08:00
        $next_monday = strtotime('next monday 08:00:00');
        wp_schedule_event($next_monday, 'weekly', 'bdv_weekly_event');
    }

    flush_rewrite_rules();

    // Default email templates.
    require_once BDV_MEMBERS_DIR . 'includes/class-email-manager.php';
    Biodevas\Members\Email_Manager::install_defaults();

    // Default settings.
    if (false === get_option('bdv_members_settings')) {
        update_option('bdv_members_settings', [
            'admin_email' => get_option('admin_email'),
            'iban' => '',
            'rgpd_version' => '1.0',
        ]);
        
        $role = get_role('administrator');
        if ($role) {
            $role->add_cap('gestionar_miembros');
            $role->add_cap('gestionar_documentos_voluntariado');
        }

        // Add caps to shop_manager if exists (WooCommerce)
        $shop_manager = get_role('shop_manager');
        if ($shop_manager) {
            $shop_manager->add_cap('gestionar_miembros');
            $shop_manager->add_cap('gestionar_documentos_voluntariado');
        }

        // Add caps to monitor_actividad
        $monitor = get_role('monitor_actividad');
        if ($monitor) {
            $monitor->add_cap('gestionar_miembros');
            $monitor->add_cap('gestionar_documentos_voluntariado');
        }
    }

    // Save initial DB version.
    add_option('bdv_members_db_version', BDV_MEMBERS_DB_VERSION, '', false);
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('bdv_daily_event');
    wp_clear_scheduled_hook('bdv_weekly_event');
    flush_rewrite_rules();
});

/* ── Boot ─────────────────────────────────────────────────── */
add_action('plugins_loaded', function (): void {

    // Core.
    new Biodevas\Members\CPT_Miembro();
    new Biodevas\Members\Estados();
    new Biodevas\Members\Email_Manager();
    new Biodevas\Members\Rest_API();
    new Biodevas\Members\Payment_Listener();
    new Biodevas\Members\CPT_Registro_Hora();
    new Biodevas\Members\CPT_Proyecto();
    new Biodevas\Members\CPT_Documento();
    \Biodevas\Members\PDF_Document::init();
    \Biodevas\Members\Voluntariado_Manager::init();
    // GDPR compliance: data export/erasure via WordPress Privacy Tools.
    Biodevas\Members\GDPR_Tools::init();
    // Automation handled via state hooks.
    // Load Cron Jobs
    require_once BDV_MEMBERS_DIR . 'includes/class-cron-manager.php';
    new Biodevas\Members\Cron_Manager();
    new Biodevas\Members\Audit_Logger();

    // Upgrade Manager (checks for DB version upgrades on admin_init).
    new Biodevas\Members\Members_Upgrade_Manager();


    // Admin.
    if (is_admin()) {
        new Biodevas\Members\Admin_Page();
        new Biodevas\Members\Admin_Settings();
        new Biodevas\Members\Admin_Metaboxes();
        new Biodevas\Members\CSV_Exporter();
        new Biodevas\Members\Admin_Horas();
        new Biodevas\Members\Admin_Dashboard();
        new Biodevas\Members\Admin_Webhooks();
        new Biodevas\Members\Admin_Proyectos();
    }

    // Public.
    new Biodevas\Members\Form_Handler();
    new Biodevas\Members\Form_Voluntariado();
    new Biodevas\Members\Mi_Area();
    new Biodevas\Members\Verificar_Certificado();
    new Biodevas\Members\Block_Members();
});

add_action('init', [\Biodevas\Members\CPT_Miembro::class, 'register']);
add_action('init', [\Biodevas\Members\CPT_Registro_Hora::class, 'register']);
add_action('init', [\Biodevas\Members\CPT_Proyecto::class, 'register']);
add_action('add_meta_boxes_proyecto', [\Biodevas\Members\CPT_Proyecto::class, 'render_metabox']);
add_action('save_post_proyecto', [\Biodevas\Members\CPT_Proyecto::class, 'save_metabox']);

/* ── Admin Actions ────────────────────────────────────────── */
add_action('admin_post_bdv_approve_member', function () {
    if (!current_user_can('edit_users')) {
        wp_die('No tienes permisos.');
    }

    $id = (int) ($_GET['member_id'] ?? 0);
    check_admin_referer('bdv_approve_member_' . $id);

    if ($id && \Biodevas\Members\CPT_Miembro::approve_member($id)) {
        // Redirect back.
        wp_redirect(admin_url('admin.php?page=bdv-members&msg=approved'));
        exit;
    }

    wp_redirect(admin_url('admin.php?page=bdv-members&msg=error'));
    exit;
});

add_action('admin_post_bdv_delete_member', function () {
    if (!current_user_can('delete_posts')) {
        wp_die('No tienes permisos.');
    }

    $id = (int) ($_GET['member_id'] ?? 0);
    check_admin_referer('bdv_delete_member_' . $id);

    if ($id && wp_trash_post($id)) {
        wp_redirect(admin_url('admin.php?page=bdv-members&msg=deleted'));
        exit;
    }

    wp_redirect(admin_url('admin.php?page=bdv-members&msg=error'));
    exit;
});

add_action('admin_post_bdv_pdf_card', function () {
    $id = (int) ($_GET['member_id'] ?? 0);

    // Security checks.
    if (!$id || get_post_type($id) !== 'miembro') {
        wp_die(esc_html__('ID de miembro no válido.', 'biodevas-members'));
    }

    check_admin_referer('bdv_pdf_card_' . $id);

    if (!current_user_can('edit_post', $id)) {
        wp_die(esc_html__('No tienes permisos para ver la tarjeta de este miembro.', 'biodevas-members'));
    }

    echo \Biodevas\Members\PDF_Card::get_html($id);
    exit;
});
