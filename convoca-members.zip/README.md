# Biodevas Members

**Plugin de gestiÃ³n de socios y voluntarios para la AsociaciÃ³n Biodevas.**

| Dato | Valor |
|---|---|
| **Versión** | 1.5.0 |
| **Requiere PHP** | 8.1+ |
| **Requiere WP** | 6.4+ |
| **Depende de** | `biodevas-common` |
| **Namespace** | `Biodevas\Members` |
| **Autor** | Jose Carlos Nieto Ramos |

---

## Changelog

### 1.5.0 (2026-04-30)
- **Nuevo:** Sistema de gestión de Voluntariado expandido (separación clara entre Socios y Voluntarios).
- **Nuevo:** Generación automática del "Acuerdo de Incorporación de Voluntariado" mediante `BDV_Signature`.
- **Nuevo:** Registro de datos técnicos de aceptación (IP, timestamp, hash) en el PDF del acuerdo.
- **Mejora:** Campos personalizables en el formulario `[biodevas_voluntariado]` (Teléfono, DNI, Dirección, etc.).
- **Mejora:** Lógica de asignación de roles y capacidades (`voluntario_aprobado`) centralizada.

### 1.4.0 (2026-04-30)
- **Mejora:** Refactorizado el sistema de generación de Acuerdos para usar el motor centralizado `BDV_Signature`.


### 1.3.0 (2026-04-30)
- **Nuevo:** Sistema de auditorÃ­a completo â€” registra cambios de estado, borrados lÃ³gicos, emails enviados, contacto vÃ­a WhatsApp y todas las acciones administrativas.
- **Nuevo:** Bloques de Gutenberg nativos para todos los shortcodes (`biodevas/alta-socio`, `biodevas/mi-area`, `biodevas/voluntariado`).
- **Nuevo:** Botones AJAX corregidos en el metabox de socio (Generar Link de Pago, Enviar Recordatorio RGPD).
- **Fix:** MigraciÃ³n completa de `date()` â†’ `wp_date()` en 7 archivos para consistencia de zona horaria (Europe/Madrid).
- **Fix:** NÃºmero de socio ahora se muestra correctamente en la tarjeta de socio.
- **Fix:** Checkbox "RenovaciÃ³n automÃ¡tica anual" redimensionado.
- **Fix:** Estado de cuota se calcula dinÃ¡micamente al crear el miembro.
- **Fix:** Botones superpuestos en el listado de miembros.
- **Fix:** Error JS `Cannot set properties of null` en el metabox de acciones.

### 1.2.1
- Fix: Corregidas meta keys RGPD para horas de voluntariado.
- Fix: Sincronizada constante BDV_MEMBERS_VERSION con versiÃ³n del header.

### 1.2.0
- Nuevo: Sistema de versionado de base de datos con Members_Upgrade_Manager.
- Nuevo: Herramientas RGPD en metabox de miembro (exportar/eliminar datos JSON).

### 1.1.0
- Nuevo: Sistema completo de voluntariado con CPT Proyectos.
- Nuevo: GeneraciÃ³n de certificados PDF con Dompdf.

### 1.0.2
- Primera versiÃ³n: CPT, formularios, emails, admin, REST API.

---

## Funcionalidades principales

- **GestiÃ³n de socios** â€” Alta, baja, renovaciÃ³n, estados (pendiente, activo, suspendido, baja).
- **Voluntariado** â€” Registro de horas, aprobaciÃ³n por admin, seguimiento.
- **AuditorÃ­a** â€” Log completo de todas las acciones con paginaciÃ³n y filtros.
- **Planes de membresÃ­a** â€” ConfiguraciÃ³n de cuotas anuales y modalidades.
- **Panel pÃºblico de socio** â€” Shortcode `[biodevas_mi_area]` con autenticaciÃ³n email+cÃ³digo.
- **Tarjeta digital** â€” GeneraciÃ³n PDF descargable desde el panel.
- **Certificados de voluntariado** â€” PDF con verificaciÃ³n online vÃ­a QR.
- **Emails automÃ¡ticos** â€” Bienvenida, recordatorios, aprobaciÃ³n, etc.
- **Cron jobs** â€” Recordatorios de pago, expiraciÃ³n de membresÃ­as, digest semanal.
- **Dashboard admin** â€” Widget con mÃ©tricas, alertas y acciones rÃ¡pidas.
- **Bloques Gutenberg** â€” InserciÃ³n directa desde el editor visual de WordPress.
- **Webhooks** â€” IntegraciÃ³n con sistemas externos vÃ­a `biodevas-common`.
- **REST API** â€” Endpoints para el panel de socio (login, perfil, inscripciones, pagos, horas).

## Requisitos

1. WordPress 6.4+
2. PHP 8.1+
3. Plugin `biodevas-common` activo.
4. *(Opcional)* `biodevas-gateway` para pagos de cuotas.
5. *(Opcional)* `biodevas-enroll` para consultar inscripciones desde el panel.

## InstalaciÃ³n

1. AsegÃºrate de que `biodevas-common` estÃ© activo.
2. Sube la carpeta `biodevas-members` a `wp-content/plugins/`.
3. Activa desde **Plugins** en el administrador.
4. Ve a **Biodevas Socios â†’ Ajustes** para configurar planes, emails y opciones.

## Estructura

```
biodevas-members/
â”œâ”€â”€ biodevas-members.php           # Punto de entrada
â”œâ”€â”€ includes/
â”‚   â”œâ”€â”€ class-cpt-miembro.php      # CPT 'miembro' + planes
â”‚   â”œâ”€â”€ class-estados.php          # MÃ¡quina de estados
â”‚   â”œâ”€â”€ class-process-member.php   # LÃ³gica de registro central
â”‚   â”œâ”€â”€ class-member-auth.php      # AutenticaciÃ³n sesiÃ³n/token
â”‚   â”œâ”€â”€ class-rest-api.php         # REST API endpoints
â”‚   â”œâ”€â”€ class-email-manager.php    # Plantillas de email
â”‚   â”œâ”€â”€ class-cron-manager.php     # Tareas programadas
â”‚   â”œâ”€â”€ class-pdf-card.php         # Tarjeta digital PDF
â”‚   â”œâ”€â”€ class-certificate-generator.php # Certificados de voluntariado
â”‚   â”œâ”€â”€ class-audit-logger.php     # Sistema de auditorÃ­a
â”‚   â””â”€â”€ ...
â”œâ”€â”€ admin/
â”‚   â”œâ”€â”€ class-admin-page.php       # PÃ¡ginas de administraciÃ³n
â”‚   â”œâ”€â”€ class-admin-dashboard.php  # Widget del dashboard
â”‚   â”œâ”€â”€ class-admin-settings.php   # ConfiguraciÃ³n
â”‚   â””â”€â”€ class-admin-webhooks.php   # GestiÃ³n de webhooks
â”œâ”€â”€ public/
â”‚   â”œâ”€â”€ class-form-handler.php     # Formulario [biodevas_alta]
â”‚   â”œâ”€â”€ class-form-voluntariado.php # Formulario [biodevas_voluntariado]
â”‚   â””â”€â”€ class-mi-area.php         # Panel [biodevas_mi_area]
â”œâ”€â”€ templates/                     # Plantillas PHP
â””â”€â”€ assets/                        # CSS + JS
```

## Shortcodes y Bloques

| Shortcode | Bloque Gutenberg | DescripciÃ³n |
|---|---|---|
| `[biodevas_alta]` | `biodevas/alta-socio` | Formulario de alta de socios (multi-paso) |
| `[biodevas_voluntariado]` | `biodevas/voluntariado` | Formulario de registro de voluntarios |
| `[biodevas_mi_area]` | `biodevas/mi-area` | Panel privado del socio |

## REST API

Base: `/wp-json/biodevas/v1/`

| MÃ©todo | Endpoint | Auth | DescripciÃ³n |
|---|---|---|---|
| `POST` | `/login` | PÃºblica | Login con email + cÃ³digo |
| `GET` | `/me` | SesiÃ³n | Perfil del socio |
| `GET` | `/me/inscripciones` | SesiÃ³n | Historial de inscripciones |
| `GET` | `/me/pagos` | SesiÃ³n | Historial de pagos |
| `GET` | `/me/horas` | SesiÃ³n | Horas de voluntariado |
| `POST` | `/me/horas` | SesiÃ³n | Enviar nuevo registro de horas |
| `GET` | `/me/card` | SesiÃ³n | Descargar tarjeta digital HTML |

> **AutenticaciÃ³n:** Los endpoints protegidos requieren una sesiÃ³n activa (cookie `bdv_member_session`) obtenida tras un login exitoso. El token tambiÃ©n puede enviarse como header `X-BDV-Auth`.

## Hooks (Acciones)

Ver el archivo [HOOKS.md](../biodevas-common/HOOKS.md) para la referencia completa.

| Hook | ParÃ¡metros |
|---|---|
| `biodevas_members_estado_changed` | `$post_id, $new, $old` |
| `biodevas_members_created` | `$post_id` |
| `biodevas_members_email_bienvenida` | `$post_id` |
| `biodevas_members_email_recordatorio_pago` | `$post_id` |
| `biodevas_members_hours_submitted` | `$post_id, $member_id` |
| `biodevas_members_unsubscribe_request` | `$member_id` |
| `biodevas_members_cuota_pagada` | `$member_id, $pago_id` |
| `biodevas_members_membership_expired` | `$member_id` |
| `biodevas_members_payment_reminder_sent` | `$member_id, $key, $days` |

## Cron Jobs

| Evento | Frecuencia | DescripciÃ³n |
|---|---|---|
| `bdv_daily_maintenance` | Diario | ExpiraciÃ³n de membresÃ­as y recordatorios |
| `bdv_weekly_digest` | Semanal | Resumen semanal para admins |

## ConfiguraciÃ³n

Accesible desde **Biodevas Socios â†’ Ajustes** en el admin de WP.

- **Planes** â€” Nombre, slug, cuota anual, descripciÃ³n.
- **Emails** â€” Remitente, CC, plantilla de bienvenida.
- **Recordatorios** â€” DÃ­as antes/despuÃ©s de expiraciÃ³n para enviar avisos.
- **Panel pÃºblico** â€” PÃ¡gina donde se usa `[biodevas_mi_area]`.

## Licencia

Uso interno â€” AsociaciÃ³n Biodevas.

## Novedades en 1.4.0
- Refactorizado el sistema de generación de Acuerdos de Incorporación para utilizar el motor centralizado BDV_Signature.
