<?php
/**
 * Volunteer registration form (shortcode [biodevas_voluntariado]).
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class Form_Voluntariado
{

    /** Interest areas matching the static site. */
    public const INTEREST_AREAS = [
        'educacion' => '📚 Educación Ambiental',
        'aves' => '🐦 Ornitología (Paxareando)',
        'marina' => '🌊 Biodiversidad Marina (GIMPA)',
        'rios' => '💧 Ciencia Ciudadana Fluvial',
        'botanica' => '🌿 Botánica (Veget-ando)',
        'meteo' => '🌦️ Meteorología (Troposfera)',
        'infantil' => '👶 Actividades Infantiles (Busgosu)',
        'lugg' => '🏠 Centro Social Los Lugg',
        'comunicacion' => '📢 Comunicación y RRSS',
        'diseno' => '🎨 Diseño e Ilustración',
        'fotografia' => '📷 Fotografía de Naturaleza',
        'logistica' => '🚗 Logística y Coordinación',
    ];

    public function __construct()
    {
        add_shortcode('biodevas_voluntariado', [$this, 'render']);
        add_action('wp_ajax_bdv_voluntariado_submit', [$this, 'handle_submit']);
        add_action('wp_ajax_nopriv_bdv_voluntariado_submit', [$this, 'handle_submit']);
    }

    public function render(): string
    {
        wp_enqueue_style(
            'bdv-members-public',
            BDV_MEMBERS_URL . 'assets/css/biodevas-members-public.css',
            [],
            BDV_MEMBERS_VERSION
        );
        wp_enqueue_script(
            'bdv-members-public',
            BDV_MEMBERS_URL . 'assets/js/biodevas-members-public.js',
            ['biodevas-common-js'],
            BDV_MEMBERS_VERSION,
            true
        );
        wp_localize_script('bdv-members-public', 'bdvMembers', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'volNonce' => wp_create_nonce('bdv_voluntariado_nonce'),
        ]);

        ob_start();
        include BDV_MEMBERS_DIR . 'templates/form-voluntariado.php';
        return ob_get_clean();
    }

    public function handle_submit(): void
    {

        check_ajax_referer('bdv_voluntariado_nonce', 'nonce');

        $nombre = sanitize_text_field($_POST['nombre'] ?? '');
        $dni = strtoupper(trim($_POST['dni'] ?? ''));
        $dni = str_replace([' ', '-'], '', $dni);
        $fecha_nac = sanitize_text_field($_POST['fecha_nacimiento'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $telefono = sanitize_text_field($_POST['telefono'] ?? '');
        $whatsapp = sanitize_text_field($_POST['whatsapp'] ?? 'si');
        $direccion = sanitize_text_field($_POST['direccion'] ?? '');
        $municipio = sanitize_text_field($_POST['municipio'] ?? '');
        $canal = sanitize_text_field($_POST['canal_contacto'] ?? 'whatsapp');
        $disponibilidad = sanitize_text_field($_POST['disponibilidad'] ?? '');
        $experiencia = sanitize_text_field($_POST['experiencia'] ?? '');
        $motivacion = sanitize_textarea_field($_POST['motivacion'] ?? '');
        $rgpd = !empty($_POST['rgpd']);
        $comunicaciones = !empty($_POST['comunicaciones']);

        // Interests.
        $intereses_raw = isset($_POST['intereses']) && is_array($_POST['intereses'])
            ? array_map('sanitize_text_field', $_POST['intereses'])
            : [];
        $intereses = implode(',', $intereses_raw);

        // Validation.
        $errors = [];
        if (empty($nombre))
            $errors[] = 'El nombre es obligatorio.';
        if (empty($dni))
            $errors[] = 'El DNI/NIE es obligatorio.';
        if (empty($fecha_nac))
            $errors[] = 'La fecha de nacimiento es obligatoria.';
        if (!is_email($email))
            $errors[] = 'El email no es válido.';
        if (empty($telefono))
            $errors[] = 'El teléfono es obligatorio.';
        if (empty($direccion))
            $errors[] = 'La dirección es obligatoria.';
        if (empty($municipio))
            $errors[] = 'El municipio es obligatorio.';
        if (!$rgpd)
            $errors[] = 'Debes aceptar la política de privacidad.';
        if (empty($_POST['declaracion_responsable']))
            $errors[] = 'Debes aceptar la Declaración Responsable.';

        if ($dni && !self::validar_dni($dni)) {
            $errors[] = 'El DNI/NIE no es válido.';
        }

        // Dynamic fields validation
        $dynamic_fields = get_option('bdv_volunteer_fields', []);
        $dynamic_data = [];
        foreach ($dynamic_fields as $field) {
            $name = 'dyn_' . $field['name'];
            $val = isset($_POST[$name]) ? (is_array($_POST[$name]) ? implode(', ', array_map('sanitize_text_field', $_POST[$name])) : sanitize_textarea_field($_POST[$name])) : '';
            if (!empty($field['required']) && empty($val)) {
                $errors[] = sprintf('El campo "%s" es obligatorio.', $field['label']);
            }
            $dynamic_data['_cst_' . $field['name']] = $val;
        }

        if (!empty($errors)) {
            wp_send_json_error(['errors' => $errors]);
        }

        // Check for duplicate Email. DNI is handled in meta.
        if (email_exists($email)) {
            wp_send_json_error(['errors' => ['Ese correo ya está registrado en el sistema.']]);
        }
        
        // Check for duplicate DNI in user meta
        $existing_dni = get_users([
            'meta_key' => '_cst_dni',
            'meta_value' => $dni,
            'number' => 1
        ]);
        if (!empty($existing_dni)) {
            wp_send_json_error(['errors' => ['Ese DNI ya está registrado en el sistema.']]);
        }

        // Minor detection.
        $dob = new \DateTime($fecha_nac);
        $today = new \DateTime();
        $age = $today->diff($dob)->y;
        $menor = $age < 18;

        // Create WP User
        $username = sanitize_user(current(explode('@', $email)) . wp_rand(100, 999));
        $password = wp_generate_password(12, false);
        $user_id = wp_create_user($username, $password, $email);

        if (is_wp_error($user_id)) {
            wp_send_json_error(['errors' => ['Error al crear el registro: ' . $user_id->get_error_message()]]);
        }

        // Update basic user info
        wp_update_user([
            'ID' => $user_id,
            'first_name' => $nombre,
        ]);

        $settings = get_option('bdv_members_settings', []);

        $meta_map = [
            '_cst_aprobado' => 0, // Pending approval
            '_cst_dni' => $dni,
            '_cst_fecha_nacimiento' => $fecha_nac,
            '_cst_telefono' => $telefono,
            '_cst_whatsapp' => $whatsapp,
            '_cst_direccion' => $direccion,
            '_cst_municipio' => $municipio,
            '_cst_canal_contacto' => $canal,
            '_cst_intereses' => $intereses,
            '_cst_disponibilidad' => $disponibilidad,
            '_cst_experiencia' => $experiencia,
            '_cst_motivacion' => $motivacion,
            '_cst_menor_edad' => $menor ? '1' : '0',
            '_cst_rgpd_version' => $settings['rgpd_version'] ?? '1.0',
            '_cst_rgpd_timestamp' => current_time('mysql'),
            '_cst_comunicaciones_ok' => $comunicaciones ? '1' : '0',
            '_cst_declaracion_responsable' => '1'
        ];

        if ($menor) {
            $meta_map['_cst_tutor_nombre'] = sanitize_text_field($_POST['tutor_nombre'] ?? '');
            $meta_map['_cst_tutor_dni'] = sanitize_text_field($_POST['tutor_dni'] ?? '');
        }

        // Merge dynamic fields
        $meta_map = array_merge($meta_map, $dynamic_data);

        foreach ($meta_map as $key => $value) {
            update_user_meta($user_id, $key, $value);
        }

        // Notify admins
        wp_mail(
            $settings['admin_email'] ?? get_option('admin_email'),
            'Nueva solicitud de voluntariado',
            "Se ha recibido una nueva solicitud de voluntariado de {$nombre} ({$email}).\nRevisa la pantalla de 'Gestionar Voluntarios' para aprobarla."
        );

        wp_send_json_success([
            'nombre' => $nombre,
            'email' => $email,
        ]);
    }
    /**
     * Validate Spanish DNI/NIE checksum.
     */
    public static function validar_dni(string $dni): bool
    {
        $dni = strtoupper(trim($dni));
        $dni = str_replace([' ', '-'], '', $dni);

        if (!preg_match('/^[XYZ0-9][0-9]{7}[A-Z]$/', $dni)) {
            return false;
        }

        $letra = substr($dni, -1);
        $numeros = substr($dni, 0, -1);

        // NIE handling.
        $numeros = str_replace(['X', 'Y', 'Z'], ['0', '1', '2'], $numeros);

        $letras_validas = 'TRWAGMYFPDXBNJZSQVHLCKE';
        $letra_esperada = $letras_validas[((int) $numeros) % 23];

        return $letra === $letra_esperada;
    }
}
