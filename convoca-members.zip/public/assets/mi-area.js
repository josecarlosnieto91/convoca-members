/**
 * Biodevas Members — Mi Area JS (Vanilla)
 * User panel operations inside 'Mi Area'.
 */
(function(bdv) {
  'use strict';

  const MiArea = {
    init: function() {
      this.cache();
      if (!this.$container) return;
      this.bindEvents();
      this.checkLoginStatus();
    },

    cache: function() {
      this.$container = bdv.$('#bdv-mi-area');
      this.$main = bdv.$('#bdv-main-content');
    },

    bindEvents: function() {
      const self = this;

      // Event delegation implementation for container
      this.$container.addEventListener('submit', function(e) {
        if (e.target && e.target.id === 'bdv-login-form') {
            e.preventDefault();
            self.handleLogin(e.target);
        } else if (e.target && e.target.id === 'bdv-hours-form') {
            e.preventDefault();
            self.submitHours(e.target);
        }
      });

      this.$container.addEventListener('click', function(e) {
        if (e.target.closest('#bdv-logout-btn')) {
            e.preventDefault();
            self.handleLogout();
        } else if (e.target.closest('#bdv-btn-unsubscribe')) {
            e.preventDefault();
            if (confirm('¿Estás seguro de que quieres solicitar la baja del club de socios?')) {
                self.requestUnsubscribe();
            }
        } else {
            const tabBtn = e.target.closest('.bdv-panel-nav li');
            if (tabBtn) {
                if (tabBtn.classList.contains('active')) return;
                bdv.$$('.bdv-panel-nav li', self.$container).forEach(t => t.classList.remove('active'));
                tabBtn.classList.add('active');
                self.switchTab(tabBtn.dataset.tab);
            }
        }
      });
    },

    checkLoginStatus: function() {
      if (window.bdvMiArea && window.bdvMiArea.isLoggedIn) {
        const activeTabEl = bdv.$('.bdv-panel-nav li.active', this.$container);
        const activeTab = activeTabEl ? activeTabEl.dataset.tab : 'profile';
        this.switchTab(activeTab);
      }
    },

    handleLogin: function(form) {
      const btn = form.querySelector('button');
      const result = bdv.$('.form-result', form);
      const data = {
        email: bdv.$('#email', form).value,
        code: bdv.$('#code', form).value
      };

      bdv.setLoading(btn, true, 'Entrar');
      result.innerHTML = '';

      fetch(window.bdvMiArea.apiUrl + '/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': window.bdvMiArea.nonce },
        body: JSON.stringify(data)
      })
      .then(res => res.json())
      .then(res => {
        if (res.success) {
          location.reload();
        } else {
          result.innerHTML = '<p class="text-error">' + res.message + '</p>';
          bdv.setLoading(btn, false, 'Entrar');
        }
      })
      .catch(() => {
        result.innerHTML = '<p class="text-error">Error de conexión.</p>';
        bdv.setLoading(btn, false, 'Entrar');
      });
    },

    handleLogout: function() {
      document.cookie = 'bdv_member_session=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
      location.reload();
    },

    switchTab: function(tab) {
      this.$main.innerHTML = '<div class="bdv-spinner"></div>';
      
      switch(tab) {
        case 'profile': this.fetchProfile(); break;
        case 'inscriptions': this.fetchInscriptions(); break;
        case 'payments': this.fetchPayments(); break;
        case 'hours': this.fetchHours(); break;
        case 'membership': this.renderMembership(); break;
      }
    },

    fetchProfile: function() {
      fetch(window.bdvMiArea.apiUrl + '/me', { headers: { 'X-WP-Nonce': window.bdvMiArea.nonce } })
      .then(res => res.json())
      .then(profile => {
        const html = `
          <h2>👤 Mis Datos</h2>
          <div class="bdv-meta-grid">
            <div class="meta-item"><strong>Nombre:</strong> <span>${profile.nombre}</span></div>
            <div class="meta-item"><strong>Email:</strong> <span>${profile.email}</span></div>
            <div class="meta-item"><strong>Código de Acceso:</strong> <span>${profile.codigo}</span></div>
            <div class="meta-item"><strong>Estado:</strong> ${this.formatEstado(profile.estado)}</div>
          </div>
          <hr>
          <h3>Zona de Peligro</h3>
          <p class="text-muted">Si deseas solicitar tu baja como socio/a, puedes hacerlo pulsando el siguiente botón. Se notificará a la administración para procesarla.</p>
          <button id="bdv-btn-unsubscribe" class="btn-danger-outline">Solicitar Baja</button>
        `;
        this.$main.innerHTML = html;
      })
      .catch(() => { this.$main.innerHTML = '<p>Error cargando perfil.</p>'; });
    },

    fetchInscriptions: function() {
      fetch(window.bdvMiArea.apiUrl + '/me/inscripciones', { headers: { 'X-WP-Nonce': window.bdvMiArea.nonce } })
      .then(res => res.json())
      .then(data => {
        if (!data.items || data.items.length === 0) {
          this.$main.innerHTML = '<h2>📝 Mis Inscripciones</h2><p>No tienes inscripciones recientes.</p>';
          return;
        }

        let html = `
          <h2>📝 Mis Inscripciones</h2>
          <table class="bdv-table">
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Actividad</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              ${data.items.map(item => `
                <tr>
                  <td>${item.fecha}</td>
                  <td>${item.actividad}</td>
                  <td>${this.formatEstadoBadge(item.estado)}</td>
                  <td>
                    ${(['confirmada', 'pagada'].includes(item.estado)) && item.token ? `
                      <a href="/wp-json/biodevas-enroll/v1/ics?id=${item.id}&token=${item.token}" class="btn-primary-mini" title="Añadir a mi calendario">📅 Calendario</a>
                    ` : ''}
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        `;
        this.$main.innerHTML = html;
      })
      .catch(() => { this.$main.innerHTML = '<p>Error cargando inscripciones.</p>'; });
    },

    fetchPayments: function() {
      fetch(window.bdvMiArea.apiUrl + '/me/pagos', { headers: { 'X-WP-Nonce': window.bdvMiArea.nonce } })
      .then(res => res.json())
      .then(data => {
        if (!data.items || data.items.length === 0) {
          this.$main.innerHTML = '<h2>💳 Pagos y Cuotas</h2><p>No se han encontrado pagos registrados.</p>';
          return;
        }

        let html = `
          <h2>💳 Mis Pagos</h2>
          <table class="bdv-table">
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Concepto</th>
                <th>Importe</th>
                <th>Estado</th>
              </tr>
            </thead>
            <tbody>
              ${data.items.map(item => `
                <tr>
                  <td>${item.fecha}</td>
                  <td>${item.concepto}</td>
                  <td>${item.importe}€</td>
                  <td>${this.formatEstadoBadge(item.estado)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        `;
        this.$main.innerHTML = html;
      })
      .catch(() => { this.$main.innerHTML = '<p>Error cargando pagos.</p>'; });
    },

    fetchHours: function() {
      Promise.all([
        fetch(window.bdvMiArea.apiUrl + '/me/hours', { headers: { 'X-WP-Nonce': window.bdvMiArea.nonce } }).then(res => res.json()),
        fetch(window.bdvMiArea.apiUrl + '/activities', { headers: { 'X-WP-Nonce': window.bdvMiArea.nonce } }).then(res => res.json()),
        fetch(window.bdvMiArea.apiUrl + '/proyectos').then(res => res.json())
      ])
      .then(([data, activities, proyectos]) => {
        let itemsHtml = '<p>No tienes registros de horas.</p>';
        if (data.items && data.items.length > 0) {
          itemsHtml = `
            <table class="bdv-table">
              <thead>
                <tr>
                  <th>Fecha</th>
                  <th>Proyecto</th>
                  <th>Tareas</th>
                  <th>Horas</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                ${data.items.map(item => `
                  <tr>
                    <td>${item.fecha}</td>
                    <td>${item.proyecto || '—'}</td>
                    <td>${item.tareas ? (item.tareas.length > 40 ? item.tareas.substring(0,40) + '...' : item.tareas) : '—'}</td>
                    <td>${item.horas}h</td>
                    <td>${this.formatEstadoBadge(item.estado)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          `;
        }

        let activityOptions = (activities || []).map(act => `<option value="${act.id}">${act.title}</option>`).join('');
        let proyectoOptions = (proyectos || []).map(p => `<option value="${p.id}">${p.title}</option>`).join('');

        let html = `
          <div class="bdv-hours-layout">
            <div class="hours-header">
              <h2>⏳ Mis Horas de Voluntariado</h2>
              <div class="hours-summary">
                <span class="total-badge">${data.total_horas}h <span>Totales Aprobadas</span></span>
              </div>
            </div>
            
            <section class="card-inner">
              <h3>Añadir Nuevo Registro</h3>
              <form id="bdv-hours-form" class="bdv-inline-form">
                <div class="form-group"><input type="date" name="fecha" required></div>
                <div class="form-group">
                  <select name="proyecto_id" required>
                    <option value="">Selecciona proyecto *</option>
                    ${proyectoOptions}
                  </select>
                </div>
                <div class="form-group">
                  <select name="actividad_id">
                    <option value="">Selecciona actividad (opcional)</option>
                    ${activityOptions}
                  </select>
                </div>
                <div class="form-group"><input type="number" name="horas" step="0.5" placeholder="Horas" required></div>
                <div class="form-group">
                  <textarea name="tareas" placeholder="Describe las tareas realizadas (obligatorio)" maxlength="500" rows="2" required></textarea>
                </div>
                <div class="form-group"><input type="text" name="descripcion" placeholder="Descripción breve (opcional)"></div>
                <button type="submit" class="btn-primary-mini">Añadir</button>
              </form>
            </section>

            <section class="history-section">
              <h3>Historial</h3>
              ${itemsHtml}
            </section>
          </div>
        `;
        
        fetch(window.bdvMiArea.apiUrl + '/me/certificate', { headers: { 'X-WP-Nonce': window.bdvMiArea.nonce } })
        .then(res => res.json())
        .then(cert => {
          if (cert.success) {
            html += '<div class="bdv-certificate-section" style="margin-top: 30px; text-align: center; padding: 20px; background: #d4edda; border-radius: 8px;">' +
              '<h3>🎉 ¡Felicidades! Has completado tu voluntariado</h3>' +
              '<p>Has completado ' + cert.horas + ' horas. Ya puedes descargar tu certificado.</p>' +
              '<a href="' + cert.download_url + '" class="btn btn-primary" target="_blank">📜 Descargar Certificado</a>' +
              '</div>';
          } else if (cert.progress) {
            const pct = cert.progress.porcentaje;
            html += '<div class="bdv-certificate-section" style="margin-top: 30px; text-align: center; padding: 20px; background: #fff3cd; border-radius: 8px;">' +
              '<h3>📊 Progreso hacia el certificado</h3>' +
              '<div style="width: 100%; background: #e9ecef; height: 20px; border-radius: 10px; overflow: hidden; margin: 10px 0;">' +
              '<div style="width: ' + pct + '%; background: #28a745; height: 100%;"></div></div>' +
              '<p>' + cert.progress.total + ' / ' + cert.progress.objetivo + ' horas (' + pct + '%)</p>' +
              '<p><small>Completa ' + cert.progress.objetivo + ' horas para obtener tu certificado</small></p>' +
              '</div>';
          }
          this.$main.innerHTML = html;
        });
      })
      .catch(() => { this.$main.innerHTML = '<p>Error cargando datos de horas.</p>'; });
    },

    submitHours: function(form) {
      if (!bdv.form.validate(form)) {
          alert('Revisa los campos obligatorios.');
          return;
      }

      const data = {
        fecha: bdv.$('[name="fecha"]', form).value,
        proyecto_id: bdv.$('[name="proyecto_id"]', form).value,
        actividad_id: bdv.$('[name="actividad_id"]', form).value,
        horas: bdv.$('[name="horas"]', form).value,
        tareas: bdv.$('[name="tareas"]', form).value,
        descripcion: bdv.$('[name="descripcion"]', form).value
      };

      const btn = form.querySelector('button[type="submit"]');
      bdv.setLoading(btn, true, 'Añadiendo...');

      fetch(window.bdvMiArea.apiUrl + '/me/hours', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': window.bdvMiArea.nonce },
        body: JSON.stringify(data)
      })
      .then(res => res.json())
      .then(res => {
        if (res.success) {
          this.switchTab('hours');
        } else {
          alert('Error: ' + res.message);
          bdv.setLoading(btn, false, 'Añadir');
        }
      })
      .catch(() => {
          alert('Error de conexión.');
          bdv.setLoading(btn, false, 'Añadir');
      });
    },

    requestUnsubscribe: function() {
      fetch(window.bdvMiArea.apiUrl + '/me/unsubscribe', {
        method: 'POST',
        headers: { 'X-WP-Nonce': window.bdvMiArea.nonce }
      })
      .then(res => res.json())
      .then(res => {
        if (res.success) {
          alert('Solicitud enviada correctamente. La administración se pondrá en contacto contigo.');
          location.reload();
        } else {
          alert(res.message || 'Error en la solicitud.');
        }
      })
      .catch(() => alert('Error de conexión.'));
    },

    renderMembership: function() {
      const html = `
        <h2>🪪 Mi Carnet Digital</h2>
        <div class="digital-card-preview">
          <p>Tu carnet de socio/a digital:</p>
          <div class="placeholder-card card-glass">
            <h4 class="text-gradient">Biodevas Membership</h4>
            <div class="card-chip"></div>
            <div class="card-details">
              <span class="card-label">Socio/a Numerario/a</span>
            </div>
          </div>
          <br>
          <button id="bdv-btn-card" class="btn-primary">Ver / Descargar Carnet</button>
        </div>
      `;
      this.$main.innerHTML = html;

      const btnCard = bdv.$('#bdv-btn-card', this.$main);
      if (btnCard) {
          btnCard.addEventListener('click', () => {
              fetch(window.bdvMiArea.apiUrl + '/me/card', { headers: { 'X-WP-Nonce': window.bdvMiArea.nonce } })
              .then(res => res.text())
              .then(html => {
                  const win = window.open('', '_blank');
                  if (win) {
                      win.document.write(html);
                      win.document.close();
                  }
              });
          });
      }
    },

    formatEstado: function(estado) {
      const map = {
        'activo': '<span class="text-success">Activo/a</span>',
        'pendiente_pago': '<span class="text-warning">Pendiente de Pago</span>',
        'pendiente_documentacion': '<span class="text-warning">Pendiente de Documentación</span>',
        'baja_solicitada': '<span class="text-error">Baja Solicitada</span>',
      };
      return map[estado] || estado;
    },

    formatEstadoBadge: function(estado) {
      const map = {
        'confirmada': 'badge-success',
        'pagada': 'badge-success',
        'paid': 'badge-success',
        'pendiente': 'badge-warning',
        'waitlist': 'badge-warning',
        'cancelled': 'badge-error',
        'failed': 'badge-error',
        'pendiente_pago': 'badge-warning'
      };
      const label = estado.charAt(0).toUpperCase() + estado.slice(1);
      return `<span class="badge ${map[estado] || 'badge-default'}">${label}</span>`;
    }
  };

  document.addEventListener('DOMContentLoaded', () => MiArea.init());

})(window.biodevas || {});
