<?php
/**
 * Public member panel: shortcode [biodevas_mi_area].
 *
 * @package Biodevas\Members
 */

namespace Biodevas\Members;

if (!defined('ABSPATH')) {
    exit;
}

class Mi_Area
{
    public function __construct()
    {
        add_shortcode('biodevas_mi_area', [$this, 'render']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    /**
     * Enqueue CSS/JS.
     */
    public function enqueue_assets(): void
    {
        wp_enqueue_style('biodevas-mi-area', BDV_MEMBERS_URL . 'public/assets/mi-area.css', [], BDV_MEMBERS_VERSION);
        wp_enqueue_script('biodevas-mi-area', BDV_MEMBERS_URL . 'public/assets/mi-area.js', ['biodevas-common-js'], BDV_MEMBERS_VERSION, true);

        $member_id = Member_Auth::get_current_member_id();
        wp_localize_script('biodevas-mi-area', 'bdvMiArea', [
            'apiUrl' => rest_url('biodevas/v1'),
            'nonce' => wp_create_nonce('wp_rest'),
            'isLoggedIn' => $member_id > 0,
            'memberId' => $member_id,
            'messages' => [
                'loginSuccess' => __('Has iniciado sesión correctamente.', 'biodevas-members'),
                'loginError' => __('Email o código incorrecto.', 'biodevas-members'),
                'saveSuccess' => __('Datos guardados correctamente.', 'biodevas-members'),
                'hourSuccess' => __('Registro de horas enviado a revisión.', 'biodevas-members'),
            ]
        ]);
    }

    /**
     * Render the panel.
     */
    public function render(): string
    {
        $this->enqueue_assets();
        ob_start();
        $member_id = Member_Auth::get_current_member_id();

        echo '<div id="bdv-mi-area" class="bdv-mi-area" data-loading="true">';
        
        if ($member_id > 0) {
            $this->render_dashboard($member_id);
        } else {
            $this->render_login_form();
        }

        echo '</div>';

        return ob_get_clean();
    }

    /**
     * Render Login Form.
     */
    private function render_login_form(): void
    {
        ?>
        <div class="bdv-login-container card-glass">
            <h2 class="text-gradient">Acceso Socios</h2>
            <p><?php _e('Introduce tu email y tu código de acceso para entrar en tu área privada.', 'biodevas-members'); ?></p>
            <form id="bdv-login-form" class="bdv-login-form">
                <div class="form-group">
                    <label for="email"><?php _e('Email', 'biodevas-members'); ?></label>
                    <input type="email" id="email" name="email" required placeholder="ejemplo@biodevas.org">
                </div>
                <div class="form-group">
                    <label for="code"><?php _e('Código de Acceso', 'biodevas-members'); ?></label>
                    <input type="text" id="code" name="code" required maxlength="8" style="text-transform: uppercase;">
                    <small><?php _e('El código que recibiste al darte de alta (ej: AB1234)', 'biodevas-members'); ?></small>
                </div>
                <button type="submit" class="btn-primary"><?php _e('Entrar', 'biodevas-members'); ?></button>
                <div class="form-result"></div>
            </form>
        </div>
        <?php
    }

    /**
     * Render Dashboard (React-like Skeleton).
     */
    private function render_dashboard(int $member_id): void
    {
        $post = get_post($member_id);
        ?>
        <div class="bdv-dashboard-container">
            <header class="bdv-panel-header">
                <div>
                    <h1>¡Hola, <span><?php echo esc_html($post->post_title); ?></span>!</h1>
                    <p class="subtitle"><?php _e('Bienvenido a tu panel de socio de Biodevas.', 'biodevas-members'); ?></p>
                </div>
                <button id="bdv-logout-btn" class="btn-link"><?php _e('Cerrar sesión', 'biodevas-members'); ?></button>
            </header>

            <div class="bdv-panel-grid">
                <!-- Navigation -->
                <nav class="bdv-panel-nav card-glass">
                    <ul>
                        <li class="active" data-tab="profile">👤 <?php _e('Mis Datos', 'biodevas-members'); ?></li>
                        <li data-tab="membership">🪪 <?php _e('Carnet Digital', 'biodevas-members'); ?></li>
                        <li data-tab="inscriptions">📝 <?php _e('Inscripciones', 'biodevas-members'); ?></li>
                        <li data-tab="hours">⏳ <?php _e('Voluntariado', 'biodevas-members'); ?></li>
                        <li data-tab="payments">💳 <?php _e('Pagos y Cuotas', 'biodevas-members'); ?></li>
                    </ul>
                </nav>

                <!-- Content -->
                <main class="bdv-panel-content card-glass" id="bdv-main-content">
                    <div class="bdv-spinner"></div>
                </main>
            </div>
        </div>
        <?php
    }
}
